
#include "stdafx.h"
#include "volume_manager.h"

unsigned int ComBase::counter = 0;
bool ComBase::initialized = false;
