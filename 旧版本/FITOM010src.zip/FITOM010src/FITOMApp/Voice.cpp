#include "stdafx.h"
#include "Voice.h"


CVoice::CVoice()
{
}


CVoice::~CVoice()
{
}
