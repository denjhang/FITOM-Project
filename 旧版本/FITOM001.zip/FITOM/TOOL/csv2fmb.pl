#!/bin/perl

use strict;

my $infile = shift(@ARGV);
my $outfile = shift(@ARGV);

$infile ne '' or die;
$outfile ne '' or die;

my ($ifh, $sfh, $ofh);
open ($ifh, "<$infile") or die;
open ($ofh, ">$outfile") or die;
binmode($ofh);

while (<$ifh>) {
	my @buf = split(/,/, $_);
	print $ofh pack("C4a16C12C24C24C24C24", @buf);
}

close($ifh);
close($ofh);

exit;
