#!/bin/perl

use strict;

my $infile = "dxgmlist.txt";
my $outfile = "dxgm.csv";
$infile ne '' or die;
unlink($outfile);
my ($ifh, $ofh);
open ($ifh, "<$infile") or die;
while (<$ifh>) {
	system("grep -s -e \"$_\" dx100all.csv fb01all.csv n88pre.csv | head -n 1 >> $outfile");
}
close ($ifh);
