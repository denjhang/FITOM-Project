#!/bin/bash

rm -rf dxgm.csv
cat dxgmlist.txt | while read i
do
grep --text -h -s -e "$i" dx100all.csv fb01all.csv n88pre.csv | head -n 1 >> dxgm.csv
done
