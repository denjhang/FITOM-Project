#!/usr/bin/perl
use strict;

my $infile = shift(@ARGV);
my $outfile = shift(@ARGV);

$infile ne '' or die;
$outfile ne '' or die;

my ($ifh, $ofh);
open ($ifh, "<$infile") or die "$infile";
open ($ofh, ">$outfile") or die;
binmode($ifh);
#binmode($ofh);

my $buf = "";

for (my $i=0; $i<128; $i++) {
	$buf = "";
	read ($ifh, $buf, 4); #4OP[EOF]
	read ($ifh, $buf, 25);
	my $name = $buf;
	read ($ifh, $buf, 7); #extension
	read ($ifh, $buf, 11); #data
	my @data1 = unpack("C11", $buf);
	read ($ifh, $buf, 11); #data
	my @data2 = unpack("C11", $buf);
	read ($ifh, $buf, 2); #dummy
	my $lfo = 0;
	my $fb = (($data2[10] << 3) & 0x70) | (($data1[10] >> 1) & 0x07);
	my $alg = (($data2[10] & 1) << 1) | ($data1[10] & 1) | 0x4;
	print $ofh pack("C4", (0, 0, 0, 0x20));
	print $ofh pack("a16", $name);
	print $ofh pack("C12", ($fb, $alg, 0, 0, 0, 0, $lfo, 0, 0, 0, 0, 0));
	
	for (my $op=0; $op<2; $op++) {
		my @outop = &readop($op, @data1);
		print $ofh pack("C24", @outop);
	}
	for (my $op=0; $op<2; $op++) {
		my @outop = &readop($op, @data2);
		print $ofh pack("C24", @outop);
	}

}
exit 0;

sub readop
{
	my $op = shift(@_);
	my @data = @_;
	my $mul = ($data[0 + $op] & 0xf);
	my $am = ($data[0 + $op] & 0x80) >> 7;
	my $vib = ($data[0 + $op] & 0x40) >> 6;
	my $egt = ($data[0 + $op] & 0x20) >> 5;
	my $ksr = ($data[0 + $op] & 0x10) >> 4;

	my $ksl = ($data[2 + $op] & 0xc0) >> 6;
	my $tl = ($data[2 + $op] & 0x3f);

	my $ar = ($data[4 + $op] & 0xf0) >> 4;
	my $dr = ($data[4 + $op] & 0x0f);
	my $sl = ($data[6 + $op] & 0xf0) >> 4;
	my $rr = ($data[6 + $op] & 0x0f);

	my $ws = ($data[8 + $op] & 0x07);
	return ($ar, $dr, $sl, ($egt ? 0 : $rr), $rr, 4, $tl, 0, 0, $ksl, $ksr, $ws,
		      $am, $vib, 0, 0, 0, 0, 0, 0, $mul, 0, 0, 0);
}

sub getbyte
{
  my ($fh) = @_;
  my $ret = 0;
  read($fh, $ret, 1);
  return ord($ret);
}
