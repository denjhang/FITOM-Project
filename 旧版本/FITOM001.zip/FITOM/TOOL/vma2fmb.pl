#!/usr/bin/perl
use strict;

my $infile = shift(@ARGV);
my $outfile = shift(@ARGV);

$infile ne '' or die;
$outfile ne '' or die;

my ($ifh, $ofh);
open ($ifh, "<$infile") or die "$infile";
open ($ofh, ">$outfile") or die;
binmode($ifh);
#binmode($ofh);

my @name = ();
my $buf = "";

for (my $i=0; $i<128; $i++) {
	$buf = "";
	read ($ifh, $buf, 8);
	read ($ifh, $buf, 8);
	push(@name, $buf);
}
read ($ifh, $buf, 8);
for (my $i=0; $i<128; $i++) {
	$buf = "";
	&getbyte($ifh);	#dummy
	my $bank = &getbyte($ifh);	#bank
	my $inst = &getbyte($ifh);	#inst
	$buf = &getbyte($ifh);	#LFO|FB|ALG
	my $lfo = ($buf & 0xc0) >> 6;
	my $fb = ($buf & 0x38) >> 3;
	my $alg = ($buf & 0x07);
	&getbyte($ifh);	#dummy
	print $ofh pack("C4", (0, 0, 0, 0x20));
	print $ofh pack("a16", $name[$i]);
	print $ofh pack("C12", ($fb, $alg, 0, 0, 0, 0, $lfo, 0, 0, 0, 0, 0));
	for (my $op=0; $op<4; $op++) {
		$buf = &getbyte($ifh);	#MULT|VIB|EGT|SUS|KSR
		my $mul = ($buf & 0xf0) >> 4;
		my $vib = ($buf & 0x08) >> 3;
		my $egt = ($buf & 0x04) >> 2;
		my $sus = ($buf & 0x02) >> 1;
		my $ksr = ($buf & 0x01);
		$buf = &getbyte($ifh);	#RR|DR
		my $rr = ($buf & 0xf0) >> 4;
		my $dr = ($buf & 0x0f);
		$buf = &getbyte($ifh);	#AR|SL
		my $ar = ($buf & 0xf0) >> 4;
		my $sl = ($buf & 0x0f);
		$buf = &getbyte($ifh);	#TL|KSL
		my $tl = ($buf & 0xfc) >> 2;
		my $ksl = ($buf & 0x03);
		$buf = &getbyte($ifh);	#DVB|DAM|AM|WS
		my $dvb = ($buf & 0xc0) >> 6;
		my $dam = ($buf & 0x30) >> 4;
		my $am = ($buf & 0x08) >> 3;
		my $ws = ($buf & 0x07);
		print $ofh pack("C24", ($ar, $dr, $sl, ($egt ? 0 : $rr), $rr, 4, $tl, 0, 0, $ksl, $ksr, $ws,
		      $am, $vib, 0, 0, 0, 0, 0, 0, $mul, 0, 0, 0));
	}
	&getbyte($ifh);	#dummy
}
exit 0;

sub getbyte
{
  my ($fh) = @_;
  my $ret = 0;
  read($fh, $ret, 1);
  return ord($ret);
}
