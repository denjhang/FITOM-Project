#!/bin/perl

use strict;

my $infile = shift(@ARGV);
my $outfile = shift(@ARGV);

$infile ne '' or die;
$outfile ne '' or die;

my ($ifh, $sfh, $ofh);
open ($ifh, "<$infile") or die;
open ($ofh, ">$outfile") or die;
binmode($ifh);

while (!eof($ifh)) {
	my $buf;
	read($ifh, $buf, 128);
	print $ofh join(",", unpack("C4a16C12C24C24C24C24", $buf)) . "\n";
}

close($ifh);
close($ofh);

exit;
