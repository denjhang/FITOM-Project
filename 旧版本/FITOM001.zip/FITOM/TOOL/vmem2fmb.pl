#!/usr/bin/perl
use strict;

my $infile = shift(@ARGV);
my $outfile = shift(@ARGV);

$infile ne '' or die;
$outfile ne '' or die;

my ($ifh, $ofh);
open ($ifh, "<$infile") or die;
open ($ofh, ">$outfile") or die;
binmode($ifh);
binmode($ofh);

my $ich;
# Header comparison
$ich = getbyte($ifh); printf("%02X\n", $ich); $ich == 0xf0 or die; # Status
$ich = getbyte($ifh); printf("%02X\n", $ich); $ich == 0x43 or die; # ID
$ich = getbyte($ifh); printf("%02X\n", $ich); ($ich & 0xf0) == 0x00 or die; # Sub Status
$ich = getbyte($ifh); printf("%02X\n", $ich); $ich == 0x04 or die; # Format No.

  my $length = getbyte($ifh);
  $length = ($length << 7) | getbyte($ifh);
  print "Length = $length\n";
  for (my $i=0; $i<($length/128); $i++) {
    my @op1 = readop($ifh);
    my @op3 = readop($ifh);
    my @op2 = readop($ifh);
    my @op4 = readop($ifh);
    $ich = getbyte($ifh);
    my $sy = ($ich >> 6);
    my $fb = ($ich >> 3) & 0x7;
    my $al = $ich & 0x7;
    my $lfs = int((getbyte($ifh) / 99.0) * 127.0);
    my $lfd = getbyte($ifh);
    my $pmd = int((getbyte($ifh) / 99.0) * 127.0);
    my $amd = int((getbyte($ifh) / 99.0) * 127.0);
    $ich = getbyte($ifh);
    my $pms = ($ich >> 4) & 0x7;
    my $ams = ($ich >> 2) & 0x3;
    my $lws = ($ich & 0x3);
    read($ifh, $ich, 11);	#skip
    read($ifh, $ich, 10);
    my $name = $ich;
    read($ifh, $ich, 6);	#skip
    @op1 = readop2($ifh, @op1);
    @op3 = readop2($ifh, @op3);
    @op2 = readop2($ifh, @op2);
    @op4 = readop2($ifh, @op4);
    my $rev = getbyte($ifh);
    if ($name !~ /INIT VOICE/) {
      print $ofh pack("C4", (0, 0, 0, 0x10));
      print $ofh pack("a16", $name);
      print $ofh pack("C12", ($fb, $al, $ams, $pms, $amd, $pmd, $lfs, $lws, $sy, $lfd, 0, 0));
      print $ofh pack("C24", @op1);
      print $ofh pack("C24", @op2);
      print $ofh pack("C24", @op3);
      print $ofh pack("C24", @op4);
    }
    read($ifh, $ich, 46);	#skip
  }

close($ifh);
close($ofh);
exit(0);


sub readop
{
  my ($ifh) = @_;
  my $ar = getbyte($ifh);
  my $dr = getbyte($ifh);
  my $sr = getbyte($ifh);
  my $rr = getbyte($ifh);
  my $sl = 15-getbyte($ifh);
  my $ksl = int(99 - getbyte($ifh));
  my $ich = getbyte($ifh);
  my $am = $ich >> 6;
  my $ebs = ($ich >> 3) & 0x7;
  my $tl = int(99 - getbyte($ifh));
  $ich = getbyte($ifh);
  my $mul = $ich >> 2;
  my $dt2 = $ich & 0x3;
  $ich = getbyte($ifh);
  my $ksr = $ich >> 3;
  my $dt1 = $ich & 0x7;
  return ($ar, $dr, $sl, $sr, $rr, 0, $tl, 0, 0, $ksl, $ksr, 0, $am, 0, 0, 0, 0, 0, 0, 0, $mul, $dt1, $dt2, 0);
}

sub readop2
{
  my ($ifh, @op) = @_;
  my $ich = getbyte($ifh);
  my $egs = $ich >> 4;
  my $fix = ($ich >> 3) & 1;
  my $fxr = $ich & 7;
  $ich = getbyte($ifh);
  my $osw = $ich >> 4;
  my $oft = $ich & 0xf;
  return ($op[0], $op[1], $op[2], $op[3], $op[4], 4, $op[6], $op[7],
          $egs, $op[9], $op[10], $osw, $op[12], $op[13], $op[14], $op[15],
          $op[16], $op[17], $op[18], $fix, $op[20], ($fxr?$fxr:$op[21]), $op[22], $oft);
}

sub getbyte
{
  my ($fh) = @_;
  my $ret = 0;
  read($fh, $ret, 1);
  return ord($ret);
}
