#!/usr/bin/perl
use strict;

my $infile = shift(@ARGV);
my $outfile = shift(@ARGV);

$infile ne '' or die;
$outfile ne '' or die;

my ($ifh, $ofh, $nfh);
my @name = ();

open ($nfh, "<gmname.txt") or die;
while(<$nfh>) {
	push (@name, $_);
}
close($nfh);

open ($ifh, "<$infile") or die;
open ($ofh, ">$outfile") or die;
binmode($ifh);
binmode($ofh);

for (my $inno=0; $inno<128; $inno++) {
	my $ich;
	my @op1 = ();
	my @op2 = ();
	my @op3 = ();
	my @op4 = ();
	$ich = getbyte($ifh);
	my $fb = ($ich >> 3) & 7;
	my $al = $ich & 7;

	$op1[0] = 31 - getbyte($ifh);
	$op2[0] = 31 - getbyte($ifh);
	$op3[0] = 31 - getbyte($ifh);
	$op4[0] = 31 - getbyte($ifh);
	my $opmask = getbyte($ifh) & 0xf;
	$op1[1] = 31 - getbyte($ifh);
	$op2[1] = 31 - getbyte($ifh);
	$op3[1] = 31 - getbyte($ifh);
	$op4[1] = 31 - getbyte($ifh);
	my $lwf = getbyte($ifh) & 0xf; # lfo wave form
	$op1[3] = 31 - getbyte($ifh);
	$op2[3] = 31 - getbyte($ifh);
	$op3[3] = 31 - getbyte($ifh);
	$op4[3] = 31 - getbyte($ifh);
	my $lfodelay = getbyte($ifh) & 0xff;
	$op1[4] = 15 - getbyte($ifh);
	$op2[4] = 15 - getbyte($ifh);
	$op3[4] = 15 - getbyte($ifh);
	$op4[4] = 15 - getbyte($ifh);
	my $lfs = getbyte($ifh) & 0xff; # lfo speed
	$op1[2] = 15 - getbyte($ifh);
	$op2[2] = 15 - getbyte($ifh);
	$op3[2] = 15 - getbyte($ifh);
	$op4[2] = 15 - getbyte($ifh);
	my $pmd = getbyte($ifh) + 0; # pmd
	$op1[6] = 127 - getbyte($ifh);
	$op2[6] = 127 - getbyte($ifh);
	$op3[6] = 127 - getbyte($ifh);
	$op4[6] = 127 - getbyte($ifh);
	my $amd = getbyte($ifh) + 0; # amd
	$op1[10] = getbyte($ifh);
	$op2[10] = getbyte($ifh);
	$op3[10] = getbyte($ifh);
	$op4[10] = getbyte($ifh);
	my $pms = getbyte($ifh) & 0xf; #pms
	$op1[20] = getbyte($ifh);
	$op2[20] = getbyte($ifh);
	$op3[20] = getbyte($ifh);
	$op4[20] = getbyte($ifh);
	getbyte($ifh);
	$op1[21] = getbyte($ifh);
	$op2[21] = getbyte($ifh);
	$op3[21] = getbyte($ifh);
	$op4[21] = getbyte($ifh);
	getbyte($ifh);
	$op1[12] = getbyte($ifh) != 0;
	$op2[12] = getbyte($ifh) != 0;
	$op3[12] = getbyte($ifh) != 0;
	$op4[12] = getbyte($ifh) != 0;
	
	#TL adjustment
	if (($al&7) < 4) {
		$op4[6] = 0;
	} elsif (($al&7) == 4) {
		if ($op2[6] > $op4[6]) { $op2[6] -= $op4[6]; $op4[6] = 0; }
		else { $op4[6] -= $op2[6]; $op2[6] = 0; }
	} elsif (($al&7) <= 6) {
		while ($op2[6] && $op3[6] && $op4[6]) {
			$op2[6]--; $op3[6]--; $op4[6]--;
		}
	} elsif (($al&7) == 7) {
		while ($op1[6] && $op2[6] && $op3[6] && $op4[6]) {
			$op1[6]--; $op2[6]--; $op3[6]--; $op4[6]--;
		}
	}
		
	read($ifh, $ich, 14);
	print $ofh pack("C4", (0, 0, 0, 0x10));
	print $ofh pack("a16", $name[$inno]);
	print $ofh pack("C12", ($fb, $al, 0, $pms, $amd, $pmd, $lfs, $lwf, ($lfodelay!=0), $lfodelay, 0, 0));
	print $ofh pack("C24", @op1);
	print $ofh pack("C24", @op2);
	print $ofh pack("C24", @op3);
	print $ofh pack("C24", @op4);
}
close($ifh);
close($ofh);
exit(0);

sub getbyte
{
  my ($fh) = @_;
  my $ret = 0;
  read($fh, $ret, 1);
  return ord($ret);
}
