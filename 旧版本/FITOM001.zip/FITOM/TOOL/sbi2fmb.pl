#!/usr/bin/perl
use strict;

my $infile = shift(@ARGV);
my $outfile = shift(@ARGV);

$infile ne '' or die;
$outfile ne '' or die;

my ($ifh, $ofh);
open ($ifh, "<$infile") or die "$infile";
open ($ofh, ">$outfile") or die;
binmode($ifh);
#binmode($ofh);

my $buf = "";

for (my $i=0; $i<128; $i++) {
	$buf = "";
	read ($ifh, $buf, 4); #SBI[EOF] or 2OP[EOF]
	read ($ifh, $buf, 25);
	my $name = $buf;
	read ($ifh, $buf, 7); #extension
	read ($ifh, $buf, 16); #data
	my @data = unpack("C16", $buf);
	my $lfo = 0;
	my $fb = $data[10] >> 1;
	my $alg = $data[10] & 1;
	print $ofh pack("C4", (0, 0, 0, 0x20));
	print $ofh pack("a16", $name);
	print $ofh pack("C12", ($fb, $alg, 0, 0, 0, 0, $lfo, 0, 0, 0, 0, 0));
	for (my $op=0; $op<2; $op++) {
		my @outop = &readop($op, @data);
		print $ofh pack("C24", @outop);
	}
	print $ofh pack("C48", 0);
}
exit 0;

sub readop
{
	my $op = shift(@_);
	my @data = @_;
	my $mul = ($data[0 + $op] & 0xf);
	my $am = ($data[0 + $op] & 0x80) >> 7;
	my $vib = ($data[0 + $op] & 0x40) >> 6;
	my $egt = ($data[0 + $op] & 0x20) >> 5;
	my $ksr = ($data[0 + $op] & 0x10) >> 4;

	my $ksl = ($data[2 + $op] & 0xc0) >> 6;
	my $tl = ($data[2 + $op] & 0x3f);

	my $ar = ($data[4 + $op] & 0xf0) >> 4;
	my $dr = ($data[4 + $op] & 0x0f);
	my $sl = ($data[6 + $op] & 0xf0) >> 4;
	my $rr = ($data[6 + $op] & 0x0f);

	my $ws = ($data[8 + $op] & 0x07);
	return ($ar, $dr, $sl, ($egt ? 0 : $rr), $rr, 4, $tl, 0, 0, $ksl, $ksr, $ws,
		      $am, $vib, 0, 0, 0, 0, 0, 0, $mul, 0, 0, 0);
}

sub getbyte
{
  my ($fh) = @_;
  my $ret = 0;
  read($fh, $ret, 1);
  return ord($ret);
}
