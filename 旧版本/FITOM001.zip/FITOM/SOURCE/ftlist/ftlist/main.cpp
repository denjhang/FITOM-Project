#include <stdio.h>
#include <Windows.h>
#include "ftd2xx.h"

int main(int argc, char* argv[])
{
	DWORD numDev;
	FT_STATUS res = FT_CreateDeviceInfoList(&numDev);
	if (res == FT_OK) {
		if (numDev) {
			FT_DEVICE_LIST_INFO_NODE* pDest = new FT_DEVICE_LIST_INFO_NODE[numDev];
			res = FT_GetDeviceInfoList(pDest, &numDev);
			if (res == FT_OK) {
				for (int i=0; i<(int)numDev; i++) {
					printf("Device:%02i\n", i);
					printf(" Type=%08X\n", pDest[i].Type);
					printf(" ID=%08X\n", pDest[i].ID);
					printf(" Location=%08X\n", pDest[i].LocId);
					printf(" Description=%-64s\n", pDest[i].Description);
					printf(" SerialNo.=%-16s\n\n", pDest[i].SerialNumber);
				}
			}
		} else {
			printf("No FT Device found.\n");
		}
	} else {
		printf("Device Error occurred.");
	}
	return 0;
}
