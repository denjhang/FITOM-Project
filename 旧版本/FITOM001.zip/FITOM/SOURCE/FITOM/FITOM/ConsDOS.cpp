#include "Console.h"
#include <conio.h>

extern "C" {
#include <hcons.h>
};

#ifdef putc
#undef putc
#endif

CConsole::CConsole()
{
	hc_init(0);
	hc_txon();
}


CConsole::~CConsole()
{
	hc_end();
}

void CConsole::cls()
{
	hc_cls();
}

void CConsole::puts(int x, int y, CONSATTR attr, char* str, int max)
{
	hc_putsn(x, y, attr|1, str, max);
}

void CConsole::putc(int x, int y, CONSATTR attr, int c)
{
	hc_putc(x, y, attr|1, c);
}

int CConsole::inkey()
{
	int res = 0;
	_asm mov ah,01h
	_asm int 18h
	_asm mov bl,bh
	_asm xor bh,bh
	_asm mov res,bx
	return res;
}

int CConsole::getch()
{
	int res = 0;
	_asm xor ah,ah
	_asm int 18h
	_asm xor ah,al
	_asm xor al,ah
	_asm xor ah,al
	_asm mov res,ax

	return res;
}
