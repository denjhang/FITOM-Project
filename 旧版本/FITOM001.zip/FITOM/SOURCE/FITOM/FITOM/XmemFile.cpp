#include "STDAFX.H"
#include "XmemFile.h"

CXmemFile::CXmemFile(void) : actsize(0), pos(0)
{
}

CXmemFile::CXmemFile(UINT32 size) : actsize(0), pos(0)
{
	if (Alloc(size) < 0) {
		printf("Fatal error: XMS allocation failed\n");
		_exit(-1);
	} 
}

CXmemFile::~CXmemFile(void)
{
	Free();
}

UINT32 CXmemFile::GetSize()
{
	return (actsize);
}