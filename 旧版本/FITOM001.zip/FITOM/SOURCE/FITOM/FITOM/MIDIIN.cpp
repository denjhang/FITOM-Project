#include "stdafx.h"
#include "MIDIIN.h"

#ifdef _DOS
extern "C" {
#include <RS232C.h>
};
#include "Port.h"

#define TIMEOUT 1000

CMPU401MidiIn::CMPU401MidiIn(UINT16 dtport, UINT16 stport)
{
	portd = dtport;
	ports = stport;

		int flag = 0;
	int limit = TIMEOUT;
	int limit2 = TIMEOUT;	
	while(IsOutput() && limit--){}
	limit = TIMEOUT;
	SetStat(0xFF);
	do {
		while(!IsInput() && limit-->0){}
		if (GetData() == 0xFE) { flag = 1; }
	} while (!flag && limit2-->0);

	limit = TIMEOUT;
	while(IsOutput() && limit-->0){}
	flag = 0;
	SetStat(0x3F);
	limit = TIMEOUT;
	limit2 = TIMEOUT;
	do {
		while(!IsInput() && limit-->0){}
		if (GetData() == 0xFE) { flag = 1; }
	} while (!flag && limit2-->0);
	sprintf(desc, "MPU-401 UART(%04X,%04X)", dtport, stport);
}

CMPU401MidiIn::~CMPU401MidiIn()
{
}

void CMPU401MidiIn::SetStat(UINT8 stat)
{
	outp(ports, stat);
}

UINT8 CMPU401MidiIn::GetStat()
{
	return inp(ports);
}

UINT8 CMPU401MidiIn::IsInput(void)
{
	UINT8 ret = (GetStat() & 0x80);
    return !ret;
}

UINT8 CMPU401MidiIn::IsOutput(void)
{
    return(GetStat() & 0x40);
}

UINT8 CMPU401MidiIn::GetData(void)
{
	return(inp(portd));
}

CRSMidiIn::CRSMidiIn()
{
	rs_init(1024, 1024);
	rs_status();
	char* bps;
	if(!((rs_status() & 128)>>7)){
		rs_open_RS(0x45, BIT_8 | PARITY_NONE | STOP_10);
					/* ����I�[�v�� RS/CS����*/
					/* 8�ޯ� ���è�Ȃ� �į���ޯ� 1 */
		//printf("System Clock 5MHz\nOpen 30720bps\n");
		bps = "30720bps";
	}else{
		rs_open_RS(0x84, BIT_8 | PARITY_NONE | STOP_10);
		//printf("System Clock 8MHz\nOpen 31200bps\n");
		bps = "31200bps";
	}
	rs_signal(0x01);
	rs_signal(0x04);
	sprintf(desc, "PC-9801 RS-MIDI(%s)", bps);
}

CRSMidiIn::~CRSMidiIn()
{
	rs_flush();                     /* ���M�o�b�t�@����ɂȂ�܂ő҂� */
	rs_close();                     /* ����N���[�Y */
	rs_end();                       /* �I������ */
}

UINT8 CRSMidiIn::IsOutput()
{
	return 0;
}

UINT8 CRSMidiIn::IsInput()
{
	return (Recv_len>0);
}

UINT8 CRSMidiIn::GetData()
{
	return rs_getc();
}

#endif

CYMZ263MidiIn::CYMZ263MidiIn(CPort* devport) : port(devport)
{
	sprintf(desc, "YMZ263 UART");
}

CYMZ263MidiIn::~CYMZ263MidiIn()
{
}

UINT8 CYMZ263MidiIn::GetData()
{
	return port->read(0x0e, 1);
}

UINT8 CYMZ263MidiIn::IsInput()
{
	return (port->status() & 0x04);
}


#ifdef _WIN32
#include <MMSystem.h>

CW32MidiIn::CW32MidiIn(char* name)
{
	rpt = wpt = 0;
	MIDIINCAPS mic;
	int dev = -1;
	int numdevs = midiInGetNumDevs();
	for (int i=0; i<numdevs; i++) {
		midiInGetDevCaps(i, &mic, sizeof(mic));
		if (strcmp(name, mic.szPname) == 0) {
			dev = i;
			break;
		}
	}
	if (dev >= 0) {
		strncpy(desc, mic.szPname, 32);
		midiInOpen(&hIn, dev, (DWORD_PTR)CW32MidiIn::MidiInProc, (DWORD_PTR)this, CALLBACK_FUNCTION);
		midiInPrepareHeader(hIn, &mhdr, sizeof(MIDIHDR));
		midiInStart(hIn);
	}
}

CW32MidiIn::~CW32MidiIn()
{
	midiInStop(hIn);
	midiInReset(hIn);
	midiInClose(hIn);
}

UINT8 CW32MidiIn::IsInput(void)
{
    return (wpt>rpt);
}

UINT8 CW32MidiIn::GetData(void)
{
	UINT8 ret = 0;
	if (wpt > rpt) {
		ret = buf[rpt++];
	}
	if (rpt == wpt) {
		rpt = wpt = 0;
	}
	return ret;
}

void CALLBACK CW32MidiIn::MidiInProc(HMIDIIN hMidiIn, UINT wMsg, DWORD dwInstance, DWORD dwParam1, DWORD dwParam2)
{
	switch(wMsg) {
	case MIM_DATA:
		{
			CW32MidiIn* mpu = (CW32MidiIn*)dwInstance;
			if (mpu && mpu->wpt < 1024) {
				mpu->buf[mpu->wpt++] = LOBYTE(LOWORD(dwParam1));
				mpu->buf[mpu->wpt++] = HIBYTE(LOWORD(dwParam1));
				mpu->buf[mpu->wpt++] = LOBYTE(HIWORD(dwParam1));
			}
		}
		break;
	case MIM_OPEN:		// ���̓f�o�C�X �I�[�v�� �R�[���o�b�N
		printf("*** MIM_OPEN ***\n");
		break;
	case MIM_CLOSE:		// ���̓f�o�C�X���N���[�Y
		printf("*** MIM_CLOSE ***\n");
		break;
	case MIM_LONGDATA:	// ���̓o�b�t�@�̃R�[���o�b�N
		printf("*** MIM_LONGDATA ***\n");
		break;
	case MIM_ERROR:		// ���̓f�o�C�X �G���[ �R�[���o�b�N
		printf("*** MIM_ERROR ***\n");
		break;
	case MIM_LONGERROR:	// �����ȃV�X�e�� �G�N�X�N���[�V�u ���b�Z�[�W�ɑ΂���R�[���o�b�N
		printf("*** MIM_LONGERROR ***\n");
		break;
	case MIM_MOREDATA:	// ???
		printf("*** MIM_MOREDATA ***\n");
		break;
	default:
		printf("*** (unknown message) ***\n");
		break;
	}
}

CW32RsMidi::CW32RsMidi(char* name)
{
	hCom = CreateFile(name, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL); // �V���A���|�[�g���J��
	GetCommState(hCom, &dcb); // ���݂̐ݒ�l��ǂݍ���

	dcb.BaudRate = 31500; // ���x
	dcb.ByteSize = 8; // �f�[�^��
	dcb.Parity = NOPARITY; // �p���e�B
	dcb.StopBits = ONESTOPBIT; // �X�g�b�v�r�b�g��
	dcb.fOutxCtsFlow = FALSE; // ���M��CTS�t���[
	dcb.fRtsControl = FALSE; // RTS�t���[

	SetCommState(hCom, &dcb); // �ύX�����ݒ�l����������
	sprintf(desc, "%1 RS-MIDI(31500bps)", name);
}

CW32RsMidi::~CW32RsMidi()
{
	CloseHandle(hCom);
}

UINT8 CW32RsMidi::IsInput()
{
	DWORD errors;
	COMSTAT comStat;
	ClearCommError(hCom, &errors, &comStat);
	return (comStat.cbInQue > 0);
}

UINT8 CW32RsMidi::GetData()
{
	UINT8 ret = 0;
	DWORD numberOfPut;
	ReadFile(hCom, &ret, sizeof(ret), &numberOfPut, NULL); // �o�b�t�@�����荞��
	return ret;
}

#endif
