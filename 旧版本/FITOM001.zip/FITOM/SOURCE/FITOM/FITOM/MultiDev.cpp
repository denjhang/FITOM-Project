#include "STDAFX.H"
#include "MultiDev.h"

CMultiDevice::CMultiDevice(CSoundDevice* chip1, CSoundDevice* chip2, UINT8 fsamp, CPort* pt)
	: CSoundDevice(0, 0, fsamp, pt), numchips(0), chips(NULL)
{
	if (chip1 && chip2) {
		AddDevice(chip1);
		AddDevice(chip2);
		device = chip1->GetDevice();
	}
}

void CMultiDevice::AddDevice(CSoundDevice* chip)
{
	CSoundDevicePtr* newchips = new CSoundDevicePtr[numchips+1];
	if (chips) {
		for (int i=0; i<numchips; i++) {
			newchips[i] = chips[i];
		}
		delete [] chips;
	}
	chips = newchips;
	newchips[numchips] = chip;
	numchips++;
}

void CMultiDevice::SetMasterVolume(UINT8 vol, int update)
{
	for (int i=0; i<numchips; i++) {
		chips[i]->SetMasterVolume(vol, update);
	}
}

void CMultiDevice::ResetVoice(CMidiCh* pch, FMVOICE* voice, int update)
{
	for (int i=0; i<numchips; i++) {
		chips[i]->ResetVoice(pch, voice, update);
	}
}

void CMultiDevice::TimerCallBack(UINT32 tick)
{
	for (int i=0; i<numchips; i++) {
		chips[i]->TimerCallBack(tick);
	}
}

void CMultiDevice::PollingCallBack()
{
	for (int i=0; i<numchips; i++) {
		chips[i]->PollingCallBack();
	}
}

