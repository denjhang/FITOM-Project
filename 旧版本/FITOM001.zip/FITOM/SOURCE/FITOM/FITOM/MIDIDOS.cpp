#include "stdafx.h"
#include "MIDIDEV.h"

extern "C" {
#include <RS232C.h>
};
#include "Port.h"

#define TIMEOUT 1000

CMPU401::CMPU401(UINT16 dtport, UINT16 stport)
{
	portd = dtport;
	ports = stport;

		int flag = 0;
	int limit = TIMEOUT;
	int limit2 = TIMEOUT;	
	while(IsTxBusy() && limit--){}
	limit = TIMEOUT;
	SetStat(0xFF);
	do {
		while(!IsReceived() && limit-->0){}
		if (Read() == 0xFE) { flag = 1; }
	} while (!flag && limit2-->0);

	limit = TIMEOUT;
	while(IsTxBusy() && limit-->0){}
	flag = 0;
	SetStat(0x3F);
	limit = TIMEOUT;
	limit2 = TIMEOUT;
	do {
		while(!IsReceived() && limit-->0){}
		if (Read() == 0xFE) { flag = 1; }
	} while (!flag && limit2-->0);
	sprintf(desc, "MPU-401 UART(%04X,%04X)", dtport, stport);
}

CMPU401::~CMPU401()
{
}

void CMPU401::SetStat(UINT8 stat)
{
	outp(ports, stat);
}

UINT8 CMPU401::GetStat()
{
	return inp(ports);
}

UINT8 CMPU401::IsReceived(void)
{
	UINT8 ret = (GetStat() & 0x80);
    return !ret;
}

UINT8 CMPU401::IsTxBusy(void)
{
    return(GetStat() & 0x40);
}

UINT8 CMPU401::Read(void)
{
	return(inp(portd));
}

void CMPU401::Send(UINT8 data)
{
	int limit = TIMEOUT;
	while(IsTxBusy() && limit-->0){}
	outp(portd, data);
}

void CMPU401::Send(void* msg, size_t len)
{
	for (size_t i=0; i<len; i++) {
		Send(((char*)msg)[i]);
	}
}

CRSMidi::CRSMidi()
{
	rs_init(1024, 1024);
	rs_status();
	char* bps;
	if(!((rs_status() & 128)>>7)){
		rs_open_RS(0x45, BIT_8 | PARITY_NONE | STOP_10);
					/* ����I�[�v�� RS/CS����*/
					/* 8�ޯ� ���è�Ȃ� �į���ޯ� 1 */
		//printf("System Clock 5MHz\nOpen 30720bps\n");
		bps = "30720bps";
	}else{
		rs_open_RS(0x84, BIT_8 | PARITY_NONE | STOP_10);
		//printf("System Clock 8MHz\nOpen 31200bps\n");
		bps = "31200bps";
	}
	rs_signal(0x01);
	rs_signal(0x04);
	sprintf(desc, "PC-9801 RS-MIDI(%s)", bps);
}

CRSMidi::~CRSMidi()
{
	rs_flush();                     /* ���M�o�b�t�@����ɂȂ�܂ő҂� */
	rs_close();                     /* ����N���[�Y */
	rs_end();                       /* �I������ */
}

UINT8 CRSMidi::IsTxBusy()
{
	return 0;
}

UINT8 CRSMidi::IsReceived()
{
	return (Recv_len>0);
}

UINT8 CRSMidi::Read()
{
	return rs_getc();
}

void CRSMidi::Send(UINT8 data)
{
	rs_putc(data);
}

void CRSMidi::Send(void* msg, size_t len)
{
	for (size_t i=0; i<len; i++) {
		Send(((char*)msg)[i]);
	}
}

CYMZ263Midi::CYMZ263Midi(CPort* devport) : port(devport)
{
	sprintf(desc, "YMZ263 UART");
}

CYMZ263Midi::~CYMZ263Midi()
{
}

UINT8 CYMZ263Midi::Read()
{
	return port->read(0x0e, 1);
}

UINT8 CYMZ263Midi::IsReceived()
{
	return (port->status() & 0x04);
}

UINT8 CYMZ263Midi::IsTxBusy()
{
	return (port->status() & 0x08);
}

void CYMZ263Midi::Send(UINT8 data)
{
	while(IsTxBusy()){}
	port->write(0x0e, data, 1);
}

void CYMZ263Midi::Send(void* msg, size_t len)
{
	for (size_t i=0; i<len; i++) {
		Send(((char*)msg)[i]);
	}
}
