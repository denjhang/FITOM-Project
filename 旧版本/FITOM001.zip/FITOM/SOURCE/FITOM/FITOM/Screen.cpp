#include "STDAFX.H"
#include "Screen.h"
#include "Console.h"
#include "SoundDev.h"
#include "MIDIDEV.h"
#include "MIDI.h"
#include <conio.h>

IScreen::IScreen(CFITOM* parent) : Parent(parent)
{
}

IScreen::~IScreen(void)
{
}

CScreen::CScreen(CFITOM* parent) : IScreen(parent)
{
}

int CScreen::Modal(int flag)
{
	int res = 0;
	int ch;
	//Show(flag);
	do {
		while(!Parent->GetConsole()->inkey()) {
			if (Parent->PollingCallBack()) {
				Parent->SetRedraw(1);
			}
		}
		ch = Parent->GetConsole()->getch();
		res = KeyOn(ch);
		if (res) {
			Parent->SetRedraw(1);
		}
	} while (res > -1);
	return ch;
}

CMainScreen::CMainScreen(CFITOM* parent) : CScreen(parent), currentscreen(0), scrs(0)
{
	scr[scrs++] = new CMidiMon(Parent);
	scr[scrs++] = new CDeviceMon(Parent);
	scr[scrs++] = new CRegisterMon(Parent);
	scr[scrs++] = new CVoiceEdit(Parent);
	scr[scrs++] = new CNullScreen(Parent);
}

int CMainScreen::Modal(int flag)
{
	do {
		//Show(flag);
	} while (KeyOn(scr[currentscreen]->Modal(flag)) != -1);
	return 0;
}

int CMainScreen::Show(int flag)
{
	if (Parent->GetRedraw()) {
		Parent->SetRedraw(0);
		return scr[currentscreen]->Show(flag);
	}
	return 0;
}

int CMainScreen::KeyOn(int key)
{
	int ret = 0;
	char tmp[6];
	CConsole* Console = Parent->GetConsole();
	sprintf(tmp, "%04X", key);
	Console->puts(75, 0, CConsole::CA_GREEN, tmp, strlen(tmp));
	switch (key) {
	case KEY_F1://F1
		Console->cls();
		currentscreen = 0;
		//ret = scr[currentscreen]->Modal(0);
		break;
	case KEY_F2://F2
		Console->cls();
		currentscreen = 1;
		//ret = scr[currentscreen]->Modal(0);
		break;
	case KEY_F3://F3
		Console->cls();
		currentscreen = 2;
		break;
	case KEY_F4://F4
		Console->cls();
		currentscreen = 3;
		break;
	case KEY_F5://F5
		Console->cls();
		currentscreen = 4;
		break;
	case KEY_HOME://HOME_CLR
		Parent->AllNoteOff();
		Parent->ResetAllCtrl();
		ret = 0;
		break;
	case KEY_ESC:
		ret = -1;
		break;
	}
	return ret;
}

CMidiMon::CMidiMon(CFITOM* parent) : CScreen(parent), curpage(0), hcur(0), vcur(0)
{
}

const char* NoteName[] = {
	"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B",
};

int CMidiMon::Show(int flag)
{
	int x = 2, y = 2;
	char tmp[1024];
	CConsole* Console = Parent->GetConsole();
	CMidiIn* mpu = Parent->GetMidiIn(curpage);
	CMidiInst* midi = Parent->GetMidiInst(curpage);
	static int xtab[] = {4, 7, 24, 28, 33, 37};

	sprintf(tmp, "MIDI Input monitor %i/%i", curpage+1, Parent->GetMidiInputs());
	Console->puts(0, 0, (CConsole::CONSATTR)(CConsole::CA_YELLOW|CConsole::CA_REV), tmp, strlen(tmp));
	sprintf(tmp, "IN%i:%s", curpage+1, mpu->GetDescriptor());
	Console->puts(x, y++, CConsole::CA_WHITE, tmp, strlen(tmp));
	sprintf(tmp, "  CH DEV        NOTE  Pan Vol  Bank:Prog.Chg                ");
	Console->puts(x, y++, (CConsole::CONSATTR)(CConsole::CA_CYAN|CConsole::CA_REV), tmp, strlen(tmp));
	x+=2;
	for (int j=0; j<16; j++) {
		CMidiCh* pch = midi->GetMidiCh(j);
		UINT8 notenum = pch ? pch->GetLastNote() : 0xff;
		char note[6];
		if (notenum < 128) {
			sprintf(note, "%s%i", NoteName[notenum % 12], (notenum/12-2));
		} else {
			strcpy(note, "----");
		}
		char prog[17];
		memset(prog, 0x20, 16);
		UINT32 progid = pch ? pch->GetLastProg() : 0;
		UINT8 vtype = UINT8(progid >> 24);
		UINT8 bank = pch ? pch->GetBankNo() : 0;
		UINT8 pnum = pch ? pch->GetProgramNo() : 0;
		UINT8 pan = pch ? pch->GetPanpot() : 64;
		UINT8 vol = pch ? pch->GetTrackVolume() : 0;
		UINT8 devid = pch ? pch->GetDeviceID() : 0xff;
		FMVOICE vtbl;
		memcpy(vtbl.name, "----------------", 16);
		Parent->GetVoice(&vtbl, devid, bank, pnum);
		memcpy(prog, vtbl.name, 16);
		prog[16] = '\0';
		const char* devname = "----";
		if (pch) {
			if (pch->IsInst()) { devname = Parent->GetDeviceNameFromID(pch->GetDeviceID()); }
			if (pch->IsRhythm()) { devname = "RHYTHM"; }
			if (pch->IsThru()) {
				char thruch[16];
				sprintf(thruch, "THRU%1i:%02i", ((CThruCh*)pch)->GetOutPort(), ((CThruCh*)pch)->GetOutCh()+1);
				devname = thruch;
			}
		}
		sprintf(tmp, "%2i:%-9s  %-4s  %3i %3i  %3i:%3i:%-16s", j+1, devname, note, pan, vol, bank, pnum, prog);
		Console->puts(x, y++, CConsole::CA_WHITE, tmp, strlen(tmp));
		if (j == vcur) {
			sprintf(tmp, "%2i", vcur+1);
			Console->puts(4, 4+vcur, (CConsole::CONSATTR)(CConsole::CA_WHITE|CConsole::CA_REV), tmp, strlen(tmp));
			if (hcur) {
				switch (hcur) {
				case 1://Device
					sprintf(tmp, "%-9s", devname);
					break;
				case 2://Pan
					sprintf(tmp, "%3i", pan);
					break;
				case 3://Volume
					sprintf(tmp, "%3i", vol);
					break;
				case 4://Bank
					sprintf(tmp, "%3i", bank);
					break;
				case 5://Prog
					sprintf(tmp, "%3i", pnum);
					break;
				}
				Console->puts(xtab[hcur], 4+vcur, (CConsole::CONSATTR)(CConsole::CA_YELLOW|CConsole::CA_REV), tmp, strlen(tmp));
			}
		}
	}
	return 0;
}

int CMidiMon::KeyOn(int ch)
{
	UINT8 maxmpu = Parent->GetMidiInputs();
	CMidiInst* midi = Parent->GetMidiInst(curpage);
	CMidiCh* pch = midi->GetMidiCh(vcur);
	SINT8 diff = 0;
	int ret = 0;
	switch(ch) {
	case KEY_UP://up
		if (vcur) {
			vcur--;
			ret = 1;
		}
		break;
	case KEY_PAGEUP://pageup
		if (curpage) {
			curpage--;
			ret = 1;
			Parent->GetConsole()->cls();
		}
		break;
	case KEY_PAGEDN://pagedown
		if ((curpage+1)<maxmpu) {
			curpage++;
			ret = 1;
			Parent->GetConsole()->cls();
		}
		break;
	case KEY_DOWN://down
		if (vcur < 15) {
			vcur++;
			ret = 1;
		}
		break;
	case KEY_LEFT:
		if (hcur > 0) {
			hcur--;
			ret = 1;
		}
		break;
	case KEY_RIGHT:
		if (hcur < 5) {
			hcur++;
			ret = 1;
		}
		break;
	case KEY_MINUS:
	case KEY_PLUS:
		diff = (ch==KEY_PLUS) ? 1 : -1;
		if (hcur == 1) { //Device modify
			int maxidx = Parent->GetInstDevs() + (Parent->GetMidiOutputs() * 16) + 2;
			int devidx;
			if (pch) {
				if (pch->IsInst()) {
					devidx = Parent->GetInstDeviceIndex(pch->GetDeviceID());
				} else
				if (pch->IsRhythm()) {
					devidx = maxidx - 2;
				}else
				if (pch->IsThru()) {
					devidx = ((CThruCh*)pch)->GetOutPort() * 16 + ((CThruCh*)pch)->GetOutCh() + Parent->GetInstDevs();
				}
			} else {
				devidx = maxidx - 1;
			}
			devidx += diff;
			devidx = (devidx<0) ? (maxidx-1) : devidx;
			devidx = (devidx>=maxidx) ? 0 : devidx;
			midi->Release(vcur);
			ret = 1;
			if (devidx < Parent->GetInstDevs()) {
				midi->Assign(vcur, Parent->GetInstDeviceFromIndex(devidx), 0);
			} else if (devidx == (maxidx - 2)) {
				midi->AssignRhythm(vcur);
			} else if (devidx != (maxidx - 1)) {
				devidx -= Parent->GetInstDevs();
				midi->AssignThru(vcur, (devidx%(Parent->GetMidiOutputs()*16)), devidx/(Parent->GetMidiOutputs()*16));
			}
		} else
		if (pch) {
			UINT8 vol = pch->GetTrackVolume();
			UINT32 progid = pch->GetLastProg();
			UINT8 vtype = UINT8(progid >> 24);
			UINT8 bank = pch->GetBankNo(); //UINT8(progid >> 8) & 0xff;
			UINT8 pnum = pch->GetProgramNo(); //UINT8(progid & 0xff);
			UINT8 pan = pch->GetPanpot();
			switch (hcur) {
			case 2://Pan
				pch->SetPanpot(UINT8(pan+diff)&0x7f);
				ret = 1;
				break;
			case 3://Volume
				pch->SetVolume(UINT8(vol+diff)&0x7f);
				ret = 1;
				break;
			case 4://Bank
				pch->BankSel(UINT8(bank+diff)&0x7f);
				pch->ProgChange(pnum);
				ret = 1;
				break;
			case 5://Prog
				pch->BankSel(bank);
				pch->ProgChange(UINT8(pnum+diff)&0x7f);
				ret = 1;
				break;
			}
		}
		break;
	default:
		ret = -1;
		break;
	}
	return ret;
}

CDeviceMon::CDeviceMon(CFITOM* parent) : CScreen(parent), curpage(0), hcur(0), vcur(0)
{
}

int CDeviceMon::Show(int flag)
{
	int x = 2, y = 2;
	char tmp[1024];
	CConsole* Console = Parent->GetConsole();
	CSoundDevice* dev = Parent->GetInstDeviceFromIndex(curpage);

	sprintf(tmp, "FM device monitor %i/%i", curpage+1, Parent->GetInstDevs());
	Console->puts(0, 0, (CConsole::CONSATTR)(CConsole::CA_YELLOW|CConsole::CA_REV), tmp, strlen(tmp));
	dev->GetDescriptor(tmp);
	Console->puts(x, y++, CConsole::CA_WHITE, tmp, strlen(tmp));
	sprintf(tmp, " CH  NOTE    BLK:Fnum     Bank:Prog.Chg                 ");
	Console->puts(x, y++, (CConsole::CONSATTR)(CConsole::CA_CYAN|CConsole::CA_REV), tmp, strlen(tmp));
	x+=2;
	for (int j=0; j<dev->GetAvailable(); j++) {
		UINT8 notenum = dev->GetCurrentNote(j);
		char note[6];
		if (notenum < 128) {
			sprintf(note, "%s%i", NoteName[notenum % 12], (notenum/12-2));
		} else {
			strcpy(note, "----");
		}
		char prog[17];
		UINT32 progid = dev->GetCurrentVoice(j);
		UINT8 vtype = UINT8(progid >> 24);
		UINT8 bank = UINT8(progid >> 8) & 0x7f;
		UINT8 pnum = UINT8(progid & 0x7f);
		FMVOICE vtbl;
		memcpy(vtbl.name, "----------------", 16);
		Parent->GetVoice(&vtbl, dev->GetDevice(), bank, pnum);
		memcpy(prog, vtbl.name, 16);
		prog[16] = '\0';
		ISoundDevice::FNUM fnum = dev->GetCurrentFnum(j);
		//ISoundDevice::CHATTR* attr = dev->GetChAttribute(j);
		sprintf(tmp, "%2i: %-4s    %02X:%04X     %3i:%3i %-16s", j+1, note, fnum.block, fnum.fnum, bank, pnum, prog);
		Console->puts(x, y++, CConsole::CA_WHITE, tmp, strlen(tmp));
	}
	sprintf(tmp, "%2i", vcur+1);
	Console->puts(4, 4+vcur, (CConsole::CONSATTR)(CConsole::CA_WHITE|CConsole::CA_REV), tmp, strlen(tmp));
	return 0;
}

int CDeviceMon::KeyOn(int ch)
{
	UINT8 maxdev = Parent->GetInstDevs();
	int ret = 0;
	switch(ch) {
	case KEY_UP://up
		if (vcur) {
			vcur--;
			ret = 1;
		}
		break;
	case KEY_PAGEUP://pageup
		if (curpage) {
			curpage--;
			vcur = 0;
			ret = 1;
			Parent->GetConsole()->cls();
		}
		break;
	case KEY_PAGEDN://pagedown
		if ((curpage+1)<Parent->GetInstDevs()) {
			curpage++;
			vcur = 0;
			ret = 1;
			Parent->GetConsole()->cls();
		}
		break;
	case KEY_DOWN://down
		if ((vcur+1) < Parent->GetInstDeviceFromIndex(curpage)->GetAvailable()) {
			vcur++;
			ret = 1;
		}
		break;
	default:
		ret = -1;
		break;
	}
	return ret;
}

CRegisterMon::CRegisterMon(CFITOM* parent) : CScreen(parent), curpage(0), hcur(0), vcur(0)
{
}

int CRegisterMon::Modal(int flag)
{
	return CScreen::Modal(flag);
}

int CRegisterMon::Show(int flag)
{
	int x = 2, y = 2;
	char tmp[1024];
	CConsole* Console = Parent->GetConsole();
	CSoundDevice* dev = Parent->GetInstDeviceFromIndex(curpage);

	sprintf(tmp, "Register monitor %i/%i", curpage+1, Parent->GetInstDevs());
	Console->puts(0, 0, (CConsole::CONSATTR)(CConsole::CA_YELLOW|CConsole::CA_REV), tmp, strlen(tmp));
	dev->GetDescriptor(tmp);
	Console->puts(x, y++, CConsole::CA_WHITE, tmp, strlen(tmp));
	for (int j=0; j<16; j++) {
		sprintf(tmp, "%04X", j*32);
		Console->puts(2, 4+j, CConsole::CA_WHITE, tmp, 4);
		for (int i=0; i<32; i++) {
			sprintf(tmp, "%02X", dev->GetReg(j*32+i, 0));
			Console->puts(7+i*2, 4+j, CConsole::CA_WHITE, tmp, 2);
		}
	}
	Parent->SetRedraw(1);
	return 0;
}

int CRegisterMon::KeyOn(int ch)
{
	UINT8 maxdev = Parent->GetInstDevs();
	int ret = 0;
	switch(ch) {
	case KEY_PAGEUP://pageup
		if (curpage) {
			curpage--;
			vcur = 0;
			ret = 1;
			Parent->GetConsole()->cls();
		}
		break;
	case KEY_PAGEDN://pagedown
		if ((curpage+1)<Parent->GetInstDevs()) {
			curpage++;
			vcur = 0;
			ret = 1;
			Parent->GetConsole()->cls();
		}
		break;
	default:
		ret = -1;
		break;
	}
	return ret;
}
