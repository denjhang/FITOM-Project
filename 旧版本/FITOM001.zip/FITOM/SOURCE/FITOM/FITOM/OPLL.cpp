#include "STDAFX.H"
#include "FITOM.h"
#include "OPLL.h"
#include "MIDI.h"

#define ADDR_WAIT	6
#define DATA_WAIT	39

ISoundDevice::FNUM COPLL::RhythmFnum[3] = {	
	ISoundDevice::FNUM(2, 0x480), ISoundDevice::FNUM(2, 0x540), ISoundDevice::FNUM(0, 0x700)
};
UINT8 COPLL::RhythmReg[] = { 0x37, 0x38, 0x38, 0x37, 0x36, };
UINT8 COPLL::RhythmMapCh[] = { 7, 8, 8, 7, 6, };

UINT8 COPLL::RhythmFreq[3] = { 47, 60, 53, };

COPLL::COPLL(CPort* pt, UINT8 mode, UINT8 fsamp) :
	CSoundDevice(DEVICE_OPLL, 9, fsamp, pt), RhythmOnMap(0), RhythmOffMap(0)
{
	ops = 2;
	if (mode) {
		rhythmcap = 5;
		for (int i=6; i<9; i++) {
			EnableCh(i, 0);
		}
	}
}

void COPLL::SetVoice(UINT8 ch, FMVOICE* voice, int update)
{
	update = (voice->AL & 0x40) ? update : -1;
	CSoundDevice::SetVoice(ch, voice, update);
}

void COPLL::UpdateVoice(UINT8 ch)
{
	UINT8 tmp;
	FMVOICE* voice = GetChAttribute(ch)->GetVoice();

	UINT8 inst = 0;
	if (voice->AL & 0x40) {//Preset Instrument
		inst = voice->AL & 0xf;
	} else {//User Instrument
		for (int i=0; i<2; i++) {
			tmp = ((voice->op[i].AM & 0x1) << 7) | ((voice->op[i].VIB & 0x1) << 6) |
				(voice->op[i].SR ? 0x20: 0) | ((voice->op[i].KSR & 0x1) << 4) |
				(voice->op[i].MUL & 0x0F);
			SetReg(0 + i, tmp);
			tmp = ((voice->op[i].AR & 0xf) << 4) | (voice->op[i].DR & 0xf);
			SetReg(4 + i, tmp);
			tmp = ((voice->op[i].SL & 0xf) << 4) | ((voice->op[i].SR ? voice->op[i].SR : voice->op[i].RR) & 0xf);
			SetReg(6 + i, tmp);
		}
		tmp = ((voice->op[0].KSL & 0x3) << 6) | (voice->op[0].TL & 0x3f);
		SetReg(2, tmp);
		tmp = ((voice->op[1].KSL & 0x3) << 6) | ((voice->op[0].WS & 1) << 3) |
			((voice->op[1].WS & 1) << 4) | (voice->FB & 0x7);
		SetReg(3, tmp);
	}
	SetReg(0x30 + ch, (inst << 4) | (GetReg(0x30 + ch, 0) & 0x0f));
}

void COPLL::UpdateVolExp(UINT8 ch)
{
	CHATTR* attr = GetChAttribute(ch);
	FMVOICE* voice = attr->GetVoice();
	UINT8 evol = CalcEffectiveLevel(attr->GetEffectiveLevel(), (voice->op[1].TL << 1) | (voice->op[1].TL >> 5));
	attr->baseTL[1] = evol >> 1;
	SetReg(0x30 + ch, (GetReg(0x30 + ch, 0) & 0xf0) | (evol >> 3));
}

void COPLL::UpdateFreq(UINT8 ch, const FNUM* fnum)
{
	CHATTR* attr = GetChAttribute(ch);
	fnum = fnum ? fnum : attr->GetLastFnumber();
	SetReg(0x10 + ch, UINT8((fnum->fnum>>2) & 0xff));
	SetReg(0x20 + ch, (GetReg(0x20 + ch, 0) & 0x30) |
		(fnum->block << 1) | UINT8(fnum->fnum >> 10));
}

void COPLL::UpdateSustain(UINT8 ch)
{
	UINT8 sus = GetChAttribute(ch)->GetParent()->GetSustain() ? 0x20 : 0;
	UINT8 tmp = GetReg(0x20 + ch, 0) & 0xdf;
	SetReg(0x20 + ch, sus | tmp);
}

void COPLL::UpdateTL(UINT8 ch, UINT8 op, UINT8 lev)
{
	if (op == 0) {
		SetReg(0x2, (GetReg(2, 0) & 0xc0) | (lev >> 1));
	} else if (op == 1) {
		SetReg(0x30 + ch, (GetReg(0x30 + ch, 0) & 0xf0) | (lev >> 3));
	}
}

void COPLL::UpdateKey(UINT8 ch, UINT8 keyon)
{
	UINT8 tmp;
	FMVOICE* voice = GetChAttribute(ch)->GetVoice();

	if ((voice->ID >> 24) != 0xff) {//Preset Instrument
		for (int i=0; i<2; i++) {
			tmp = ((voice->op[i].SL & 0xf) << 4) | (((keyon && voice->op[i].SR) ? voice->op[i].SR : voice->op[i].RR) & 0xf);
			SetReg(6 + i, tmp);
		}
	}

	tmp = GetReg(0x20 + ch, 0) & 0xef;
	SetReg(0x20 + ch, tmp | (keyon ? 0x10 : 0));
}

void COPLL::RhythmOn(UINT8 num, UINT8 vel, SINT8 pan, FMVOICE* rv, FNUM* fnum)
 {
	//SetReg(0x0e, 0x20);
	if (num < rhythmcap) {
		UINT8 evol = CalcEffectiveLevel(rhythmvol, 127-vel) >> 3;
		UINT16 addr = RhythmReg[num];
		UINT8 vch = RhythmMapCh[num];
		UINT8 mask = (num&5) ? 0xf0 : 0x0f;
		evol = (num&5) ? evol : (evol << 4);

		SetReg(addr, (GetReg(addr, 0) & mask) | evol);
		fnum = fnum ? fnum : &RhythmFnum[vch-6];
		UpdateFreq(vch, fnum);
		//SetNote(vch, RhythmFreq[vch-6]+off);
		//SetReg(0x0e, GetReg(0x0e, 0) & ~(1 << num));
		//SetReg(0x0e, (1 << num) | 0x20);
		RhythmOnMap |= (1 << num);
	}
}

void COPLL::RhythmOff(UINT8 num)
{
	if (num < rhythmcap) {
		RhythmOffMap |= (1 << num);
	}
}

void COPLL::TimerCallBack(UINT32 tick)
{
	CSoundDevice::TimerCallBack(tick);
	if (RhythmOffMap) {
		SetReg(0x0e, 0x20 | ((~RhythmOffMap) & (GetReg(0x0e, 0) & 0x1f)));
		RhythmOffMap = 0;
	}
	if (RhythmOnMap) {
		SetReg(0x0e, 0x20 | RhythmOnMap);
		RhythmOnMap = 0;
	}
}

COPLLP::COPLLP(CPort* pt, UINT8 mode, UINT8 fsamp) : COPLL(pt, mode, fsamp)
{
	SetDevice(DEVICE_OPLLP);
}

C2420::C2420(CPort* pt, UINT8 mode, UINT8 fsamp) : COPLL(pt, mode, fsamp)
{
	SetDevice(DEVICE_2420);
}

void C2420::UpdateFreq(UINT8 ch, const FNUM* fnum)
{
	CHATTR* attr = GetChAttribute(ch);
	fnum = fnum ? fnum : attr->GetLastFnumber();
	SetReg(0x10 + ch, (fnum->block << 5)|UINT8((fnum->fnum>>6)&0xff));
	SetReg(0x20 + ch, (GetReg(0x20 + ch, 0) & 0xf0) | UINT8((fnum->fnum>>2)&0xf));
}
