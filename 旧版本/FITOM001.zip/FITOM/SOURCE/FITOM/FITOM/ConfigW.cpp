#include "stdafx.h"
#include "FITOM.h"
#include "MIDIDEV.h"

CPort* CFITOM::CreatePort(int pttype, char* params)
{
	CPort* ret = 0;
	CHostIF* ioif = 0;
	char iftype[16];
	char portdef[80];
	UINT16 a0, a1, d0, d1, id, w1, w2;
	w1 = 7;
	w2 = 39;
	sscanf(params, "%[^:]: %i : %s", iftype, &id, portdef);
//		sscanf(params, "%[^:]:%i: %i, %i, %hx, %hx, %hx, %hx", iftype, &id, &w1, &w2, &a0, &d0, &a1, &d1);
	if (strcmp(iftype, "SPFM") == 0) {  //Serial Port FM (FT232)
	} else
	if (strcmp(iftype, "REBIRTH") == 0) {	//Re:Birth (FT245)
		ioif = GetIOIF(CHostIF::BIRTH, id);
	}
	else
	if (strcmp(iftype, "GIMIC") == 0) {  //C86CTL.dll
	} else
	if (strcmp(iftype, "MEM") == 0) {  //Memory mapped I/O
	} else
	if (strcmp(iftype, "IO") == 0) {  //I/O mapped I/O
	}
	if (ioif == 0) { return 0; }
	if (ioif->GetIFType() == CHostIF::BIRTH) {
		sscanf(portdef, "%i : %i : %hx", &w1, &w2, &a0);
		switch (pttype) {
		case 0: // 1 address port (for DCSG series)
			ret = new CSNPort(a0, ioif);
			break;
		case 1: // 1 address & data ports (most of sound chip)
			d0 = a0 + 1;
			ret = new CIOPort(a0, d0, a0, w1, w2, 0, ioif);
			break;
		case 2: // 2 sets of address & data (OPL3/OPNA/OPNB/OPN2/OPN3 etc.)
			d0 = a0 + 1; a1 = a0 + 2; d1 = a0 + 3;
			ret = new CDblPort(new CIOPort(a0, d0, a0, w1, w2, 0, ioif), new CIOPort(a1, d1, a0, w1, w2, 0, ioif));
			break;
		}
	} else
	if (ioif->GetIFType() == CHostIF::C86CTL) {
	} else
	if (ioif->GetIFType() == CHostIF::SPFM) {
	} else {
		switch (pttype) {
		case 0: // 1 address port (for DCSG series)
			sscanf(portdef, "%i, %i, %hx", &w1, &w2, &a0);
			ret = new CSNPort(a0, ioif);
			break;
		case 1: // 1 address & data ports (most of sound chip)
			sscanf(portdef, "%i, %i, %hx, %hx", &w1, &w2, &a0, &d0);
			ret = new CIOPort(a0, d0, a0, w1, w2, 0, ioif);
			break;
		case 2: // 2 sets of address & data (OPL3/OPNA/OPNB/OPN2/OPN3 etc.)
			sscanf(portdef, "%i, %i, %hx, %hx, %hx, %hx", &w1, &w2, &a0, &d0, &a1, &d1);
			ret = new CDblPort(new CIOPort(a0, d0, a0, w1, w2, 0, ioif), new CIOPort(a1, d1, a0, w1, w2, 0, ioif));
			break;
		}
	}
	return ret;
}

int CFITOM::LoadMidiConfig(FILE* fp)
{
	char tmp[80];
	CMidiIn* pmi;
	CMidiOut* pmo;
	while(fgets(tmp, 80, fp) != NULL) {

		char name[80];
		if (strncmp("MCIMIDIIN:", tmp, 10) == 0) {
			sscanf(&tmp[10], "%[^\n]", name);
			pmi = new CW32MidiIn(name);
			if (pmi) {
				AddDevice(pmi);
				printf("MIDI IN device \"%s\" as port %i...\n", name, mpus);
			}
		}
		if (strncmp("COMMIDIIN:", tmp, 10) == 0) {
			sscanf(&tmp[10], "%s", name);
			pmi = new CW32RsMidi(name);
			if (pmi) {
				AddDevice(pmi);
				printf("RS-MIDI UART setting on %s as port %i...\n", mpus);
			}
		}
		if (strncmp("MCIMIDIOUT:", tmp, 11) == 0) {
			sscanf(&tmp[11], "%[^\n]", name);
			pmo = new CW32MidiOut(name);
			if (pmo) {
				AddDevice(pmo);
				printf("MIDI OUT device \"%s\" as port %i...\n", name, mpus);
			}
		}
		if (strncmp("COMMIDIOUT:", tmp, 10) == 0) {
			sscanf(&tmp[10], "%s", name);
			pmo = new CW32RsMidi(name);
			if (pmo) {
				AddDevice(pmo);
				printf("RS-MIDI UART setting on %s as port %i...\n", mpus);
			}
		}
		if (strncmp("COMMIDI:", tmp, 8) == 0) {
			sscanf(&tmp[8], "%s", name);
			pmi = new CW32RsMidi(name);
			if (pmi) {
				AddDevice((CMidiOut*)AddDevice(pmi));
				printf("RS-MIDI UART setting on %s as port %i...\n", mpus);
			}
		}
	}
	if (!mpus) { return -1; }
	if (!devs) { return -2; }
	return 0;
}

