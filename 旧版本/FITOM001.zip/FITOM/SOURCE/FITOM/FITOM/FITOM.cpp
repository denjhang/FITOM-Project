#include "stdafx.h"
#include "FITOM.h"
#include "OPN.h"
#include "OPM.h"
#include "OPL.h"
#include "OPLL.h"
#include "SSG.h"
#include "MIDIDEV.h"
#include "MIDI.h"
#include "Console.h"
#include "XmemFile.h"
#include "Screen.h"


UINT8 CFITOM::GetDeviceIDFromName(char* name)
{
	UINT8 ret = DEVICE_NONE;
	if (strcmp("OPN", name) == 0) {
		ret = DEVICE_OPN;
	}
	if (strcmp("OPNA", name) == 0) {
		ret = DEVICE_OPNA;
	}
	if (strcmp("OPNB", name) == 0) {
		ret = DEVICE_OPNB;
	}
	if (strcmp("F286", name) == 0) {
		ret = DEVICE_F286;
	}
	if (strcmp("2610B", name) == 0) {
		ret = DEVICE_2610B;
	}
	if (strcmp("OPNC", name) == 0) {
		ret = DEVICE_OPNC;
	}
	if (strcmp("OPN3L", name) == 0) {
		ret = DEVICE_OPN3L;
	}
	if (strcmp("OPN2", name) == 0) {
		ret = DEVICE_OPN2;
	}
	if (strcmp("OPN2C", name) == 0) {
		ret = DEVICE_OPN2C;
	}
	if (strcmp("OPN2L", name) == 0) {
		ret = DEVICE_OPN2L;
	}
	if (strcmp("OPL", name) == 0) {
		ret = DEVICE_OPL;
	}
	if (strcmp("Y8950", name) == 0) {
		ret = DEVICE_Y8950;
	}
	if (strcmp("OPL2", name) == 0) {
		ret = DEVICE_OPL2;
	}
	if (strcmp("OPL3", name) == 0) {
		ret = DEVICE_OPL3;
	}
	if (strcmp("OPL3_2", name) == 0) {
		ret = DEVICE_OPL3_2;
	}
	if (strcmp("OPLL", name) == 0) {
		ret = DEVICE_OPLL;
	}
	if (strcmp("F281", name) == 0) {
		ret = DEVICE_OPLLP;
	}
	if (strcmp("2420", name) == 0) {
		ret = DEVICE_2420;
	}
	if (strcmp("OPM", name) == 0) {
		ret = DEVICE_OPM;
	}
	if (strcmp("OPP", name) == 0) {
		ret = DEVICE_OPP;
	}
	if (strcmp("PSG", name) == 0) {
		ret = DEVICE_PSG;
	}
	if (strcmp("SSG", name) == 0) {
		ret = DEVICE_SSG;
	}
	return ret;
}

const char* CFITOM::GetDeviceNameFromID(UINT8 devid)
{
	const char* ret = "-----";
	switch (devid) {
	case DEVICE_OPN:
		ret = "OPN";
		break;
	case DEVICE_OPNA:
		ret = "OPNA";
		break;
	case DEVICE_OPNB:
		ret = "OPNB";
		break;
	case DEVICE_2610B:
		ret = "YM2610B";
		break;
	case DEVICE_F286:
		ret = "YMF286";
		break;
	case DEVICE_OPNC:
		ret = "OPNC";
		break;
	case DEVICE_OPN3L:
		ret = "OPN3L";
		break;
	case DEVICE_OPN2:
		ret = "OPN2";
		break;
	case DEVICE_OPN2C:
		ret = "OPN2C";
		break;
	case DEVICE_OPN2L:
		ret = "OPN2L";
		break;
	case DEVICE_OPL:
		ret = "OPL";
		break;
	case DEVICE_Y8950:
		ret = "Y8950";
		break;
	case DEVICE_OPL2:
		ret = "OPL2";
		break;
	case DEVICE_OPL3:
		ret = "OPL3";
		break;
	case DEVICE_OPL3_2:
		ret = "OPL3(2op)";
		break;
	case DEVICE_OPLL:
		ret = "OPLL";
		break;
	case DEVICE_OPLLP:
		ret = "YMF281";
		break;
	case DEVICE_2420:
		ret = "YM2420";
		break;
	case DEVICE_OPM:
		ret = "OPM";
		break;
	case DEVICE_OPP:
		ret = "OPP";
		break;
	case DEVICE_SSG:
		ret = "SSG";
		break;
	case 0xff:
		ret = "RHYTHM";
		break;
	}
	return ret;
}

int CFITOM::InitInstance()
{
	LoadConfig();
	for (int i=0; i<devs; i++) {
		fmdev[i]->Reset();
		FMVOICE voice;
		GetVoice(&voice, fmdev[i]->GetDevice(), 0, 0);
		for (int j=0; j<fmdev[i]->GetAvailable(); j++) {
			//fmdev[i]->ResetVoice(NULL, NULL, 0);
			fmdev[i]->SetVoice(j, &voice);
		}
	}
	ResetAllCtrl();
	AllNoteOff();
	Console = new CConsole();
	Console->cls();
	SetRedraw(1);
	return 0;
}

CFITOM::CFITOM() : mpus(0), ompus(0), devs(0), MasterVolume(127), Console(NULL), redraw(1), timerprocessing(0), pollprocessing(0), timerskipped(0)
{
	printf("FM Instruments Total Operationg Middleware\n\n");
	opmbank = new CXmemFile(MAX_BANK * 128L * sizeof(FMVOICE));
	InitVoice(VOICE_TYPE_OPM, MAX_BANK, opmbank);
	printf("OPM voice bank %lu bytes available\n", opmbank->GetSize());
	opnabank = new CXmemFile(MAX_BANK * 128L * sizeof(FMVOICE));
	InitVoice(VOICE_TYPE_OPNA, MAX_BANK, opnabank);
	printf("OPNA voice bank %lu bytes available\n", opnabank->GetSize());
	opl2bank = new CXmemFile(MAX_BANK * 128L * sizeof(FMVOICE));
	InitVoice(VOICE_TYPE_OPL2, MAX_BANK, opl2bank);
	printf("OPL2 voice bank %lu bytes available\n", opl2bank->GetSize());
	opl3bank = new CXmemFile(MAX_BANK * 128L * sizeof(FMVOICE));
	InitVoice(VOICE_TYPE_OPL3, MAX_BANK, opl3bank);
	printf("OPL3 voice bank %lu bytes available\n", opl3bank->GetSize());
	opllbank = new CXmemFile(MAX_BANK * 128L * sizeof(FMVOICE));
	InitVoice(VOICE_TYPE_OPLL, MAX_BANK, opllbank);
	printf("OPLL voice bank %lu bytes available\n", opllbank->GetSize());
	psgbank = new CXmemFile(MAX_BANK * 1L * sizeof(FMVOICE));
	InitVoice(VOICE_TYPE_SSG, 1, psgbank);
	printf("PSG voice bank %lu bytes available\n", psgbank->GetSize());
	drummap = new CXmemFile(MAX_BANK * 128L * sizeof(DRUMMAP));
	printf("Drum map bank %lu bytes available\n", drummap->GetSize());
}

void CFITOM::ExitInstance(int save)
{
	UINT8 i;
	Console->cls();
	delete Console;
	for (i=0; i<mpus; i++) {
		delete mpu[i];
		delete midi[i];
	}
	for (i=0; i<devs; i++) {
		delete fmdev[i];
	}
	
	if (save) {
		char tmp[256];
		static CXmemFile* membank[] = {opnabank, opmbank, opl2bank, opl3bank, opllbank, };
		static char* bankname[] = {"OPNA_", "OPM__", "OPL2_", "OPL3_", "OPLL_", };
		for (int i=0; i<(sizeof(membank)/sizeof(CXmemFile*)); i++) {
			for (int j=0; j<MAX_BANK; j++) {
				sprintf(tmp, "%s%02i.fmb", bankname[i], j);
				SaveVoice(j, membank[i], tmp);
			}
		}
		SaveVoice(0, psgbank, "PSG__00.fmb");
	}
	delete opnabank;
	delete opmbank;
	delete opl2bank;
	delete opl3bank;
	delete opllbank;
	delete psgbank;
	delete drummap;
}

CSoundDevice* CFITOM::GetInstDeviceFromID(UINT8 devid)
{
	for (UINT8 i=0; i<devs; i++) {
		if (fmdev[i]->GetDevice() == devid) {
			return fmdev[i];
		}
	}
	return NULL;
}

int CFITOM::GetInstDeviceIndex(const CSoundDevice* pdev)
{
	for (int i=0; i<devs; i++) {
		if (pdev == fmdev[i]) {
			return i;
		}
	}
	return -1;
}

int CFITOM::GetInstDeviceIndex(UINT8 devid)
{
	for (int i=0; i<devs; i++) {
		if (fmdev[i]->GetDevice() == devid) {
			return i;
		}
	}
	return -1;
}

UINT8 CFITOM::GetVoiceType(UINT8 dev)
{
	UINT8 ret = 0;
	switch(dev) {
	case DEVICE_OPN:
	case DEVICE_OPNC:
		ret = VOICE_TYPE_OPN;
		break;
	case DEVICE_OPNA:
	case DEVICE_OPNB:
	case DEVICE_2610B:
	case DEVICE_F286:
	case DEVICE_OPN2:
	case DEVICE_OPN2L:
	case DEVICE_OPN2C:
	case DEVICE_OPN3L:
		ret = VOICE_TYPE_OPNA;
		break;
	case DEVICE_OPM:
	case DEVICE_OPP:
		ret = VOICE_TYPE_OPM;
		break;
	case DEVICE_OPL:
	case DEVICE_Y8950:
		ret = VOICE_TYPE_OPL;
		break;
	case DEVICE_OPL2:
	case DEVICE_OPL3_2:
		ret = VOICE_TYPE_OPL2;
		break;
	case DEVICE_OPLL:
	case DEVICE_OPLLP:
	case DEVICE_2420:
		ret = VOICE_TYPE_OPLL;
		break;
	case DEVICE_OPL3:
		ret = VOICE_TYPE_OPL3;
		break;
	case DEVICE_PSG:
	case DEVICE_SSG:
	case DEVICE_SSGS:
	case DEVICE_SSGL:
	case DEVICE_SSGLP:
		ret = VOICE_TYPE_SSG;
		break;
	case DEVICE_DCSG:
		ret = VOICE_TYPE_DCSG;
		break;
	case DEVICE_APSG:
		ret = VOICE_TYPE_APSG;
	}
	return ret;
}

int CFITOM::GetVoice(FMVOICE* voice, UINT8 dev, UINT8 bank, UINT8 prog)
{
	CXmemFile* xmem = NULL;
	UINT8 vtype = GetVoiceType(dev);
	if (bank < MAX_BANK && prog < 128) {
		switch(vtype) {
		case VOICE_TYPE_OPN:
		case VOICE_TYPE_OPNA:
			xmem = opnabank;
			break;
		case VOICE_TYPE_OPM:
			xmem = opmbank;
			break;
		case VOICE_TYPE_OPL:
		case VOICE_TYPE_OPL2:
			xmem = opl2bank;
			break;
		case VOICE_TYPE_OPLL:
			xmem = opllbank;
			break;
		case VOICE_TYPE_OPL3:
			xmem = opl3bank;
			break;
		case VOICE_TYPE_SSG:
		case VOICE_TYPE_APSG:
		case VOICE_TYPE_DCSG:
			xmem = psgbank;
			bank = 0;
			break;
		}
		if (xmem) {
			xmem->Seek((prog + bank * 128L) * sizeof(FMVOICE), 0);
			xmem->Read((void*)voice, sizeof(FMVOICE));
		}
	} else {
		memset(voice, 0, sizeof(FMVOICE));
		voice->ID = (0xff000000L) | (UINT16(bank) << 8) | prog;
		sprintf(voice->name, "%03i:%03i", bank, prog);
	}
	return 0;
}

int CFITOM::SetVoice(FMVOICE* voice, UINT8 dev, UINT8 bank, UINT8 prog)
{
	CXmemFile* xmem = NULL;
	UINT8 vtype = GetVoiceType(dev);
	if (bank < MAX_BANK && prog < 128) {
		switch(vtype) {
		case VOICE_TYPE_OPN:
		case VOICE_TYPE_OPNA:
			xmem = opnabank;
			break;
		case VOICE_TYPE_OPM:
			xmem = opmbank;
			break;
		case VOICE_TYPE_OPL:
		case VOICE_TYPE_OPL2:
			xmem = opl2bank;
			break;
		case VOICE_TYPE_OPLL:
			xmem = opllbank;
			break;
		case VOICE_TYPE_OPL3:
			xmem = opl3bank;
			break;
		case VOICE_TYPE_SSG:
		case VOICE_TYPE_APSG:
		case VOICE_TYPE_DCSG:
			xmem = psgbank;
			bank = 0;
			break;
		}
		if (xmem) {
			xmem->Seek((prog + bank * 128L) * sizeof(FMVOICE), 0);
			xmem->Write((void*)voice, sizeof(FMVOICE));
		}
	} else {
		return -1;
	}
	return 0;
}

int CFITOM::GetDrum(DRUMMAP* drum, UINT8 bank, UINT8 prog, UINT8 note)
{
	int ret = -1;
	if (drum) {
		prog &= 0x7f;
		note &= 0x7f;
		drummap->Seek((prog * 128L + note) * sizeof(DRUMMAP), 0);
		drummap->Read(drum, sizeof(DRUMMAP));
		ret = 0;
	}
	return ret;
}

void CFITOM::AllNoteOff()
{
	for (int i=0; i<devs; i++) {
		if (fmdev[i]) {
			fmdev[i]->Reset();
		}
	}
}

void CFITOM::ResetAllCtrl()
{
	for (int i=0; i<mpus; i++) {
		for (int j=0; j<16; j++) {
			CMidiCh* mch = midi[i]->GetMidiCh(j);
			if (mch) {
				mch->ResetAllCtrl();
			}
		}
	}
}

int CFITOM::PollingCallBack()
{
	int i;
	int ret = 0;
	if (!timerprocessing && !pollprocessing) {
		pollprocessing = 1;
		for (i=0; i<mpus; i++) {
			ret |= midi[i]->PollingCallBack();
		}
		for (i=0; i<devs; i++) {
			fmdev[i]->PollingCallBack();
		}
		pollprocessing = 0;
	}
	return ret;
}

void CFITOM::TimerCallBack(UINT32 tick)
{
	if (!timerprocessing && !pollprocessing) {
		timerprocessing = 1;
		int i;
		for (i=0; i<mpus; i++) {
			midi[i]->TimerCallBack(tick);
		}
		for (i=0; i<devs; i++) {
			fmdev[i]->TimerCallBack(tick);
		}
		timerprocessing = 0;
	}
}
