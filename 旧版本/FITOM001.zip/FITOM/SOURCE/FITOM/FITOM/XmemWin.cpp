#include "STDAFX.H"
#include "XmemFile.h"

int CXmemFile::Alloc(UINT32 size)
{
	xmem = ::GlobalAlloc(GHND, size);
	if (xmem) { actsize = size; }
	return GetLastError();
}

int CXmemFile::Read(void* dst, UINT32 size)
{
	if (actsize < (pos+size)) return -1;
	void* ptmp = GlobalLock(xmem);
	memcpy(dst, (char*)ptmp+pos, size);
	pos += size;
	GlobalUnlock(xmem);
	return GetLastError();
}

int CXmemFile::Write(void* src, UINT32 size)
{
	if (actsize < (pos+size)) return -1;
	void* ptmp = GlobalLock(xmem);
	memcpy((char*)ptmp+pos, src, size);
	pos += size;
	GlobalUnlock(xmem);
	return GetLastError();
}

int CXmemFile::Seek(SINT32 offset, int origin)
{
	switch (origin) {
	case 0:	//top
		if (offset < 0 || offset > actsize) { return -1; }
		pos = offset;
		break;
	case 1:	//current
		if ((pos+offset) < 0 || (pos+offset) > actsize) { return -1; }
		pos += offset;
		break;
	case 2:	//end
		if (SINT32(actsize+offset) < 0 || (actsize+offset) > actsize) { return -1; }
		pos = actsize + offset;
		break;
	}
	return 0;
}

int CXmemFile::Free()
{
	::GlobalFree(xmem);
	xmem = 0;
	pos = 0;
	actsize = 0;
	return GetLastError();
}
