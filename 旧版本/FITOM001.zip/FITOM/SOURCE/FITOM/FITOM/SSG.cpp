#include "stdafx.h"
#include "SSG.h"
#include "FITOM.h"

namespace ROM {
extern const UINT16 TP399[];
extern const UINT16 TP400[];
extern const UINT16 TP358[];
extern const UINT16 TP409[];
};

CPSGBase::CPSGBase(UINT8 devid, CPort* pt, UINT8 ch, UINT8 fsamp)
	: CSoundDevice(devid, ch, fsamp, pt)
{
	switch (fsamp) {
	case 0:
	default:
		TP = ROM::TP399;
		break;
	case 1:
		TP = ROM::TP400;
		break;
	case 2:
		TP = ROM::TP358;
		break;
	case 3:
		TP = ROM::TP409;
		break;
	}
	ops = 0;
	lfoTL = new UINT8[chs];
	egattr = new CEnvelope[chs];
}

ISoundDevice::FNUM CPSGBase::GetFnumber(UINT8 ch)
{
	FNUM ret;
	CHATTR* attr = GetChAttribute(ch);
	SINT16 note = attr->GetLastNote() % 12;
	SINT16 oct = (attr->GetLastNote() / 12) - 1;
	SINT16 cent = attr->GetLastFineFreq() + attr->GetChLFOValue();

	// normalize
	if (cent < 0) {
		cent = -cent;
		note -= ((cent+63) / 64);
		cent = 64 - (cent % 64);
	}
	if (cent > 63) {
		note += cent / 64;
		cent = cent % 64;
	}
	if (note < 0) {
		note = -note;
		oct -= ((note+11) / 12);
		note = 12 - (note % 12);
	}
	if (note > 11) {
		oct += note / 12;
		note = note % 12;
	}

	ret.block = attr->GetLastNote();
	ret.fnum = TP[note*64+cent] >> ((oct<1)?1:oct);
	return ret;
}

void CPSGBase::UpdateKey(UINT8 ch, UINT8 keyon)
{
	FMVOICE* voice = GetChAttribute(ch)->GetVoice();
	if (keyon) {
		UpdateVoice(ch);
		if (!(voice->AL & 0x4)) {
			egattr[ch].Start(&voice->op[0]);
		}
	} else {
		egattr[ch].Release();
	}
}

void CPSGBase::PollingCallBack()
{
}

void CPSGBase::UpdateLevelEG()
{
	for (int i=0; i<chs; i++) {
		if (egattr[i].GetPhase() != CEnvelope::EG_NONE) {
			egattr[i].Update();
		} else if (GetChAttribute(i)->IsRunning()) {
			NoteOff(i);
		}
	}
}

void CPSGBase::TimerCallBack(UINT32 tick)
{
	if (/*(tick & 1)*/1) {
		UpdateLevelEG();
	}
	CSoundDevice::TimerCallBack(tick);

	for (int i=0; i<chs; i++) {
		if (egattr[i].GetPhase() != CEnvelope::EG_NONE) {
			UpdateVolExp(i);
		}
	}
}

//-------------------------------

CSSG::CSSG(CPort* pt, UINT8 fsamp) : CPSGBase(DEVICE_SSG, pt, 3, fsamp)
{
	SetReg(0x07, 0x3f, 1);
	ops = 2;
}

void CSSG::UpdateVolExp(UINT8 ch)
{
	CHATTR* attr = GetChAttribute(ch);
	if (!(attr->GetVoice()->AL & 0x4)) {
		UINT8 evol = attr->GetEffectiveLevel();
		SINT16 lev = SINT16(lfoTL[ch]) - 64 + egattr[ch].GetValue();
		lev = (lev < 0) ? 0 : lev;
		lev = (lev > 127) ? 127 : lev;
		evol = CalcEffectiveLevel(evol, 127-UINT8(lev)) >> 3;
		SetReg(8 + ch, 15-evol & 0xf, 1);
	}
}

void CSSG::UpdateFreq(UINT8 ch, const FNUM* fnum)
{
	fnum = fnum ? fnum : GetChAttribute(ch)->GetLastFnumber();
	SetReg(ch * 2 + 0, UINT8(fnum->fnum & 0xff), 1);
	SetReg(ch * 2 + 1, UINT8(fnum->fnum >> 8), 1);
}

void CSSG::UpdateVoice(UINT8 ch)
{
	UINT8 mix = 8;
	CHATTR* attr = GetChAttribute(ch);
	FMVOICE* voice = attr->GetVoice();
	switch (voice->AL & 3) {
	case 0:
		mix = 0x8;
		break;
	case 1:
		mix = 0x1;
		break;
	case 2:
		mix = 0x0;
		break;
	case 3:
		mix = 0x9;
		break;
	}
	lfoTL[ch] = attr->baseTL[0] = attr->baseTL[1] = 64;
	SetReg(0x7, (GetReg(0x7, 0) & ~(0x9 << ch)) | (mix << ch), 1);
	if (mix==1 || mix==0) {
		SetReg(0x6, voice->NFQ, 1);
	}
	if (voice->AL & 0x4) {	//HW env
		SetReg(0x8+ch, (GetReg(0x8+ch, 0) & 0xe0) | 0x10 | (voice->op[0].EGT & 0xf), 1);
		SetReg(0xb, (((voice->op[0].SR << 4) & 0xf0) | (voice->op[0].SL & 0xf)), 1);
		SetReg(0xc, (((voice->op[0].DR << 2) & 0xfc) | ((voice->op[0].SR >> 4) & 0x3)), 1);
	}
}

void CSSG::UpdateTL(UINT8 ch, UINT8 op, UINT8 lev)
{
	FMVOICE* voice = GetChAttribute(ch)->GetVoice();
	switch (op) {
	case 0:// Amplitude LFO
		{
			lfoTL[ch] = lev;
		}
		break;
	case 1:// Noise freq LFO
		if ((voice->AL & 3)==1 || (voice->AL & 3)==2) {
			SINT16 frq = SINT16(lev) - 64 + (((voice->NFQ << 2) | (voice->NFQ >> 3)) & 0x7f);
			frq = (frq < 0) ? 0 : frq;
			frq = (frq > 127) ? 127 : frq;
			SetReg(0x6, lev >> 2, 1);
		}
		break;
	}
}

UINT8 CSSG::QueryCh(CMidiCh* parent, FMVOICE* voice, int mode)
{
	CHATTR* attr2 = GetChAttribute(2);
	CHATTR* attr1 = GetChAttribute(1);
	if (voice && (voice->AL & 0x3) != 0) {//Noise enabled
		if (mode ? attr2->IsAvailable() : attr2->IsEnable()) {
			return 2;
		} else {
			return 0xff;
		}
	} else if (voice && (voice->AL & 0x20) != 0) {//HW Envelop
		if (mode ? attr1->IsAvailable() : attr1->IsEnable()) {
			return 1;
		} else {
			return 0xff;
		}
	}
	return CSoundDevice::QueryCh(parent, voice, mode);
}

//-------------------------------
CSSGS::CSSGS(CPort* pt, UINT8 fsamp) : CPSGBase(DEVICE_SSGS, pt, 6, fsamp)
{
	SetReg(0x07, 0x3f, 1);
	ops = 2;
}

void CSSGS::UpdateVolExp(UINT8 ch)
{
	CHATTR* attr = GetChAttribute(ch);
	FMVOICE* voice = attr->GetVoice();
	if (!(voice->AL & 0x4)) {
		UINT8 evol = attr->GetEffectiveLevel();
		SINT16 lev = SINT16(lfoTL[ch]) - 64 + egattr[ch].GetValue();
		lev = (lev < 0) ? 0 : lev;
		lev = (lev > 127) ? 127 : lev;
		evol = CalcEffectiveLevel(evol, 127-UINT8(lev)) >> 3;
		UINT8 off = (ch < 3) ? 8 : 0x28;
		UINT8 dch = (ch < 3) ? ch : (ch-3);
		SetReg(off + dch, 15-evol & 0xf, 1);
	}
}

void CSSGS::UpdateFreq(UINT8 ch, const FNUM* fnum)
{
	fnum = fnum ? fnum : GetChAttribute(ch)->GetLastFnumber();
	UINT8 off = (ch < 3) ? 0 : 0x20;
	UINT8 dch = (ch < 3) ? ch : (ch-3);
	SetReg(off + dch * 2 + 0, UINT8(fnum->fnum & 0xff), 1);
	SetReg(off + dch * 2 + 1, UINT8(fnum->fnum >> 8), 1);
}

void CSSGS::UpdateVoice(UINT8 ch)
{
	CHATTR* attr = GetChAttribute(ch);
	FMVOICE* voice = attr->GetVoice();
	UINT8 mix = 8;
	switch (voice->AL & 3) {
	case 0:
		mix = 0x8;	//tone
		break;
	case 1:
		mix = 0x1;	//noise
		break;
	case 2:
		mix = 0x0;	//tone+noise
		break;
	case 3:
		mix = 0x9;	//off
		break;
	}
	lfoTL[ch] = attr->baseTL[0] = attr->baseTL[1] = 64;
	UINT8 off = (ch < 3) ? 0 : 0x20;
	UINT8 dch = (ch < 3) ? ch : (ch-3);
	SetReg(off + 0x7, (GetReg(0x7, 0) & ~(0x9 << dch)) | (mix << dch), 1);
	if (mix==0 || mix==1) {
		SetReg(off + 0x6, voice->NFQ, 1);
	}
	if (voice->AL & 0x4) {	//hw env
		SetReg(off + 0x8 + dch, (GetReg(0x8+ch, 0) & 0xe0) | 0x10 | (voice->op[0].EGT & 0xf), 1);
		SetReg(off + 0xb, (((voice->op[0].SR << 4) & 0xf0) | (voice->op[0].SL & 0xf)), 1);
		SetReg(off + 0xc, (((voice->op[0].DR << 2) & 0xfc) | ((voice->op[0].SR >> 4) & 0x3)), 1);
	}
}

void CSSGS::UpdateTL(UINT8 ch, UINT8 op, UINT8 lev)
{
	FMVOICE* voice = GetChAttribute(ch)->GetVoice();
	switch (op) {
	case 0:// Amplitude LFO
		{
			lfoTL[ch] = lev;
		}
		break;
	case 1:// Noise freq LFO
		if ((voice->AL & 3)==1 || (voice->AL & 3)==2) {
			SINT16 frq = SINT16(lev) - 64 + (((voice->NFQ << 2) | (voice->NFQ >> 3)) & 0x7f);
			frq = (frq < 0) ? 0 : frq;
			frq = (frq > 127) ? 127 : frq;
			UINT8 off = (ch < 3) ? 0 : 0x20;
			SetReg(off + 0x6, lev >> 2, 1);
		}
		break;
	}
}

void CSSGS::UpdatePanpot(UINT8 ch)
{
	UINT8 off = (ch < 3) ? 0 : 0x20;
	UINT8 dch = (ch < 3) ? ch : (ch-3);
	SetReg(off + 0x10 + dch, (GetChAttribute(ch)->panpot >> 2), 1);
}

UINT8 CSSGS::QueryCh(CMidiCh* parent, FMVOICE* voice, int mode)
{
	CHATTR* attr = 0;
	if (voice && ((voice->AL & 3)==1 || (voice->AL & 3)==2)) {//Noise enabled
		attr = GetChAttribute(2);
		if (mode ? attr->IsAvailable() : attr->IsEnable()) {
			return 2;
		}
		attr = GetChAttribute(5);
		if (mode ? attr->IsAvailable() : attr->IsEnable()) {
			return 5;
		}
		return 0xff;
	} else if (voice && (voice->AL & 0x4) != 0) {//HW Envelop
		attr = GetChAttribute(1);
		if (mode ? attr->IsAvailable() : attr->IsEnable()) {
			return 1;
		}
		attr = GetChAttribute(4);
		if (mode ? attr->IsAvailable() : attr->IsEnable()) {
			return 4;
		}
		return 0xff;
	}
	return CSoundDevice::QueryCh(parent, voice, mode);
}

//-------------------------------
CDCSG::CDCSG(CSNPort* pt, UINT8 fsamp) : CPSGBase(DEVICE_DCSG, pt, 3, fsamp)
{
}

void CDCSG::UpdateVolExp(UINT8 ch)
{
	CHATTR* attr = GetChAttribute(ch);
	UINT8 evol = attr->GetEffectiveLevel();
	evol = CalcEffectiveLevel(evol, 127-egattr[ch].GetValue()) >> 3;
	SetReg((ch << 1) | 1, 15 - (evol & 0xf), 1);
}

void CDCSG::UpdateFreq(UINT8 ch, const FNUM* fnum)
{
	fnum = fnum ? fnum : GetChAttribute(ch)->GetLastFnumber();
	//SetReg(ch * 2 + 0, fnum->fnum, 1);
	port->write(ch * 2, fnum->fnum, 1);
}

void CDCSG::UpdateVoice(UINT8 ch)
{
}

UINT8 CDCSG::AllocCh(CMidiCh* par, FMVOICE* voice)
{
	return CSoundDevice::AllocCh(par, voice);
}
