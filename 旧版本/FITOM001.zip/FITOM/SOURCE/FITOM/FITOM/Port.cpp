#include "STDAFX.H"
#include "Port.h"


CIOPort::CIOPort(UINT16 ad, UINT16 dt, UINT16 st, UINT8 aw, UINT8 dw, UINT8 bm, CHostIF* ioif) :
	addr(ad), data(dt), await(aw), dwait(dw), busy(bm), stat(st), pioif(ioif)
{
	memset((void*)regbak, 0xff, sizeof(regbak));
}

int CIOPort::GetDesc(char* str)
{
	sprintf(str, "(addr=%04X,data=%04X)", addr, data);
	return strlen(str);
}

void CIOPort::write(UINT16 reg, UINT16 val, int v)
{
	if ((v || regbak[reg] != val) && pioif) {
		reg &= 0xff;
		while(status()&busy);
		regbak[reg] = UINT8(val);
		pioif->write(addr, data, reg, val, await, dwait);
	} else if (!v) {
		regbak[reg] = UINT8(val);
	}
}

UINT8 CIOPort::read(UINT16 reg, int v)
{
	UINT8 ret = 0;
	reg &= 0xff;
	if (v && pioif) {
		ret = pioif->read(addr, reg, await);
	} else {
		ret = regbak[reg];
	}
	return ret;
}

UINT8 CIOPort::status()
{
	UINT8 ret = 0;
	ret = pioif ? pioif->read(stat) : 0;
	return ret;
}

CDblPort::CDblPort(CPort* pta, CPort* ptb)
{
	port[0] = pta;
	port[1] = ptb;
}

void CDblPort::write(UINT16 reg, UINT16 val, int v)
{
	(reg < 0x100) ? port[0]->write(reg, val, v) : port[1]->write(reg & 0xff, val, v);
}

UINT8 CDblPort::read(UINT16 reg, int v)
{
	return (reg < 0x100) ? port[0]->read(reg, v) : port[1]->read(reg & 0xff, v);
}

UINT8 CDblPort::status()
{
	return port[0]->status();
}

CPort* CDblPort::GetSubPort(int idx)
{
	return port[idx&1];
}

int CDblPort::GetDesc(char* str)
{
	int off = port[0]->GetDesc(str);
	int res = port[1]->GetDesc(&str[off]);
	return strlen(str);
}

CSNPort::CSNPort(UINT16 ad, CHostIF* ioif) : addr(ad), pioif(ioif)
{
}

void CSNPort::write(UINT16 ad, UINT16 val, int v)
{
	ad &= 0x7;
	if (ad == 0 || ad == 2 || ad == 4) {
		write(0x80 | (ad << 4) | val & 0xf);
		write((ad << 4) | ((val >> 4) & 0xf));
	} else {
		write(0x80 | (ad << 4) | val & 0xf);
	}
}

int CSNPort::GetDesc(char* str)
{
	sprintf(str, "(addr=%04X)", addr);
	return strlen(str);
}

void CSNPort::write(UINT8 data)
{
	pioif ? pioif->write(addr, data, 0) : 0;
}
