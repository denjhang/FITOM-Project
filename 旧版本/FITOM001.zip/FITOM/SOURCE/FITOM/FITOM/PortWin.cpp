#include "STDAFX.H"
#include "FITOM.h"
#include "Port.h"
#include <crtdbg.h>

static class CRTDBG{
public:
	CRTDBG() { _CrtSetReportMode(_CRT_WARN, _CRTDBG_MODE_DEBUG); };
} crtinit;

//	_RPTF2(_CRT_WARN, "%04X : %02X\n", addr, data);

int CFITOM::LoadIOIF(FILE* fp)
{
	CHostIF* pif = 0;
	char tmp[80]; 
	while(fgets(tmp, 80, fp) != NULL) {
		char ifname[8];
		UINT16 id;
		char ifsn[17];
		sscanf(tmp, "%[^:]:%i:%16s", ifname, &id, ifsn);
		CHostIF* pif = 0;
		if (strcmp(ifname, "SPFM") == 0) {
			pif = new CSPFMFT(id, ifsn);
		} else
		if (strcmp(ifname, "REBIRTH") == 0) {
			pif = new CReBirth(id, ifsn);
		}
		if (pif && pif->isValid()) {
			pioif[ioifs++] = pif;
		} else {
			delete pif;
			pif = 0;
		}
	}
	return ioifs;
}

void CBufferedIO::push(UINT8 data)
{
	if (SendLen < 1023) {
		SendBuff[SendLen++] = data;
	}
}

CReBirth::CReBirth(UINT32 id, char* sn) : CBufferedIO(id, CHostIF::BIRTH), ftHandle(0)
{
	FT_STATUS ftStatus = FT_OpenEx((PVOID)sn, FT_OPEN_BY_SERIAL_NUMBER, &ftHandle);
	if (ftStatus == FT_OK) {
		ftStatus = FT_SetBaudRate(ftHandle, 999999);
		if (ftStatus == FT_OK){
			ftStatus = FT_SetBitMode(ftHandle, 0x00, 0x0); //RESET
			ftStatus = FT_SetBitMode(ftHandle, 0xff, 0x1); //Asynchronous Bit Bang
			ftStatus = FT_SetTimeouts(ftHandle, 5000, 5000); //ms
			printf("Detected: FT245 Re:Birth:%s\n", sn);
		}
	} else {
		iftype = CHostIF::IOIF_NONE;
	}
}

void CReBirth::write(UINT16 addr1, UINT16 addr2, UINT16 reg, UINT16 data, UINT16 w1, UINT16 w2)
{
	UINT8 d = (addr1 >> 4) & 0xff;
	UINT8 a = (addr1 & 0xf);
	push((d>>4)|0x9c);	//board select
	push((d>>4)|0xbc);	//board select
	push((d&15)|0x90);	//board select
	push((d&15)|0xb0);	//board select
	push((reg&15)|0xa0);	//data bus
	push((reg&15)|0xb0);	//data bus
	push((reg>>4)|0xa0);	//data bus
	push((reg>>4)|0xb0);	//data bus
	push((a&15)|((d>>2)&0x30)|0x80);	//address bus
	for (int i=0; i<w1; i++) {
		push((a&15)|((d>>2)&0x30)|0x00);
	}
	//push((a&15)|((d>>2)&0x30)|0xc0);	//end of cycle

	d = (addr2 >> 4) & 0xff;
	a = (addr2 & 0xf);
	push((d>>4)|((d>>2)&0x10)|0x8c);	//board select
	push((d>>4)|((d>>2)&0x10)|0xac);	//board select
	push((d&15)|((d>>2)&0x10)|0x80);	//board select
	push((d&15)|((d>>2)&0x10)|0xa0);	//board select
	push((data&15)|0xa0);	//data bus
	push((data&15)|0xb0);	//data bus
	push((data>>4)|0xa0);	//data bus
	push((data>>4)|0xb0);	//data bus
	push((a&15)|((d>>2)&0x30)|0x80);	//address bus
	for (int i=0; i<w2; i++) {
		push((a&15)|((d>>2)&0x30)|0x00);
	}
	push((a&15)|((d>>2)&0x30)|0xc0);	//end of cycle
	flush();
}

void CReBirth::write(UINT16 addr, UINT16 data, UINT16 w)
{
	UINT8 d = (addr >> 4) & 0xff;
	UINT8 a = (addr & 0xf);
	push((d>>4)|0x9c);	//board select
	push((d>>4)|0xbc);	//board select
	push((d&15)|0x90);	//board select
	push((d&15)|0xb0);	//board select
	push((data&15)|0xa0);	//data bus
	push((data&15)|0xb0);	//data bus
	push((data>>4)|0xa0);	//data bus
	push((data>>4)|0xb0);	//data bus
	push((a&15)|((d>>2)&0x30)|0x80);	//address bus
	for (int i=0; i<w; i++) {
		push((a&15)|((d>>2)&0x30)|0x00);
	}
	for (int i=0; i<w; i++) {
		push((a&15)|((d>>2)&0x30)|0xC0);
	}
	flush();
}

UINT8 CReBirth::read(UINT16 addr, UINT16 reg, UINT16 w)
{
	return 0;
}

UINT8 CReBirth::read(UINT16 addr)
{
	return 0;
}

void CReBirth::flush()
{
	if(SendLen > 0 && ftHandle){
		DWORD writebyte;
		if (FT_Write(ftHandle, SendBuff, SendLen, &writebyte) == FT_OK) {
			SendLen = 0;
		}
	}
}

void CReBirth::wait(int w)
{
	for(int i=0; i<w; i++) push(0xf0);
}

void CReBirth::reset()
{
	CBufferedIO::reset();
	if (ftHandle) {
		FT_SetBitMode(ftHandle, 0x00, 0x0); //RESET
	}
}

CReBirth::~CReBirth()
{
	if (ftHandle) {
		reset();
		FT_Close(ftHandle);
	}
}

CSPFMFT::CSPFMFT(UINT32 id, char* sn) : CBufferedIO(id, CHostIF::SPFM), ftHandle(0)
{
	ftHandle = FT_W32_CreateFile((LPCTSTR)sn, GENERIC_READ|GENERIC_WRITE, 0, NULL, 
		OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED | FT_OPEN_BY_SERIAL_NUMBER, 0);
	if (ftHandle != INVALID_HANDLE_VALUE) {
		char tmp[MAX_PATH];
		wsprintf(tmp, "SPFM:%i:%s", id, sn);
		ovl.hEvent = CreateEvent(NULL, TRUE, FALSE, tmp);
		FTTIMEOUTS cpt;
		FT_W32_GetCommTimeouts(ftHandle, &cpt);
		cpt.ReadTotalTimeoutMultiplier = 50;
		cpt.ReadTotalTimeoutConstant  = 100;
		FT_W32_SetCommTimeouts(ftHandle, &cpt);
		FTDCB dcb;
		FT_W32_GetCommState(ftHandle, &dcb);
		dcb.BaudRate = 625000;
		dcb.ByteSize = 8;
		dcb.Parity = NOPARITY;
		dcb.StopBits = ONESTOPBIT;
		dcb.fOutxCtsFlow = FALSE;
		dcb.fRtsControl = RTS_CONTROL_DISABLE;
		FT_W32_SetCommState(ftHandle, &dcb);
		printf("Detected: FT232 %s\n", tmp);
		reset();
	} else {
		ftHandle = 0;
		iftype = CHostIF::IOIF_NONE;
	}
}

void CSPFMFT::write(UINT16 addr1, UINT16 addr2, UINT16 reg, UINT16 data, UINT16 w1, UINT16 w2)
{
	push(UINT8(addr1));
	push(UINT8(reg));
	push(UINT8(data));
	flush();
}

void CSPFMFT::write(UINT16 addr, UINT16 data, UINT16 w)
{
}

UINT8 CSPFMFT::read(UINT16 addr, UINT16 data, UINT16 w)
{
	return 0;
}

UINT8 CSPFMFT::read(UINT16 addr)
{
	return 0;
}

void CSPFMFT::flush()
{
	if (ftHandle && SendLen) {
		DWORD numberOfPut;
		FT_W32_WriteFile(ftHandle, LPVOID(SendBuff), SendLen, &numberOfPut, &ovl);
	}
}

void CSPFMFT::wait(int w)
{
	for(int i=0; i<w; i++) {
		push(0xf0);
		push(0xff);
		push(0xff);
	}
}

void CSPFMFT::reset()
{
	CBufferedIO::reset();
	if (ftHandle) {
		BYTE result[2] = {0x00,0x00};
		static const BYTE rstCmd[] = {0xff};
		static const DWORD lengthOfSent = (sizeof(rstCmd)/sizeof(BYTE));
		DWORD numberOfPut;
		DWORD numberOfRead;

		FT_W32_WriteFile(ftHandle, LPVOID(rstCmd), lengthOfSent, &numberOfPut, &ovl);
		WaitForSingleObject(ovl.hEvent, 1000);
		ResetEvent(ovl.hEvent);
		FT_W32_ReadFile(ftHandle, &result, 2, &numberOfRead, NULL);
		if(numberOfRead == 2){
			if(result[0] != 'O' || result[1] != 'K'){
				iftype = CHostIF::IOIF_NONE;
				FT_W32_CloseHandle(ftHandle);
				ftHandle = 0;
			}
		}
	}
}

CSPFMFT::~CSPFMFT()
{
	if (ftHandle) {
		FT_W32_CloseHandle(ftHandle);
	}
}
