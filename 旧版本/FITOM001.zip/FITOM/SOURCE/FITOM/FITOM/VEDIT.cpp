#include "STDAFX.H"
#include "SoundDev.h"
#include "Screen.h"
#include "Console.h"
#include "MIDIDEV.h"
#include "MIDI.h"
#include <conio.h>

const CVoiceEdit::EDITITEM CVoiceEdit::items[] = {
//size,addr,mask,shift,min,max,label,,,
	{ 3,20,0x0f,0,0,7,"FB",},//FB
	{ 3,20,0xf0,4,0,7,"FB2",},//FB2
	{ 3,21,0x7f,0,0,127,"AL",},//AL
	{ 3,22,0x7f,0,0,127,"AMS",},//AMS
	{ 3,23,0x7f,0,0,127,"PMS",},//PMS
	{ 3,24,0x7f,0,0,127,"LFO dep.M",},//AMD
	{ 3,25,0x7f,0,0,127,"LFO dep.L",},//PMD
	{ 3,26,0x7f,0,0,127,"LFO freq",},//LFO freq
	{ 3,27,0x7f,0,0,127,"LFO wave",},//LFO waveform
	{ 3,29,0x7f,0,0,127,"LFO delay",},//LFO delay
	{ 3,30,0x7f,0,0,127,"LFO rate",},//LFO rate
	{ 3,31,0x7f,0,0,127,"NOISE",},//NOISE
	{ 3,32,0x7f,0,0,127,"OP1 AR",},//OP1 AR
	{ 3,33,0x7f,0,0,127,"OP1 DR",},//OP1 DR
	{ 3,34,0x7f,0,0,127,"OP1 SL",},//OP1 SR
	{ 3,35,0x7f,0,0,127,"OP1 SR",},//OP1 SL
	{ 3,36,0x7f,0,0,127,"OP1 RR",},//OP1 RR
	{ 3,37,0x7f,0,0,127,"OP1 SRR",},//OP1 SRR
	{ 3,38,0x7f,0,0,127,"OP1 TL",},//OP1 TL
	{ 3,39,0x0f,0,0,15,"OP1 SSG-EG",},//OP1 SSG-EG
	{ 3,40,0x7f,0,0,127,"OP1 EGBIAS",},//OP1 EG BIAS
	{ 3,41,0x03,0,0,3,"OP1 KSL",},//OP1 KSL
	{ 3,42,0x03,0,0,3,"OP1 KSR",},//OP1 KSR
	{ 3,43,0x07,0,0,7,"OP1 WS",},//OP1 WS
	{ 3,44,0x01,0,0,1,"OP1 AME",},//OP1 AME
	{ 3,45,0x01,0,0,1,"OP1 VIB",},//OP1 VIB
	{ 3,46,0x0f,0,0,15,"OP1 LFO fr",},//OP1 LFO freq
	{ 3,47,0x07,0,0,7,"OP1 LFO wf",},//OP1 LFO wave
	{ 3,48,0x7f,0,0,127,"OP1 LFO dp",},//OP1 LFO depth
	{ 3,49,0x7f,0,0,127,"OP1 LFO dl",},//OP1 LFO delay
	{ 3,50,0x7f,0,0,127,"OP1 LFO rt",},//OP1 LFO rate
	{ 3,51,0x01,0,0,1,"OP1 OFM",},//OP1 OFM
	{ 3,52,0x0f,0,0,15,"OP1 MUL",},//OP1 MUL
	{ 3,53,0x07,0,0,7,"OP1 DT1",},//OP1 DT1
	{ 3,54,0x03,0,0,3,"OP1 DT2",},//OP1 DT2
	{ 3,55,0x7f,0,0,127,"OP1 OFT",},//OP1 OFT
	{ 3,56,0x7f,0,0,127,"OP2 AR",},//OP2 AR
	{ 3,57,0x7f,0,0,127,"OP2 DR",},//OP2 DR
	{ 3,58,0x7f,0,0,127,"OP2 SL",},//OP2 SR
	{ 3,59,0x7f,0,0,127,"OP2 SR",},//OP2 SL
	{ 3,60,0x7f,0,0,127,"OP2 RR",},//OP2 RR
	{ 3,61,0x7f,0,0,127,"OP2 SRR",},//OP2 SRR
	{ 3,62,0x7f,0,0,127,"OP2 TL",},//OP2 TL
	{ 3,63,0x0f,0,0,15,"OP2 SSG-EG",},//OP2 SSG-EG
	{ 3,64,0x7f,0,0,127,"OP2 EGBIAS",},//OP2 EG BIAS
	{ 3,65,0x03,0,0,3,"OP2 KSL",},//OP2 KSL
	{ 3,66,0x03,0,0,3,"OP2 KSR",},//OP2 KSR
	{ 3,67,0x07,0,0,7,"OP2 WS",},//OP2 WS
	{ 3,68,0x01,0,0,1,"OP2 AME",},//OP2 AME
	{ 3,69,0x01,0,0,1,"OP2 VIB",},//OP2 VIB
	{ 3,70,0x0f,0,0,15,"OP2 LFO fr",},//OP2 LFO freq
	{ 3,71,0x07,0,0,7,"OP2 LFO wf",},//OP2 LFO wave
	{ 3,72,0x7f,0,0,127,"OP2 LFO dp",},//OP2 LFO depth
	{ 3,73,0x7f,0,0,127,"OP2 LFO dl",},//OP2 LFO delay
	{ 3,74,0x7f,0,0,127,"OP2 LFO rt",},//OP1 LFO rate
	{ 3,75,0x01,0,0,1,"OP2 OFM",},//OP2 OFM
	{ 3,76,0x0f,0,0,15,"OP2 MUL",},//OP2 MUL
	{ 3,77,0x07,0,0,7,"OP2 DT1",},//OP2 DT1
	{ 3,78,0x03,0,0,3,"OP2 DT2",},//OP2 DT2
	{ 3,79,0x7f,0,0,127,"OP2 OFT",},//OP2 OFT
	{ 3,80,0x7f,0,0,127,"OP3 AR",},//OP3 AR
	{ 3,81,0x7f,0,0,127,"OP3 DR",},//OP3 DR
	{ 3,82,0x7f,0,0,127,"OP3 SL",},//OP3 SR
	{ 3,83,0x7f,0,0,127,"OP3 SR",},//OP3 SL
	{ 3,84,0x7f,0,0,127,"OP3 RR",},//OP3 RR
	{ 3,85,0x7f,0,0,127,"OP3 SRR",},//OP3 SRR
	{ 3,86,0x7f,0,0,127,"OP3 TL",},//OP3 TL
	{ 3,87,0x0f,0,0,15,"OP3 SSG-EG",},//OP3 SSG-EG
	{ 3,88,0x7f,0,0,127,"OP3 EGBIAS",},//OP3 EG BIAS
	{ 3,89,0x03,0,0,3,"OP3 KSL",},//OP3 KSL
	{ 3,90,0x03,0,0,3,"OP3 KSR",},//OP3 KSR
	{ 3,91,0x07,0,0,7,"OP3 WS",},//OP3 WS
	{ 3,92,0x01,0,0,1,"OP3 AME",},//OP3 AME
	{ 3,93,0x01,0,0,1,"OP3 VIB",},//OP3 VIB
	{ 3,94,0x0f,0,0,15,"OP3 LFO fr",},//OP3 LFO freq
	{ 3,95,0x07,0,0,7,"OP3 LFO wf",},//OP3 LFO wave
	{ 3,96,0x7f,0,0,127,"OP3 LFO dp",},//OP3 LFO depth
	{ 3,97,0x7f,0,0,127,"OP3 LFO dl",},//OP3 LFO delay
	{ 3,98,0x7f,0,0,127,"OP3 LFO rt",},//OP1 LFO rate
	{ 3,99,0x01,0,0,1,"OP3 OFM",},//OP3 OFM
	{ 3,100,0x0f,0,0,15,"OP3 MUL",},//OP3 MUL
	{ 3,101,0x07,0,0,7,"OP3 DT1",},//OP3 DT1
	{ 3,102,0x03,0,0,3,"OP3 DT2",},//OP3 DT2
	{ 3,103,0x7f,0,0,127,"OP3 OFT",},//OP3 OFT
	{ 3,104,0x7f,0,0,127,"OP4 AR",},//OP4 AR
	{ 3,105,0x7f,0,0,127,"OP4 DR",},//OP4 DR
	{ 3,106,0x7f,0,0,127,"OP4 SL",},//OP4 SR
	{ 3,107,0x7f,0,0,127,"OP4 SR",},//OP4 SL
	{ 3,108,0x7f,0,0,127,"OP4 RR",},//OP4 RR
	{ 3,109,0x7f,0,0,127,"OP4 SRR",},//OP4 SRR
	{ 3,110,0x7f,0,0,127,"OP4 TL",},//OP4 TL
	{ 3,111,0x0f,0,0,15,"OP4 SSG-EG",},//OP4 SSG-EG
	{ 3,112,0x7f,0,0,127,"OP4 EGBIAS",},//OP4 EG BIAS
	{ 3,113,0x03,0,0,3,"OP4 KSL",},//OP4 KSL
	{ 3,114,0x03,0,0,3,"OP4 KSR",},//OP4 KSR
	{ 3,115,0x07,0,0,7,"OP4 WS",},//OP4 WS
	{ 3,116,0x01,0,0,1,"OP4 AME",},//OP4 AME
	{ 3,117,0x01,0,0,1,"OP4 VIB",},//OP4 VIB
	{ 3,118,0x0f,0,0,15,"OP4 LFO fr",},//OP4 LFO freq
	{ 3,119,0x07,0,0,7,"OP4 LFO wf",},//OP4 LFO wave
	{ 3,120,0x7f,0,0,127,"OP4 LFO dp",},//OP4 LFO depth
	{ 3,121,0x7f,0,0,127,"OP4 LFO dl",},//OP4 LFO delay
	{ 3,122,0x7f,0,0,127,"OP4 LFO rt",},//OP1 LFO rate
	{ 3,123,0x01,0,0,1,"OP4 OFM",},//OP4 OFM
	{ 3,124,0x0f,0,0,15,"OP4 MUL",},//OP4 MUL
	{ 3,125,0x07,0,0,7,"OP4 DT1",},//OP4 DT1
	{ 3,126,0x03,0,0,3,"OP4 DT2",},//OP4 DT2
	{ 3,127,0x7f,0,0,127,"OP4 OFT",},//OP4 OFT
	{ 3,255,0x0,0,0,0,"----------",},//nothing
};

const CVoiceEdit::LABELITEM CVoiceEdit::labels[]= {
	{  0,  0, "CH ATTRIBUTE EDITOR", CConsole::CONSATTR(CConsole::CA_YELLOW | CConsole::CA_REV) },
	{  2,  1, "Port:", CConsole::CA_WHITE },
	{ 12,  1, "CH:", CConsole::CA_WHITE },
	{  2,  2, "DEV:", CConsole::CA_WHITE },
	{ 23,  2, "Bank:", CConsole::CA_WHITE },
	{ 34,  2, "Prog:", CConsole::CA_WHITE },
	{  2,  3, "Portamento:", CConsole::CA_WHITE },
	{ 24,  3, "Port.Time :", CConsole::CA_WHITE },
	{  2,  4, "Expression:", CConsole::CA_WHITE },
	{ 24,  4, "Track Vol.:", CConsole::CA_WHITE },
	{  2,  5, "Modulation:", CConsole::CA_WHITE },
	{ 24,  5, "Modul.Rate:", CConsole::CA_WHITE },
	{  2,  6, "Foot Ctrl.:", CConsole::CA_WHITE },
	{ 24,  6, "Foot Rate :", CConsole::CA_WHITE },
	{  2,  7, "Sustain Pd:", CConsole::CA_WHITE },
	{ 24,  7, "Legato Pd.:", CConsole::CA_WHITE },
	{  2,  8, "Force Damp:", CConsole::CA_WHITE },
	{ 24,  8, "Sostenuto :", CConsole::CA_WHITE },
	{  2,  9, "Mono Mode :", CConsole::CA_WHITE },
	{ 24,  9, "Poly Mode :", CConsole::CA_WHITE },
	{  2, 10, "Pitch Bend:", CConsole::CA_WHITE },
	{ 24, 10, "Bend Range:", CConsole::CA_WHITE },
	{  0, 12, "VOICE PARAMETER EDITOR", CConsole::CONSATTR(CConsole::CA_YELLOW | CConsole::CA_REV) },
};

const CVoiceEdit::CURLOC CVoiceEdit::locate[] = {
	/* 0*/ { 8, 1, 2, 255, CVoiceEdit::FUNC_MIDI, 1, 1, 51, 2, },
	/* 1*/ { 16, 1, 2, 255, CVoiceEdit::FUNC_CH, 0, 0, 53, 3, },
	/* 2*/ { 8, 2, 2, 255, CVoiceEdit::FUNC_DEV, 4, 3, 0, 5, },
	/* 3*/ { 30, 2, 2, 255, CVoiceEdit::FUNC_BANK, 2, 4, 1, 6, },
	/* 4*/ { 40, 2, 3, 255, CVoiceEdit::FUNC_PROG, 3, 2, 1, 6, },
	/* 5*/ { 14, 3, 3, 255, CVoiceEdit::FUNC_PORT, 6, 6, 2, 7, },
	/* 6*/ { 36, 3, 3, 255, CVoiceEdit::FUNC_PORTTIME, 5, 5, 4, 8, },
	/* 7*/ { 14, 4, 3, 255, CVoiceEdit::FUNC_EXPR, 8, 8, 5, 9, },
	/* 8*/ { 36, 4, 3, 255, CVoiceEdit::FUNC_VOL, 7, 7, 6, 10, },
	/* 9*/ { 14, 5, 3, 255, CVoiceEdit::FUNC_MODU, 10, 10, 7, 11, },
	/*10*/ { 36, 5, 3, 255, CVoiceEdit::FUNC_MODURATE, 9, 9, 8, 12, },
	/*11*/ { 14, 6, 3, 255, CVoiceEdit::FUNC_FOOT, 12, 12, 9, 13, },
	/*12*/ { 36, 6, 3, 255, CVoiceEdit::FUNC_FOOTRATE, 11, 11, 10, 14, },
	/*13*/ { 14, 7, 3, 255, CVoiceEdit::FUNC_SUSTAIN, 14, 14, 11, 56, },
	/*14*/ { 36, 7, 3, 255, CVoiceEdit::FUNC_LEGATO, 13, 13, 12, 57, },
	/*15*/ { 14, 9, 3, 255, CVoiceEdit::FUNC_MONO, 16, 16, 56, 17, },
	/*16*/ { 36, 9, 3, 255, CVoiceEdit::FUNC_POLY, 15, 15, 57, 18, },
	/*17*/ { 14, 10, 5, 255, CVoiceEdit::FUNC_BEND, 18, 18, 15, 55, },
	/*18*/ { 36, 10, 3, 255, CVoiceEdit::FUNC_BENDRANGE, 17, 17, 16, 55, },

	/*19*/ { 16, 13, 3, 0, CVoiceEdit::FUNC_VOICE, 22, 20, 55, 23, },
	/*20*/ { 36, 13, 3, 1, CVoiceEdit::FUNC_VOICE, 19, 21, 55, 24, },
	/*21*/ { 56, 13, 3, 2, CVoiceEdit::FUNC_VOICE, 20, 22, 55, 25, },
	/*22*/ { 76, 13, 3, 3, CVoiceEdit::FUNC_VOICE, 21, 19, 55, 26, },

	/*23*/ { 16, 14, 3, 4, CVoiceEdit::FUNC_VOICE, 26, 24, 19, 27, },
	/*24*/ { 36, 14, 3, 5, CVoiceEdit::FUNC_VOICE, 23, 25, 20, 28, },
	/*25*/ { 56, 14, 3, 6, CVoiceEdit::FUNC_VOICE, 24, 26, 21, 29, },
	/*26*/ { 76, 14, 3, 7, CVoiceEdit::FUNC_VOICE, 25, 23, 22, 30, },

	/*27*/ { 16, 15, 3, 8, CVoiceEdit::FUNC_VOICE, 30, 28, 23, 31, },
	/*28*/ { 36, 15, 3, 9, CVoiceEdit::FUNC_VOICE, 27, 29, 24, 32, },
	/*29*/ { 56, 15, 3, 10, CVoiceEdit::FUNC_VOICE, 28, 30, 25, 33, },
	/*30*/ { 76, 15, 3, 11, CVoiceEdit::FUNC_VOICE, 29, 27, 26, 34, },

	/*31*/ { 16, 16, 3, 12, CVoiceEdit::FUNC_VOICE, 34, 32, 27, 35, },
	/*32*/ { 36, 16, 3, 13, CVoiceEdit::FUNC_VOICE, 31, 33, 28, 36, },
	/*33*/ { 56, 16, 3, 14, CVoiceEdit::FUNC_VOICE, 32, 34, 29, 37, },
	/*34*/ { 76, 16, 3, 15, CVoiceEdit::FUNC_VOICE, 33, 31, 30, 38, },

	/*35*/ { 16, 17, 3, 16, CVoiceEdit::FUNC_VOICE, 38, 36, 31, 39, },
	/*36*/ { 36, 17, 3, 17, CVoiceEdit::FUNC_VOICE, 35, 37, 32, 40, },
	/*37*/ { 56, 17, 3, 18, CVoiceEdit::FUNC_VOICE, 36, 38, 33, 41, },
	/*38*/ { 76, 17, 3, 19, CVoiceEdit::FUNC_VOICE, 37, 35, 34, 42, },

	/*39*/ { 16, 18, 3, 20, CVoiceEdit::FUNC_VOICE, 42, 40, 35, 43, },
	/*40*/ { 36, 18, 3, 21, CVoiceEdit::FUNC_VOICE, 39, 41, 36, 44, },
	/*41*/ { 56, 18, 3, 22, CVoiceEdit::FUNC_VOICE, 40, 42, 37, 45, },
	/*42*/ { 76, 18, 3, 23, CVoiceEdit::FUNC_VOICE, 41, 39, 38, 46, },

	/*43*/ { 16, 19, 3, 24, CVoiceEdit::FUNC_VOICE, 46, 44, 39, 47, },
	/*44*/ { 36, 19, 3, 25, CVoiceEdit::FUNC_VOICE, 43, 45, 40, 48, },
	/*45*/ { 56, 19, 3, 26, CVoiceEdit::FUNC_VOICE, 44, 46, 41, 49, },
	/*46*/ { 76, 19, 3, 27, CVoiceEdit::FUNC_VOICE, 45, 43, 42, 50, },

	/*47*/ { 16, 20, 3, 28, CVoiceEdit::FUNC_VOICE, 50, 48, 43, 51, },
	/*48*/ { 36, 20, 3, 29, CVoiceEdit::FUNC_VOICE, 47, 49, 44, 52, },
	/*49*/ { 56, 20, 3, 30, CVoiceEdit::FUNC_VOICE, 48, 50, 45, 53, },
	/*50*/ { 76, 20, 3, 31, CVoiceEdit::FUNC_VOICE, 49, 47, 46, 54, },

	/*51*/ { 16, 21, 3, 32, CVoiceEdit::FUNC_VOICE, 54, 52, 47, 0, },
	/*52*/ { 36, 21, 3, 33, CVoiceEdit::FUNC_VOICE, 51, 53, 48, 0, },
	/*53*/ { 56, 21, 3, 34, CVoiceEdit::FUNC_VOICE, 52, 54, 49, 1, },
	/*54*/ { 76, 21, 3, 35, CVoiceEdit::FUNC_VOICE, 53, 51, 50, 1, },

	/*55*/ { 24, 12, 9, 255, CVoiceEdit::FUNC_EDITPAGE, 55, 55, 18, 19, },
	/*56*/ { 14, 8, 3, 255, CVoiceEdit::FUNC_FDAMP, 57, 57, 13, 15, },
	/*57*/ { 36, 8, 3, 255, CVoiceEdit::FUNC_SOSTE, 56, 56, 14, 16, },
};

const int CVoiceEdit::editpages[4][36] = {
	{ 0, 1, 2, 11, /**/ 3, 4, 5, 6, /**/ 7, 8, 9, 10, /**/
	12, 13, 14, 15, /**/ 16, 17, 18, 19, /**/ 20, 21, 22, 23, /**/
	24, 25, 26, 27, /**/ 28, 29, 30, 31, /**/ 32, 33, 34, 35, /**/},
	{ 0, 1, 2, 11, /**/ 3, 4, 5, 6, /**/ 7, 8, 9, 10, /**/
	36, 37, 38, 39, /**/ 40, 41, 42, 43, /**/ 44, 45, 46, 47, /**/
	48, 49, 50, 51, /**/ 52, 53, 54, 55, /**/ 56, 57, 58, 59, /**/},
	{ 0, 1, 2, 11, /**/ 3, 4, 5, 6, /**/ 7, 8, 9, 10, /**/
	60, 61, 62, 63, /**/ 64, 65, 66, 67, /**/ 68, 69, 70, 71, /**/
	72, 73, 74, 75, /**/ 76, 77, 78, 79, /**/ 80, 81, 82, 83, /**/},
	{ 0, 1, 2, 11, /**/ 3, 4, 5, 6, /**/ 7, 8, 9, 10, /**/
	84, 85, 86, 87, /**/ 88, 89, 90, 91, /**/ 92, 93, 94, 95, /**/
	96, 97, 98, 99, /**/ 100, 101, 102, 103, /**/ 104, 105, 106, 107, /**/},
};

const char* CVoiceEdit::pagename[] = {
	"OP1(M1)", "OP2(C1)", "OP3(M2)", "OP4(C2)",
};

CVoiceEdit::CVoiceEdit(CFITOM* parent) : CScreen(parent), cursor(0), port(0), mch(0), curpage(0)
{
	SetEditPage(curpage);
}

int CVoiceEdit::Show(int flag)
{
	int i;
	CConsole* Console = Parent->GetConsole();
	ReadVoice();
	for (i=0; i<(sizeof(labels)/sizeof(LABELITEM)); i++) {
		Parent->GetConsole()->puts(labels[i].x, labels[i].y, labels[i].attr, labels[i].label, strlen(labels[i].label));
	}
	for (i=0; i<(sizeof(locate) / sizeof(CURLOC)); i++) {
		DispValue(locate[i], (cursor == i));
	}
	return 0;
}

int CVoiceEdit::KeyOn(int ch)
{
	CMidiInst* midi = Parent->GetMidiInst(port);
	CMidiCh* pch = midi->GetMidiCh(mch);
	SINT8 diff = 0;
	int ret = 0;
	switch(ch) {
	case KEY_UP://up
		cursor = locate[cursor].up;
		ret = 1;
		break;
	case KEY_DOWN://down
		cursor = locate[cursor].down;
		ret = 1;
		break;
	case KEY_LEFT:
		cursor = locate[cursor].left;
		ret = 1;
		break;
	case KEY_RIGHT:
		cursor = locate[cursor].right;
		ret = 1;
		break;
	case KEY_MINUS:
		ModifyValue(locate[cursor], -1);
		ret = 1;
		break;
	case KEY_PLUS:
		ModifyValue(locate[cursor], 1);
		ret = 1;
		break;
	case KEY_PAGEUP://pageup
		ModifyValue(locate[55], 1);
		ret = 1;
		/*
		if (locate[cursor].param != 255) {
			params[locate[cursor].param] = (params[locate[cursor].param] + 1) % (sizeof(items)/sizeof(EDITITEM));
			ret = 1;
		}
		*/
		break;
	case KEY_PAGEDN://pagedwn
		ModifyValue(locate[55], -1);
		ret = 1;
		/*
		if (locate[cursor].param != 255) {
			params[locate[cursor].param] = params[locate[cursor].param] ? (params[locate[cursor].param] - 1) : (sizeof(items)/sizeof(EDITITEM)-1);
			ret = 1;
		}*/
		break;
	default:
		ret = -1;
		break;
	}
	return ret;
}

void CVoiceEdit::DispValue(const CURLOC& loc, int cur)
{
	CConsole* Console = Parent->GetConsole();
	char tmp[32], tmp2[32], fmt[10];
	CConsole::CONSATTR attr = CConsole::CA_WHITE;
	if (cur) {
		attr = CConsole::CONSATTR(attr | CConsole::CA_REV);
	}
	CMidiInst* midi = Parent->GetMidiInst(port);
	CMidiCh* pch = midi->GetMidiCh(mch);
	UINT8 progno = pch ? pch->GetProgramNo() : 0;
	UINT8 bank = pch ? pch->GetBankNo() : 0;
	sprintf(fmt, "%%0%ii", (UINT16)loc.size);
	switch(loc.func) {
	case FUNC_MIDI:
		sprintf(tmp, fmt, (UINT16)port);
		break;
	case FUNC_CH:
		sprintf(tmp, fmt, (UINT16)mch);
		break;
	case FUNC_DEV:
		{
			UINT8 devid = pch ? Parent->GetInstDeviceIndex(pch->GetDevice()) : 0xff;
			sprintf(tmp, fmt, (UINT16)devid);
			const char* devname = pch ? Parent->GetDeviceNameFromID(pch->GetDeviceID()) : "----";
			Console->puts(loc.x + loc.size + 2, loc.y, CConsole::CA_YELLOW, (char*)"           ", 11);
			Console->puts(loc.x + loc.size + 2, loc.y, CConsole::CA_YELLOW, (char*)devname, strlen(devname));
		}
		break;
	case FUNC_BANK:
		sprintf(tmp, fmt, (UINT16)bank);
		break;
	case FUNC_PROG:
		memset(tmp2, ' ', 16);
		sprintf(tmp, fmt, (UINT16)progno);
		sprintf(tmp2, "%-16s", (const char*)&voice[4]);
		tmp2[16] = '\0';
		Console->puts(loc.x + loc.size + 1, loc.y, CConsole::CA_YELLOW, tmp2, 16);
		break;
	case FUNC_PORT:
		strcpy(tmp, pch ? (pch->GetPortamento() ? "ON " : "OFF") : "---");
		break;
	case FUNC_PORTTIME:
		sprintf(tmp, fmt, pch ? (UINT16)pch->GetPortTime() : 0);
		break;
	case FUNC_EXPR:
		sprintf(tmp, fmt, pch ? (UINT16)pch->GetExpress() : 0);
		break;
	case FUNC_VOL:
		sprintf(tmp, fmt, pch ? (UINT16)pch->GetTrackVolume() : 0);
		break;
	case FUNC_MODU:
		sprintf(tmp, fmt, pch ? (UINT16)pch->GetModulation() : 0);
		break;
	case FUNC_MODURATE:
		sprintf(tmp, fmt, pch ? (UINT16)pch->GetPMRate() : 0);
		break;
	case FUNC_FOOT:
		sprintf(tmp, fmt, pch ? (UINT16)pch->GetFootCtrl() : 0);
		break;
	case FUNC_FOOTRATE:
		sprintf(tmp, fmt, pch ? (UINT16)pch->GetAMRate() : 0);
		break;
	case FUNC_SUSTAIN:
		strcpy(tmp, pch ? (pch->GetSustain() ? "ON " : "OFF") : "---");
		break;
	case FUNC_LEGATO:
		strcpy(tmp, pch ? (pch->GetLegato() ? "ON " : "OFF") : "---");
		break;
	case FUNC_FDAMP:
		strcpy(tmp, pch ? (pch->GetForceDamp() ? "ON " : "OFF") : "---");
		break;
	case FUNC_SOSTE:
		strcpy(tmp, pch ? (pch->GetSostenuto() ? "ON " : "OFF") : "---");
		break;
	case FUNC_MONO:
		strcpy(tmp, pch ? ((pch->GetPoly() <= 1) ? "ON " : "OFF") : "---");
		break;
	case FUNC_POLY:
		sprintf(tmp, fmt, pch ? (UINT16)pch->GetPoly() : 0);
		break;
	case FUNC_BEND:
		sprintf(tmp, fmt, pch ? (SINT16)(pch->GetPitchBend()) : 0);
		break;
	case FUNC_BENDRANGE:
		sprintf(tmp, fmt, pch ? (UINT16)pch->GetBendRange() : 0);
		break;
	case FUNC_VOICE:
		sprintf(tmp, fmt, (UINT16)((voice[items[params[loc.param]].addr] & items[params[loc.param]].mask) >> items[params[loc.param]].shift));
		sprintf(tmp2, "<%02i>%-10s:", loc.param, items[params[loc.param]].label);
		Console->puts((loc.param % 4) * 20, loc.param / 4 + 13, CConsole::CA_CYAN, tmp2, 15);
		break;
	case FUNC_EDITPAGE:
		sprintf(tmp, "<%s>", pagename[curpage]);
		break;
	};
	Console->puts(loc.x, loc.y, attr, tmp, loc.size);
}

void CVoiceEdit::ModifyValue(const CURLOC& loc, int inc)
{
	CMidiInst* midi = Parent->GetMidiInst(port);
	CMidiCh* pch = midi->GetMidiCh(mch);
	switch(loc.func) {
	case FUNC_MIDI:
		if (inc + port < 0) {
			port = Parent->GetMidiInputs() - 1;
		} else {
			port = (port + inc) % Parent->GetMidiInputs();
		}
		break;
	case FUNC_CH:
		mch = (mch + inc) & 0xf;
		break;
	case FUNC_DEV:
		{
			UINT8 devid = pch ? Parent->GetInstDeviceIndex(pch->GetDevice()) : 0xff;
			if (inc + devid < 0) {
				devid = Parent->GetInstDevs() - 1;
			} else {
				devid = (devid + inc) % Parent->GetInstDevs();
			}
			if (pch) {
				WriteVoice();
				pch->BankSelLSB(devid);
				ReadVoice();
			}
		}
		break;
	case FUNC_BANK:
		{
			UINT8 bank = pch ? pch->GetBankNo() : 0;
			if (inc + bank < 0) {
				bank = MAX_BANK - 1;
			} else {
				bank = (bank + inc) % MAX_BANK;
			}
			if (pch) {
				UINT8 progno = pch->GetProgramNo();
				pch->BankSel(bank);
				pch->ProgChange(progno);
				ReadVoice();
			}
		}
		break;
	case FUNC_PROG:
		if (pch) {
			UINT8 progno = pch ? pch->GetProgramNo() : 0;
			progno = (progno + inc) & 0x7f;
			pch->ProgChange(progno);
			ReadVoice();
		}
		break;
	case FUNC_PORT:
		if (pch) {
			pch->SetPortamento(pch->GetPortamento() ? 0 : 64);
		}
		break;
	case FUNC_PORTTIME:
		if (pch) {
			pch->SetPortTime((pch->GetPortTime() + inc) & 0x7f);
		}
		break;
	case FUNC_EXPR:
		if (pch) {
			pch->SetExpress((pch->GetExpress() + inc) & 0x7f);
		}
		break;
	case FUNC_VOL:
		if (pch) {
			pch->SetVolume((pch->GetTrackVolume() + inc) & 0x7f);
		}
		break;
	case FUNC_MODU:
		if (pch) {
			pch->SetModulation((pch->GetModulation() + inc) & 0x7f);
		}
		break;
	case FUNC_MODURATE:
		if (pch) {
			pch->SetPMRate((pch->GetPMRate() + inc) & 0x7f);
		}
		break;
	case FUNC_FOOT:
		if (pch) {
			pch->SetFootCtrl((pch->GetFootCtrl() + inc) & 0x7f);
		}
		break;
	case FUNC_FOOTRATE:
		if (pch) {
			pch->SetAMRate((pch->GetAMRate() + inc) & 0x7f);
		}
		break;
	case FUNC_SUSTAIN:
		if (pch) {
			pch->SetSustain(pch->GetSustain() ? 0 : 64);
		}
		break;
	case FUNC_LEGATO:
		if (pch) {
			pch->SetLegato(pch->GetLegato() ? 0 : 64);
		}
		break;
	case FUNC_FDAMP:
		if (pch) {
			pch->SetForceDamp(pch->GetForceDamp() ? 0 : 64);
		}
		break;
	case FUNC_SOSTE:
		if (pch) {
			pch->SetSostenuto(pch->GetSostenuto() ? 0 : 64);
		}
		break;
	case FUNC_MONO:
		if (pch) {
			pch->SetPoly((pch->GetPoly()>1) ? 1 : 255);
		}
		break;
	case FUNC_POLY:
		if (pch) {
			pch->SetPoly((pch->GetPoly() + inc));
		}
		break;
	case FUNC_BEND:
		if (pch) {
			pch->SetPitchBend((pch->GetPitchBend() + inc) & 0x3fff);
		}
		break;
	case FUNC_BENDRANGE:
		if (pch) {
			pch->SetBendRange((pch->GetBendRange() + inc) % 24);
		}
		break;
	case FUNC_VOICE:
		{
			UINT8 value = (voice[items[params[loc.param]].addr]  & items[params[loc.param]].mask) >> items[params[loc.param]].shift;
			value = ((value + inc)&(items[params[loc.param]].mask>>items[params[loc.param]].shift)) << items[params[loc.param]].shift;
			voice[items[params[loc.param]].addr] = (voice[items[params[loc.param]].addr] & 
				(~items[params[loc.param]].mask)) | value;
			if (pch) {
				pch->SetVoiceAddr(items[params[loc.param]].addr);
				pch->SetVoiceData(voice[items[params[loc.param]].addr]);
				WriteVoice();
			}
		}
		break;
	case FUNC_EDITPAGE:
		curpage = (curpage + inc) & 3;
		SetEditPage(curpage);
		break;
	};
}

void CVoiceEdit::ReadVoice()
{
	CMidiInst* midi = Parent->GetMidiInst(port);
	CMidiCh* pch = midi->GetMidiCh(mch);
	UINT8 progno = pch ? pch->GetProgramNo() : 0;
	UINT8 bank = pch ? pch->GetBankNo() : 0;
	UINT8 dev = pch ? pch->GetDeviceID() : 0xff;
	Parent->GetVoice((FMVOICE*)voice, dev, bank, progno);
}

void CVoiceEdit::WriteVoice()
{
	CMidiInst* midi = Parent->GetMidiInst(port);
	CMidiCh* pch = midi->GetMidiCh(mch);
	UINT8 progno = pch ? pch->GetProgramNo() : 0;
	UINT8 bank = pch ? pch->GetBankNo() : 0;
	UINT8 dev = pch ? pch->GetDeviceID() : 0xff;
	//voice[1] = (voice[1] + 1) & 0xff;
	Parent->SetVoice((FMVOICE*)voice, dev, bank, progno);
	pch->SetVoiceData((FMVOICE*)voice);
}

void CVoiceEdit::SetEditPage(int page)
{
	for (int i=0; i<36; i++) {
		params[i] = editpages[page][i];
	}
}
