#include "stdafx.h"
#include "FMIDI98.h"
#include "OPN.h"
#include "OPM.h"
#include "OPL.h"
#include "OPLL.h"
#include "SSG.h"
#include "MIDIDEV.h"
#include "MIDI.h"

CPort* CFMIDI98::CreatePort(int pttype, char* params)
{
	CPort* ret = 0;
	CHostIF* ioif = 0;
	char iftype[16];
	char portdef[80];
	UINT16 a0, a1, d0, d1, id, w1, w2;
	w1 = 7;
	w2 = 39;
	if (strchr(params, ':') > 0) {
		sscanf(params, "%[^:]: %i,%s", iftype, &id, portdef);
//		sscanf(params, "%[^:]:%i: %i, %i, %hx, %hx, %hx, %hx", iftype, &id, &w1, &w2, &a0, &d0, &a1, &d1);
		if (strcmp(iftype, "IO") == 0) {  //Direct I/O
			ioif = GetIOIF(CHostIF::IO98);
		}
	} else {
		ioif = GetIOIF(CHostIF::IO98);
		strncpy(portdef, params, 80);
		//sscanf(params, "%hx, %hx, %hx, %hx", iftype, &a0, &d0, &a1, &d1);
	}
	if (ioif == 0) { return 0; }
	switch (pttype) {
	case 0: // 1 address port (for DCSG series)
		sscanf(portdef, "%i, %i, %hx", &w1, &w2, &a0);
		ret = new CSNPort(a0, ioif);
		break;
	case 1: // 1 address & data ports (most of sound chip)
		sscanf(portdef, "%i, %i, %hx, %hx", &w1, &w2, &a0, &d0);
		ret = new CIOPort(a0, d0, a0, w1, w2, 0, ioif);
		break;
	case 2: // 2 sets of address & data (OPL3/OPNA/OPNB/OPN2/OPN3 etc.)
		sscanf(portdef, "%i, %i, %hx, %hx, %hx, %hx", &w1, &w2, &a0, &d0, &a1, &d1);
		ret = new CDblPort(new CIOPort(a0, d0, a0, w1, w2, 0, ioif), new CIOPort(a1, d1, a0, w1, w2, 0, ioif));
		break;
	}
	return ret;
}

int CFMIDI98::LoadMidiConfig(FILE* fp)
{
	char tmp[80];
	CMidiIn* pmi;
	CMidiOut* pmo;
	while(fgets(tmp, 80, fp) != NULL) {
		char devtyp[16];
		char mode[8];
		char iftyp[16];
		char params[40];
		if (strncmp("MPU401:", tmp, 7) == 0) {
			sscanf(&tmp[7], " %x, %x ", &wp1, &wp2);
			pmi = new CMPU401(wp1, wp2);
			if (pmi) {
				AddDevice((CMidiOut*)AddDevice(pmi));
				printf("MPU-401 UART setting on 0x%04X, 0x%04X as port %i...\n", wp1, wp2, mpus);
			}
		}
		if (strncmp("YMZ263:", tmp, 7) == 0) {
			sscanf(&tmp[7], " %x, %x ", &wp1, &wp2);
			pmi = new CYMZ263Midi(new CIOPort(wp1, wp2, wp1, 0, 0, 0));
			if (pmi) {
				AddDevice((CMidiOut*)AddDevice(pmi));
				printf("YMZ263B UART setting on 0x%04X, 0x%04X as port %i...\n", wp1, wp2, mpus);
			}
		}
		if (strncmp("RSMIDI:", tmp, 7) == 0) {
			pmi = new CRSMidi();
			if (pmi) {
				AddDevice((CMidiOut*)AddDevice(pmi));
				printf("RS-MIDI UART setting on RS-232C as port %i...\n", mpus);
			}
		}
		if (strncmp("MPU401OUT:", tmp, 10) == 0) {
			sscanf(&tmp[10], " %x, %x ", &wp1, &wp2);
			if (AddDevice((CMidiOut*)new CMPU401(wp1, wp2))>=0) {
				printf("MPU-401 UART setting on 0x%04X, 0x%04X as port %i...\n", wp1, wp2, mpus);
			}
		}
		if (strncmp("YMZ263OUT:", tmp, 10) == 0) {
			sscanf(&tmp[10], " %x, %x ", &wp1, &wp2);
			if (AddDevice((CMidiOut*)new CYMZ263Midi(new CIOPort(wp1, wp2, wp1, 0, 0, 0)))>=0) {
				printf("YMZ263B UART setting on 0x%04X, 0x%04X as port %i...\n", wp1, wp2, mpus);
			}
		}
		if (strncmp("RSMIDIOUT:", tmp, 10) == 0) {
			if (AddDevice((CMidiOut*)new CRSMidi())>=0) {
				printf("RS-MIDI UART setting on RS-232C as port %i...\n", mpus);
			}
		}
		if (strncmp("MPU401IN:", tmp, 9) == 0) {
			sscanf(&tmp[9], " %x, %x ", &wp1, &wp2);
			if (AddDevice((CMidiIn*)new CMPU401(wp1, wp2))>=0) {
				printf("MPU-401 UART setting on 0x%04X, 0x%04X as port %i...\n", wp1, wp2, mpus);
			}
		}
		if (strncmp("YMZ263IN:", tmp, 9) == 0) {
			sscanf(&tmp[9], " %x, %x ", &wp1, &wp2);
			if (AddDevice((CMidiIn*)new CYMZ263Midi(new CIOPort(wp1, wp2, wp1, 0, 0, 0)))>=0) {
				printf("YMZ263B UART setting on 0x%04X, 0x%04X as port %i...\n", wp1, wp2, mpus);
			}
		}
		if (strncmp("RSMIDIIN:", tmp, 9) == 0) {
			if (AddDevice((CMidiIn*)new CRSMidi())>=0) {
				printf("RS-MIDI UART setting on RS-232C as port %i...\n", mpus);
			}
		}
	}
	if (!mpus) { return -1; }
	if (!devs) { return -2; }
	return 0;
}

