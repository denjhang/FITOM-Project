#include "STDAFX.H"
#include "Console.h"
#include <conio.h>

CConsole::CConsole()
{
	COORD ord;
	ord.X = 80;
	ord.Y = 25;
	hCons = ::CreateConsoleScreenBuffer(GENERIC_READ | GENERIC_WRITE, 0, 0, CONSOLE_TEXTMODE_BUFFER, 0);
	SetConsoleScreenBufferSize(hCons, ord);
	SetConsoleActiveScreenBuffer(hCons);
}


CConsole::~CConsole()
{
	CloseHandle(hCons);
}

void CConsole::cls()
{
	COORD ord;
	DWORD result;
	WORD wAttribute = FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY;
	ord.X = ord.Y = 0;
	FillConsoleOutputAttribute(hCons, wAttribute, 80*25, ord, &result);
	FillConsoleOutputCharacter(hCons, ' ', 80*25, ord, &result);
}

void CConsole::puts(int x, int y, CONSATTR attr, char* str, int max)
{
	char* tmp = new char[max+1];
	memset(tmp, ' ', max);
	memcpy(tmp, str, max);
	COORD ord;
	ord.X = x;
	ord.Y = y;
	DWORD result;
	WORD watr = BACKGROUND_INTENSITY;
	watr = FOREGROUND_INTENSITY;
	watr |= ((attr&CA_RED) ? FOREGROUND_RED : 0);
	watr |= ((attr&CA_GREEN) ? FOREGROUND_GREEN : 0);
	watr |= ((attr&CA_BLUE) ? FOREGROUND_BLUE : 0);
	watr <<= ((attr&CA_REV) ? 4 : 0);
	FillConsoleOutputAttribute(hCons, watr, max, ord, &result);
	WriteConsoleOutputCharacter(hCons, tmp, max, ord, &result);
	delete[] tmp;
}

void CConsole::putc(int x, int y, CONSATTR attr, int c)
{
	COORD ord;
	ord.X = x;
	ord.Y = y;
	DWORD result;
	WORD watr = BACKGROUND_INTENSITY;
	watr = FOREGROUND_INTENSITY;
	watr |= ((attr&CA_RED) ? FOREGROUND_RED : 0);
	watr |= ((attr&CA_GREEN) ? FOREGROUND_GREEN : 0);
	watr |= ((attr&CA_BLUE) ? FOREGROUND_BLUE : 0);
	watr <<= ((attr&CA_REV) ? 4 : 0);
	WriteConsoleOutputAttribute(hCons, &watr, 1, ord, &result);
	WriteConsoleOutputCharacter(hCons, (LPTSTR)&c, 1, ord, &result);
}

int CConsole::inkey()
{
	return kbhit();
}

int CConsole::getch()
{
	return ::getch();
}
