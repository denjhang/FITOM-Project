#ifndef __MIDIIN_H__
#define __MIDIIN_H__

#include "Port.h"

class CMidiIn {
protected:
	char desc[32];
public:
	CMidiIn() {};
	~CMidiIn() {};
	virtual UINT8	IsInput() = 0;
	virtual UINT8	GetData() = 0;
	virtual const char* GetDescriptor() { return desc; };
};

class CMPU401MidiIn : public CMidiIn
{
public:
	CMPU401MidiIn(UINT16 dtport, UINT16 stport);
	~CMPU401MidiIn();
	virtual UINT8	IsInput();
	UINT8	IsOutput();
	virtual UINT8	GetData();
	UINT8	GetStat();
	void	SetStat(UINT8 data);
protected:
	UINT16 portd;
	UINT16 ports;
};

class CYMZ263MidiIn : public CMidiIn
{
public:
	CYMZ263MidiIn(CPort* devport);
	~CYMZ263MidiIn();
	virtual UINT8	IsInput();
	virtual UINT8	GetData();
protected:
	CPort* port;
};

class CRSMidiIn : public CMidiIn
{
public:
	CRSMidiIn();
	~CRSMidiIn();
	virtual UINT8	IsInput();
	UINT8	IsOutput();
	virtual UINT8	GetData();
};


#ifdef _WIN32
class CW32MidiIn : public CMidiIn
{
public:
	CW32MidiIn(char* name);
	~CW32MidiIn();
	virtual UINT8	IsInput();
	virtual UINT8	GetData();
	static void CALLBACK MidiInProc(HMIDIIN hMidiIn, UINT wMsg, DWORD dwInstance, DWORD dwParam1, DWORD dwParam2);
protected:
	HMIDIIN hIn;
	HMIDIOUT hOut;
	MIDIHDR mhdr;
	UINT8 buf[1024];
	DWORD rpt;
	DWORD wpt;
};

class CW32RsMidi : public CMidiIn
{
protected:
	HANDLE hCom;
	DCB dcb;
public:
	CW32RsMidi(char* name);
	~CW32RsMidi();
	virtual UINT8	IsInput();
	virtual UINT8	GetData();
};
#endif

#endif
