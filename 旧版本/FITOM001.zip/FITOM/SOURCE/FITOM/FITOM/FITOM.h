#ifndef __FMIDI98_H__
#define __FMIDI98_H__

//Resource code
#define	DEVICE_NONE	0
#define	DEVICE_SSG	1	//YM2149
#define	DEVICE_OPN	2	//YM2203
#define	DEVICE_OPN2	3	//YM2612
#define	DEVICE_OPNA	4	//YM2608
#define	DEVICE_OPM	5	//YM2151
#define	DEVICE_OPLL	6	//YM2413
#define	DEVICE_OPL	7	//YM3526
#define	DEVICE_OPL2	8	//YM3812
#define	DEVICE_OPL3	9	//YMF262
#define DEVICE_OPN3L 10	//YMF288
#define DEVICE_OPNB 11	//YM2610
#define	DEVICE_PSG	15	//AY-3-891x
#define	DEVICE_DCSG	16	//SN76489
#define	DEVICE_SCC	17
#define	DEVICE_SSGS	18	//YMZ705
#define	DEVICE_APSG	19	//AY8930
#define DEVICE_SSGL 20	//YMZ284
#define DEVICE_SSGLP 21	//YMZ294
#define	DEVICE_Y8950	24	//YM3801 a.k.a. MSX-AUDIO
#define	DEVICE_OPL3_2	25	//2op ch of OPL3
#define	DEVICE_OPP	26	//YM2164
#define	DEVICE_OPZ	27	//YM2414
#define	DEVICE_OPZ2	28	//YM2424
#define	DEVICE_OPLLP	29	//YMF281
#define	DEVICE_2420	30	//YM2420
#define DEVICE_OPNC 31	//YMF264
#define DEVICE_OPN2C 32	//YM3438
#define DEVICE_OPN2L 33	//YMF276
#define DEVICE_2610B 34	//YM2610B
#define DEVICE_F286 35	//YMF286-K
#define DEVICE_OPK 40	//YM7116
#define DEVICE_OPK2 41	//YM7129
#define DEVICE_OPN3 64	//YMF297
#define DEVICE_OPN3_L3 65	//OPL mode of YMF297
#define DEVICE_OPN3_N3 66	//OPN mode of YMF297


#define	DEVICE_ADPCM	257

#define VOICE_TYPE_OPM  0x10
#define VOICE_TYPE_OPN  0x11
#define VOICE_TYPE_OPNA	 0x12
#define VOICE_TYPE_OPZ  0x13

#define VOICE_TYPE_OPL2 0x20
#define VOICE_TYPE_OPL  0x21
#define VOICE_TYPE_OPLL 0x22

#define VOICE_TYPE_OPL3 0x30

#define VOICE_TYPE_SSG  0x40
#define VOICE_TYPE_APSG 0x41
#define VOICE_TYPE_DCSG 0x42

#define VOICE_TYPE_DRUM 0x50

#define MAX_BANK 16
#define MAX_MPUS 4
#define MAX_DEVS 64
#define MAX_IOIF 16
#define MAX_SCREEN 16

#ifdef _DOS
#define KEY_UP     0x3a
#define KEY_RIGHT  0x3c
#define KEY_LEFT   0x3b
#define KEY_DOWN   0x3d
#define KEY_HOME   0x3e
#define KEY_ESC    0x1b00
#define KEY_PAGEUP 0x37
#define KEY_PAGEDN 0x36
#define KEY_F1     0x62
#define KEY_F2     0x63
#define KEY_F3     0x64
#define KEY_F4     0x65
#define KEY_F5     0x66
#define KEY_PLUS   0x2b49
#define KEY_MINUS  0x2d40
#endif
#ifdef _WIN32
#define KEY_UP     0x48
#define KEY_RIGHT  0x4d
#define KEY_LEFT   0x4b
#define KEY_DOWN   0x50
#define KEY_ESC    0x1b
#define KEY_HOME   0x47
#define KEY_PAGEUP 0x49
#define KEY_PAGEDN 0x51
#define KEY_F1     0x3b
#define KEY_F2     0x3c
#define KEY_F3     0x3d
#define KEY_F4     0x3e
#define KEY_F5     0x3f
#define KEY_PLUS   0x2b
#define KEY_MINUS  0x2d
#endif

void Error(int code);

class CSoundDevice;
class CMidiInst;
class CMidiIn;
class CMidiOut;
class CXmemFile;
class CConsole;
class IScreen;

#include "Port.h"

struct FMVOICE;

class CFITOM {
public:
	struct DRUMMAP {
		CSoundDevice* device;
		UINT8 devID;
		UINT8 bank;
		UINT8 prog;
		SINT8 pan;
		UINT8 num;
		UINT8 alt[5];
		UINT16 fnum;
		UINT16 gate;
	};
protected:
	CSoundDevice* fmdev[MAX_DEVS];
	CMidiIn* mpu[MAX_MPUS];
	CMidiOut* ompu[MAX_MPUS];
	CMidiInst* midi[MAX_MPUS];
	CHostIF* pioif[MAX_IOIF];
	UINT8 devs;
	UINT8 mpus;
	UINT8 ompus;
	UINT8 ioifs;
 	UINT16 MasterVolume;
	int redraw;
	volatile int timerprocessing;
	volatile int pollprocessing;
	UINT16 timerskipped;

	//Configuration
	CPort* CreatePort(int pttype, char* params);
	int CreateSingleDevice(int devtype, char* param);
	int CreateDualDevice(int devtype, char* param);
	int LoadConfig();
	int LoadDeviceConfig(FILE* fp);
	int LoadMidiConfig(FILE* fp);
	int LoadVoiceConfig(FILE* fp);
	int LoadMapConfig(FILE* fp);
	int LoadVoice(int bank, CXmemFile* voice, char* filename);
	int LoadDrumMap(int bank, char*filename);
	int LoadIOIF(FILE* fp);
	int SaveVoice(int bank, CXmemFile* voice, char* filename);
	int InitVoice(int type, int banks, CXmemFile* voice);
#ifdef _WIN32
#endif

	//Device management
	CSoundDevice* AddDevice(CSoundDevice* pdev);
	int AddDevice(CMidiIn* pmpu);
	int AddDevice(CMidiOut* pmpu);
	CHostIF* GetIOIF(CHostIF::IOIF_TYPE type, UINT32 id=0);

	//User Interface
	int Display();
	int KeyOn();

	//Data management
	CXmemFile* opmbank;	//OPM/OPP/OPZ
	CXmemFile* opnabank;	//OPN/OPNA/OPNB/OPN2/OPN3
	CXmemFile* opl2bank;	//OPL/OPL2/Y8950
	CXmemFile* opl3bank;	//OPL3
	CXmemFile* opllbank;	//OPLL/YMF281
	CXmemFile* psgbank;	//PSG/APSG/SSG/SSGS/SSGL
	CXmemFile* drummap;
	CConsole* Console;
public:
	//Initialize and Finalize
	static CFITOM* GetInstance() {
		static CFITOM theInstance;
		return & theInstance;
	};
	~CFITOM(){};
	int InitInstance();
	void ExitInstance(int save=0);

	//Query
	int GetVoice(FMVOICE* voice, UINT8 dev, UINT8 bank, UINT8 num);
	int GetDrum(DRUMMAP* drum, UINT8 bank, UINT8 prog, UINT8 note);
	const UINT8 GetMidiInputs() const { return mpus; };
	const UINT8 GetMidiOutputs() const { return ompus; };
	const UINT8 GetInstDevs() const { return devs; };
	CConsole* GetConsole() const { return Console; };
	CMidiIn* GetMidiIn(UINT8 i) const { return (i<mpus) ? mpu[i] : NULL; };
	CMidiOut* GetMidiOut(UINT8 i) const { return (i<ompus) ? ompu[i] : NULL; };
	CMidiInst* GetMidiInst(UINT8 i) const { return (i<mpus) ? midi[i] : NULL; };
	CSoundDevice* GetInstDeviceFromIndex(UINT8 i) const { return (i<devs) ? fmdev[i] : NULL; };
	CSoundDevice* GetInstDeviceFromID(UINT8 devid);
	int GetInstDeviceIndex(const CSoundDevice* pdev);
	int GetInstDeviceIndex(UINT8 devid);

	int SetVoice(FMVOICE* voice, UINT8 dev, UINT8 bank, UINT8 num);

	//Callback
	int PollingCallBack();
	void TimerCallBack(UINT32 tick);

	void SetRedraw(int flag) { redraw = flag; };
	int GetRedraw() { return redraw; };

	//Utility
	static UINT8 GetDeviceIDFromName(char* name);
	static const char* GetDeviceNameFromID(UINT8 devid);
	static UINT8 GetVoiceType(UINT8 device);
	void AllNoteOff();
	void ResetAllCtrl();
private:
	CFITOM();
	CFITOM& operator=(CFITOM& rhs);
	CFITOM(CFITOM& rhs);
};

#endif //__FMIDI98_H__
