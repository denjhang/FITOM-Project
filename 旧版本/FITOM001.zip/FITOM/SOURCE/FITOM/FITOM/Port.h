#ifndef __PORT_H__
#define __PORT_H__

class CHostIF {
public:
	enum IOIF_TYPE { IOIF_NONE=-1, SPFM, BIRTH, C86CTL, PCIDEB, FT2232, IO98, };
protected:
	IOIF_TYPE iftype;
	UINT32 ifid;
public:
	CHostIF(UINT32 id, IOIF_TYPE type=IOIF_NONE) : ifid(id), iftype(type) {};
	~CHostIF() {};
	IOIF_TYPE GetIFType() { return iftype; };
	UINT32 GetIFID() { return ifid; };
	int isValid() { return (IOIF_NONE != iftype); };
	virtual void flush() = 0;
	virtual void write(UINT16 addr1, UINT16 addr2, UINT16 reg, UINT16 data, UINT16 w1, UINT16 w2) = 0;
	virtual void write(UINT16 addr, UINT16 data, UINT16 w) = 0;
	virtual UINT8 read(UINT16 addr, UINT16 reg, UINT16 w) = 0;
	virtual UINT8 read(UINT16 addr) = 0;
	virtual void wait(int count) = 0;
	virtual void reset() = 0;
};

#ifdef _DOS
class C98IO : public CHostIF {
public:
	C98IO() : ifid(0) {};
	virtual void flush() {};
	virtual void write(UINT16 addr1, UINT16 addr2, UINT16 reg, UINT16 data, UINT16 w1, UINT16 w2);
	virtual void write(UINT16 addr, UINT16 data, UINT16 w);
	virtual UINT8 read(UINT16 addr, UINT16 reg, UINT16 w);
	virtual UINT8 read(UINT16 addr);
	virtual void wait(int count);
	virtual void reset() {};
};
#endif

#ifdef _WIN32
#include "ftd2xx.h"

class CBufferedIO : public CHostIF {
protected:
	BYTE SendBuff[1024];
	DWORD SendLen;
	virtual void push(UINT8 data);
public:
	CBufferedIO(UINT32 id, CHostIF::IOIF_TYPE type=IOIF_NONE) : CHostIF(id, type), SendLen(0) {};
	virtual void flush() = 0;
	virtual void write(UINT16 addr1, UINT16 addr2, UINT16 reg, UINT16 data, UINT16 w1, UINT16 w2) = 0;
	virtual void write(UINT16 addr, UINT16 data, UINT16 w) = 0;
	virtual UINT8 read(UINT16 addr, UINT16 reg, UINT16 w) = 0;
	virtual UINT8 read(UINT16 addr) = 0;
	virtual void wait(int count) = 0;
	virtual void reset() { SendLen = 0; };
};

class CSPFMFT : public CBufferedIO {
protected:
	FT_HANDLE ftHandle;
	OVERLAPPED ovl;
	UINT8 prevaddr;
public:
	CSPFMFT(UINT32 id, char* sn);
	~CSPFMFT();
	virtual void flush();
	virtual void write(UINT16 addr1, UINT16 addr2, UINT16 reg, UINT16 data, UINT16 w1, UINT16 w2);
	virtual void write(UINT16 addr, UINT16 data, UINT16 w);
	virtual UINT8 read(UINT16 addr, UINT16 reg, UINT16 w);
	virtual UINT8 read(UINT16 addr);
	virtual void wait(int count);
	virtual void reset();
};

class CReBirth : public CBufferedIO {
protected:
	FT_HANDLE ftHandle;
public:
	CReBirth(UINT32 id, char* sn);
	~CReBirth();
	virtual void flush();
	virtual void write(UINT16 addr1, UINT16 addr2, UINT16 reg, UINT16 data, UINT16 w1, UINT16 w2);
	virtual void write(UINT16 addr, UINT16 data, UINT16 w);
	virtual UINT8 read(UINT16 addr, UINT16 reg, UINT16 w);
	virtual UINT8 read(UINT16 addr);
	virtual void wait(int count);
	virtual void reset();
};

#endif

class CPort
{
public:
	CPort(void) {};
	~CPort(void) {};
	virtual void write(UINT16 addr, UINT16 data, int v) = 0;
	virtual UINT8 read(UINT16 addr, int v) = 0;
	virtual UINT8 status() = 0;
	virtual int GetDesc(char* str) = 0;
};

class CIOPort : public CPort
{
public:
	CIOPort(UINT16 sad, UINT16 sdt, UINT16 sst, UINT8 aw=0, UINT8 dw=0, UINT8 bm=0, CHostIF* ioif=0);
	~CIOPort() {};
	virtual void write(UINT16 addr, UINT16 data, int v);
	virtual UINT8 read(UINT16 addr, int v);
	virtual UINT8 status();
	virtual int GetDesc(char* str);
protected:
	CHostIF* pioif;
	UINT8	busy;
	UINT16	addr;
	UINT16	data;
	UINT16	stat;
	UINT16	await;
	UINT16	dwait;
	UINT8 regbak[256];
};

class CSNPort : public CPort
{
public:
	CSNPort(UINT16 addr=0, CHostIF* ioif=0);
	~CSNPort() {};
	virtual void write(UINT16 addr, UINT16 data, int v);
	virtual UINT8 read(UINT16 addr, int v) { return 0; };
	virtual UINT8 status() { return 0; };
	virtual int GetDesc(char* str);
protected:
	CHostIF* pioif;
	UINT16 addr;
	void write(UINT8 data);
};

class CDblPort : public CPort
{
public:
	CDblPort(CPort* pta, CPort* ptb);
	~CDblPort() {};
	virtual void write(UINT16 addr, UINT16 data, int v);
	virtual UINT8 read(UINT16 addr, int v);
	virtual UINT8 status();
	virtual int GetDesc(char* str);
	CPort* GetSubPort(int idx);
protected:
	CPort* port[2];
};

#endif
