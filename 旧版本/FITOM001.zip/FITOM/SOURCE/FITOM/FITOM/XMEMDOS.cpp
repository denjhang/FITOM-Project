#include "STDAFX.H"
#include "XmemFile.h"

extern "C" {
#include "XMS.H"
};

static XMSInit xms;

XMSInit::XMSInit() {
	void* res = GetXMSentry();
	if (!res) {
		printf("XMS initialize failed.\n");
		_exit(-1);
	} else {
		printf("XMS initialize succeeded.\n");
	}
}

XMSInit::~XMSInit() { }

int CXmemFile::Alloc(UINT32 size)
{
	int res = XMSalloc( size, &xmem );
	if (res) {
		actsize = ((size >> 10) + ((size&1023) ? 1 : 0)) << 10;
		pos = 0L;
	}
	return (!res) ? -1 : 0;
}

int CXmemFile::Read(void* dst, UINT32 size)
{
	ExMemMov ( XMSGET, &xmem, dst, size );
	return 0;
}

int CXmemFile::Write(void* src, UINT32 size)
{
	ExMemMov ( XMSPUT, &xmem, src, size );
	return 0;
}

int CXmemFile::Seek(SINT32 offset, int origin)
{
	switch (origin) {
	case 0:	//top
		if (offset < 0 || offset > actsize) { return -1; }
		pos = offset;
		break;
	case 1:	//current
		if ((pos+offset) < 0 || (pos+offset) > actsize) { return -1; }
		pos += offset;
		break;
	case 2:	//end
		if (SINT32(actsize+offset) < 0 || (actsize+offset) > actsize) { return -1; }
		pos = actsize + offset;
		break;
	}
	xmem.linptr = pos;
	return 0;
}

int CXmemFile::Free()
{
	return XMSfree (xmem.handle);
}
