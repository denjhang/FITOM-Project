#include "STDAFX.H"
#include "ADPCM.h"
