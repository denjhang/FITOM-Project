#include "STDAFX.h"
#include "FITOM.h"
#include "OPL.h"
#include "MIDI.h"

#define ADDR_WAIT	6
#define DATA_WAIT	39

UINT8 COPL3::opmap[] = {0x0, 0x3, 0x8, 0xb, };
UINT8 COPL3::carmsk[] = { 0x2, 0x3, 0x8, 0xc, 0x8, 0x9, 0xa, 0xd, 0xa, 0xe, 0xb, 0xf, 0xa, 0xe, 0xb, 0xf, };

COPL3::COPL3(CDblPort* pt, UINT8 fsamp) :
	CSoundDevice(DEVICE_OPL3, 6, fsamp, pt)
{
	SetReg(0x01, 0x20);	//Enable WS
	SetReg(0x105, 0x01);	//Enable OPL3
}

void COPL3::UpdateVoice(UINT8 ch)
{
	CHATTR* attr = GetChAttribute(ch);
	FMVOICE* voice = attr->GetVoice();
	CMidiCh* parent = attr->GetParent();
	UINT8 mode = voice->AL & 0x0c;
	UINT16 rop = (ch > 2) ? 0x100 : 0;
	UINT8 dch = rop ? (ch-3) : ch;
	UINT8 tmp, i;

	for(i=0; i<4; i++)
	{
		tmp = ((voice->op[i].AM & 0x1) << 7) | ((voice->op[i].VIB & 0x1) << 6) |
			((voice->op[i].SR)?0:0x20) | ((voice->op[i].KSR & 0x1) << 4) |
			(voice->op[i].MUL & 0x0F);
		SetReg(rop + 0x20 + opmap[i] + dch, tmp);

		tmp = (UINT8)((voice->op[i].KSL << 6) | voice->op[i].TL);
		SetReg(rop + 0x40 + opmap[i] + dch, tmp);

		tmp = ((voice->op[i].AR & 0xf) << 4) | (voice->op[i].DR & 0xf);
		SetReg(rop + 0x60 + opmap[i] + dch, tmp);

		UINT8 rr = ((parent && parent->GetSustain() && (carmsk[voice->AL&0xf]&(1<<i))) ?
			voice->op[i].REV : (voice->op[i].SR ? voice->op[i].SR : voice->op[i].RR)) & 0xf;
		tmp = ((voice->op[i].SL & 0xf) << 4) | rr;
		SetReg(rop + 0x80 + opmap[i] + dch, tmp);

		SetReg(rop + 0xe0 + opmap[i] + dch, voice->op[i].WS);
	}
	tmp = (GetReg(rop + 0xc0 + dch, 0) & 0xf0) | ((voice->FB & 0x7) << 1) | (voice->AL & 0x1);
	SetReg(rop + 0xc0 + dch, tmp);
	tmp = (GetReg(rop + 0xc3 + dch, 0) & 0xf0) | ((voice->FB >> 3) & 0xe) | ((voice->AL >> 1) & 0x1);
	SetReg(rop + 0xc3 + dch, tmp);

	UINT8 con = GetReg(0x104, 0) & ~(1 << ch);
	if (mode & 0x04) {// CON=1
		SetReg(0x104, con | (1 << ch));
	} else {// CON=0
		SetReg(0x104, con);
	}
	UpdateVolExp(ch);
}

void COPL3::UpdateVolExp(UINT8 ch)
{
	CHATTR* attr = GetChAttribute(ch);
	FMVOICE* voice = attr->GetVoice();

	UINT8 mode = voice->AL & 0x0c;
	UINT16 rop = (ch > 2) ? 0x100 : 0;
	UINT8 dch = rop ? (ch-3) : ch;
	UINT8 evol = attr->GetEffectiveLevel();
	for (int i=0; i<4; i++) {
		if ((1 << i) & carmsk[voice->AL & 0xf]) {
			UINT8 tl;
			UINT8 tmp;
			tl = CalcEffectiveLevel(evol, (voice->op[i].TL << 1) | (voice->op[i].TL >> 5)) >> 1;
			attr->baseTL[i] = tl;
			tmp = (UINT8)((voice->op[i].KSL << 6) | tl);
			SetReg(rop + 0x40 + opmap[i] + dch, tmp);
		}
	}
}

void COPL3::UpdatePanpot(UINT8 ch)
{
	int pan = (GetChAttribute(ch)->panpot) / 16;
	UINT8 chena = 0;
	if (pan == 0) { //C
		chena = 0x30;
	} else if (pan > 0) { //R
		chena = 0x20;
	} else if (pan < 0) { //L
		chena = 0x10;
	}
	UINT16 rop = (ch > 2) ? 0x100 : 0;
	UINT8 dch = rop ? (ch-3) : ch;
	UINT8 tmp;
	tmp = GetReg(rop + 0xc0 + dch, 0);
	if ((tmp & 0xf0) != chena) {
		SetReg(rop + 0xc0 + dch, (tmp & 0x0f) | chena);
	}
	tmp = GetReg(rop + 0xc3 + dch, 0);
	if ((tmp & 0xf0) != chena) {
		SetReg(rop + 0xc3 + dch, (tmp & 0x0f) | chena);
	}
}

void COPL3::UpdateSustain(UINT8 ch)
{
	if (ch < chs) {
		CHATTR* attr = GetChAttribute(ch);
		FMVOICE* voice = attr->GetVoice();
		CMidiCh* parent = attr->GetParent();
		UINT8 mode = voice->AL & 0x0c;
		UINT16 rop = (ch > 2) ? 0x100 : 0;
		UINT8 dch = rop ? (ch-3) : ch;

		for (int i=0; i<4; i++) {
			if ((1 << i) & carmsk[voice->AL & 0xf]) {
				UINT8 rr = ((parent && parent->GetSustain() && (carmsk[voice->AL&0xf]&(1<<i))) ?
					voice->op[i].REV : (voice->op[i].SR ? voice->op[i].SR : voice->op[i].RR)) & 0xf;
				UINT8 tmp = ((voice->op[i].SL & 0xf) << 4) | rr;
				SetReg(rop + 0x80 + opmap[i] + dch, tmp);
			}
		}
	}
}

void COPL3::UpdateFreq(UINT8 ch, const FNUM* fnum)
{
	CHATTR* attr = GetChAttribute(ch);
	UINT16 rop = (ch > 2) ? 0x100 : 0;
	UINT8 dch = rop ? (ch-3) : ch;
	fnum = fnum ? fnum : GetChAttribute(ch)->GetLastFnumber();
	UINT16 efn = (fnum->fnum >> 1) & 0x3ff;

	SetReg(rop + 0xa0 + dch, (UINT8)(efn & 0xff), 1);
	SetReg(rop + 0xb0 + dch, (GetReg(rop + 0xb0 + dch, 0) & 0x20) |
		(UINT8)((fnum->block << 2) | (efn >> 8)), 1);
	SetReg(rop + 0xa3 + dch, (UINT8)(efn & 0xff), 1);
	SetReg(rop + 0xb3 + dch, (GetReg(rop + 0xb3 + dch, 0) & 0x20) |
		(UINT8)((fnum->block << 2) | (efn >> 8)), 1);
}

void COPL3::UpdateKey(UINT8 ch, UINT8 keyon)
{
	CHATTR* attr = GetChAttribute(ch);
	FMVOICE* voice = attr->GetVoice();

	UINT16 rop = (ch > 2) ? 0x100 : 0;
	UINT8 dch = rop ? (ch-3) : ch;
	UINT8 tmp = GetReg(rop + 0xb0 + dch, 0) & 0xdf;
	SetReg(rop + 0xb0 + dch, tmp | (keyon ? 0x20 : 0), 1);
	if ((voice->AL & 0x08) || !keyon) {
		tmp = GetReg(rop + 0xb3 + dch, 0) & 0xdf;
		SetReg(rop + 0xb3 + dch, tmp | (keyon ? 0x20 : 0), 1);
	}
}

void COPL3::UpdateTL(UINT8 ch, UINT8 op, UINT8 lev)
{
	UINT16 rop = (ch > 2) ? 0x100 : 0;
	UINT8 dch = rop ? (ch-3) : ch;

	SetReg(rop + 0x40 + opmap[op] + dch, (lev>>1));
}

COPL3_2::COPL3_2(CDblPort* pt, UINT8 fsamp) : CSpanDevice(NULL, NULL, fsamp, pt)
{
	COPL* opl1 = new COPL(pt->GetSubPort(0), 0, fsamp);
	COPL* opl2 = new COPL(pt->GetSubPort(1), 0, fsamp);
	for (int i=0; i<6; i++) {
		opl1->EnableCh(i, 0);
		opl2->EnableCh(i, 0);
	}
	AddDevice(opl1);
	AddDevice(opl2);
	SetDevice(DEVICE_OPL3_2);
}
