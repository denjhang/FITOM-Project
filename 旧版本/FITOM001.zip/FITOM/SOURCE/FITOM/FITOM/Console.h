#ifndef __CONSOLE_H__
#define __CONSOLE_H__

#ifdef _WIN32
#include <Windows.h>
#endif

#ifdef putc
#undef putc
#endif

class CConsole
{
#ifdef _WIN32
	HANDLE hCons;
#endif
public:
	enum CONSATTR {CA_BLACK=0, CA_BLUE=0x20, CA_RED=0x40, CA_MAGENTA=0x60,
		CA_GREEN=0x80, CA_CYAN=0xa0, CA_YELLOW=0xc0, CA_WHITE=0xe0, CA_REV=4, };
	void cls();
	void puts(int x, int y, CONSATTR attr, char* str, int max);
	void putc(int x, int y, CONSATTR attr, int c);
	int inkey();
	int getch();
	CConsole();
	~CConsole();
};

#endif
