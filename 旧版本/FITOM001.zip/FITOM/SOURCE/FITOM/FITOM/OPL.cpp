#include "STDAFX.h"
#include "FITOM.h"
#include "OPL.h"
#include "MIDI.h"

#define ADDR_WAIT	6
#define DATA_WAIT	39

UINT8 COPL::map[] = { 0, 1, 2, 8, 9, 10, 16, 17, 18, };
UINT8 COPL::RhythmReg[] = { 0x51, 0x55, 0x52, 0x54, 0x53, };
UINT8 COPL::RhythmMapCh[] = { 7, 8, 8, 7, 6, };
ISoundDevice::FNUM COPL::RhythmFnum[] = {	
	ISoundDevice::FNUM(2, 0x480), ISoundDevice::FNUM(2, 0x540), ISoundDevice::FNUM(0, 0x700)
};
UINT8 COPL::RhythmFreq[] = { 47, 60, 53, };

COPL::COPL(CPort* pt, UINT8 mode, UINT8 fsamp) :
	CSoundDevice(DEVICE_OPL, 9, fsamp, pt), RhythmOnMap(0), RhythmOffMap(0)
{
	ops = 2;
	if (mode & 2) {
		for (int i=0; i<6; i++) {
			EnableCh(i, 0);
		}
	}
	if (mode & 1) {
		rhythmcap = 5;
		for (int i=6; i<9; i++) {
			EnableCh(i, 0);
		}
	}
	if (mode == 2) {
		device = DEVICE_OPL3_2;
	}
	if (mode == 4) {
		rhythmcap = 4;
		for (int i=7; i<9; i++) {
			EnableCh(i, 0);
		}
	}
	SetReg(0x04, 0, 1);
	SetReg(0x08, 0, 1);
}

void COPL::UpdateVoice(UINT8 ch)
{
	UINT8 tmp;
	UINT8 i = 0;
	UINT8 ex = 0;
	CHATTR* attr = GetChAttribute(ch);
	FMVOICE* voice = attr->GetVoice();
	CMidiCh* parent = attr->GetParent();

	for(i=0; i<2; i++)
	{
		tmp = ((voice->op[i].AM & 0x1) << 7) | ((voice->op[i].VIB & 0x1) << 6) |
			((voice->op[i].SR)?0:0x20) | ((voice->op[i].KSR & 0x1) << 4) |
			(voice->op[i].MUL & 0x0F);
		SetReg(0x20 + i * 3 + map[ch], tmp);

		tmp = (UINT8)((voice->op[i].KSL << 6) | voice->op[i].TL);
		SetReg(0x40 + i * 3 + map[ch], tmp);

		tmp = ((voice->op[i].AR & 0xf) << 4) | (voice->op[i].DR & 0xf);
		SetReg(0x60 + i * 3 + map[ch], tmp);

		UINT8 rr = ((parent && parent->GetSustain() && ((i==1) || (voice->AL&1))) ?
			voice->op[i].REV : (voice->op[i].SR ? voice->op[i].SR : voice->op[i].RR)) & 0xf;
		tmp = ((voice->op[i].SL & 0xf) << 4) | rr;
		SetReg(0x80 + i * 3 + map[ch], tmp);
	}
	tmp = 0xf0 | ((voice->FB & 0x7) << 1) | (voice->AL & 0x1);
	SetReg(0xc0 + ch, tmp);

	SetReg(0xe0 + map[ch], voice->op[0].WS);
	SetReg(0xe3 + map[ch], voice->op[1].WS);
	/*
	if (!(voice->AL & 0x4) || (voice->ID>>28)==2) {
		UpdateVolExp(ch);
	}
	*/
}

void COPL::UpdateVolExp(UINT8 ch)
{
	UINT8 tl;
	UINT8 tmp;
	CHATTR* attr = GetChAttribute(ch);
	FMVOICE* voice = attr->GetVoice();
	CMidiCh* parent = attr->GetParent();

	UINT8 evol = attr->GetEffectiveLevel();
	if (voice->AL & 1) {
		tl = CalcEffectiveLevel(evol, (voice->op[0].TL << 1) | (voice->op[0].TL >> 5)) >> 1;
		tmp = (UINT8)((voice->op[0].KSL << 6) | tl);
		attr->baseTL[0] = tl;
		SetReg(0x40 + map[ch], tmp);
	}
	tl = CalcEffectiveLevel(evol, (voice->op[1].TL << 1) | (voice->op[1].TL >> 5)) >> 1;
	tmp = (UINT8)((voice->op[1].KSL << 6) | tl);
	attr->baseTL[1] = tl;
	SetReg(0x43 + map[ch], tmp);
}

void COPL::UpdateFreq(UINT8 ch, const FNUM* fnum)
{
	fnum = fnum ? fnum : GetChAttribute(ch)->GetLastFnumber();
	SetReg(0xa0 + ch, (UINT8)((fnum->fnum>>1) & 0xff), 1);
	SetReg(0xb0 + ch, (GetReg(0xb0 + ch, 0) & 0x20) |
		(UINT8)((fnum->block << 2) | (fnum->fnum >> 9)), 1);
}

void COPL::UpdatePanpot(UINT8 ch)
{
	int pan = (GetChAttribute(ch)->panpot) / 16;
	UINT8 chena = 0;
	if (pan == 0) { //C
		chena = 0x30;
	} else if (pan > 0) { //R
		chena = 0x20;
	} else if (pan < 0) { //L
		chena = 0x10;
	}
	if ((GetReg(0xc0 + ch, 0) & 0xf0) != chena) {
		SetReg(0xc0 + ch, (GetReg(0xc0 + ch, 0) & 0x0f) | chena);
	}
}

void COPL::UpdateSustain(UINT8 ch)
{
	CHATTR* attr = GetChAttribute(ch);
	FMVOICE* voice = attr->GetVoice();
	CMidiCh* parent = attr->GetParent();
	if (voice->AL & 1) {
		UINT8 rr = (parent && parent->GetSustain()) ? voice->op[0].REV : (voice->op[0].SR ? voice->op[0].SR : voice->op[0].RR);
		UINT8 tmp = ((voice->op[0].SL & 0xf) << 4) | (rr & 0xf);
		SetReg(0x80 + map[ch], tmp);
	}
	UINT8 rr = (parent && parent->GetSustain()) ? voice->op[1].REV : (voice->op[1].SR ? voice->op[1].SR : voice->op[1].RR);
	UINT8 tmp = ((voice->op[1].SL & 0xf) << 4) | (rr & 0xf);
	SetReg(0x83 + map[ch], tmp);
}

void COPL::UpdateTL(UINT8 ch, UINT8 op, UINT8 lev)
{
	SetReg(0x40 + (3*op) + map[ch], (lev>>1));
}


void COPL::UpdateKey(UINT8 ch, UINT8 keyon)
{
	CHATTR* attr = GetChAttribute(ch);
	FMVOICE* voice = attr->GetVoice();
	CMidiCh* parent = attr->GetParent();
	UINT8 tmp;
	for (int i=0; i<2; i++) {
		UINT8 rr = ((parent && parent->GetSustain() && ((i==1) || (voice->AL&1))) ? voice->op[i].REV : ((keyon && voice->op[i].SR) ? voice->op[i].SR : voice->op[i].RR)) & 0xf;
		tmp = ((voice->op[i].SL & 0xf) << 4) | rr;
		SetReg(0x80 + i * 3 + map[ch], tmp, 1);
	}
	if (rhythmcap == 4 && ch == 6) {
		if (keyon) {
			RhythmOnMap |= 0x20;
		} else {
			RhythmOffMap &= 0xdf;
		}
	} else {
		tmp = GetReg(0xb0 + ch, 0) & 0xdf;
		SetReg(0xb0 + ch, tmp | (keyon ? 0x20 : 0), 1);
	}
}

void COPL::RhythmOn(UINT8 num, UINT8 vel, SINT8 pan, FMVOICE* rv, FNUM* fnum)
{
	//SetReg(0xbd, 0x20);
	if (num < rhythmcap) {
		UINT8 evol = CalcEffectiveLevel(vel, 127-rhythmvol) >> 1;
		UINT16 addr = RhythmReg[num];
		UINT8 vch = RhythmMapCh[num];

		if (rv && vch < 9) {
			SetVoice(vch, rv);
		}
		fnum = fnum ? fnum : &RhythmFnum[vch-6];
		UpdateFreq(vch, fnum);
		SetReg(addr, evol, 1);
		//SetReg(0xbd, GetReg(0xbd, 0) & ~(1 << num));
		//SetReg(0xbd, (1 << num) | (GetReg(0xbd, 0) & 0xc0) | 0x20);
		RhythmOnMap |= (1 << num);
	}
}

void COPL::RhythmOff(UINT8 num)
{
	if (num < rhythmcap) {
		RhythmOffMap |= (1 << num);
	}
}

void COPL::TimerCallBack(UINT32 tick)
{
	CSoundDevice::TimerCallBack(tick);
	if (RhythmOffMap) {
		SetReg(0xbd, 0x20 | ((~RhythmOffMap) & (GetReg(0x0e, 0) & 0xdf)), 1);
		RhythmOffMap = 0;
	}
	if (RhythmOnMap) {
		SetReg(0xbd, 0x20 | RhythmOnMap, 1);
		RhythmOnMap = 0;
	}
}

//--------
C3801::C3801(CPort* pt, UINT8 mode, UINT8 fsamp) : COPL(pt, mode, fsamp)
{
	SetDevice(DEVICE_Y8950);
}

//--------
COPL2::COPL2(CPort* pt, UINT8 mode, UINT8 fsamp) : COPL(pt, mode, fsamp)
{
	SetDevice(DEVICE_OPL2);
	SetReg(0x01, 0x20, 1);	//Enable WS
}

