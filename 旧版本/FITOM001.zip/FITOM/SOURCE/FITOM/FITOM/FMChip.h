#ifndef __FMCHIP_H__
#define __FMCHIP_H__

#include "Port.h"

#pragma pack(1)

struct FMOP {
	UINT8	AR;		// Attack Rate: 4bit OPL / 5bit OPN/OPM
	UINT8	DR;		// Decay Rate: 4bit OPL / 5bit OPN/OPM
	UINT8	SL;		// Sustain Level: 4bit OPL/OPN/OPM
	UINT8	SR;		// Sustain Rate: none OPL / 5bit OPN/OPM
	UINT8	RR;		// Release Rate: 4bit OPL/OPN/OPM
	UINT8	KSL;	// Key Scale Level: 2bit OPL / none OPN/OPM
	UINT8	TL;		// Total Level: 6bit OPL / 7bit OPN/OPM
	UINT8	MUL;	// Multiple: 4bit OPL/OPN/OPM
	UINT8	AM;		// AM enable: 1bit OPL/OPNA/OPM
	UINT8	VIB;	// Vibrato: 1bit OPL/OPNA / none OPM
	UINT8	EGT;	// Envelope type: 1bit OPL / 4bit OPN / none OPM
	UINT8	KSR;	// Key Scale Rate: 1bit OPL / 2bit OPN/OPM
	UINT8	WS;		// Wave Select: 1bit OPLL / 2bit OPL2 / 3bit OPL3 / none OPN/OPM
	UINT8	DT1;	// Detune1: none OPL / 4bit OPN/OPM
	UINT8	DT2;	// Detune2: none OPL/OPN / 3bit OPM
};

struct FMVOICE {
	UINT32	ID;
	char		name[16];
	UINT8	FB;		// Feedback: 3bit OPL/OPN/OPM
	UINT8	AL;		// Algorythm: 1bit OPL / 2bit OPL3 / 3bit OPN/OPM
	UINT8	AMS;	// AM Sensitivity: none OPL / 2bit OPNA/OPM
	UINT8	PMS;	// PM Sensitivity: none OPL / 3bit OPNA/OPM
	UINT8	AMD;	// AM Depth
	UINT8	PMD;	// PM Depth
	UINT8	LFO;	// LFO frequency
	UINT8	LWF;	// LFO Wave form
	FMOP	op[4];
};

#pragma pack()

struct FNUM {
	UINT8	block;	// Block number/Key code(OPM)
	UINT16	fnum;	// F-number/Key fractal(OPM)
};

class CFMChip {
	friend class CDualChips;
	friend class CSpanChip;
	friend class CSplitPan;
	friend class CLinearPan;
	friend class CUnison;
protected:
	struct CHATTR {
		CHATTR();
		enum CHSTAT {
			EMPTY = 0, DISABLED = -1, ASSIGNED = 1, RUNNING = 2,
		} status;
		UINT8	volume;
		UINT8	express;
		UINT8	velocity;
		SINT8	panpot;
		UINT8	lastvel;
		UINT8	lastnote;
		FNUM		lastfnum;
		UINT8	range;
		SINT16	bend;
		SINT16	pitch;
		FMVOICE	voice;
	};
	UINT8	device;
	UINT8	chs;
	UINT8	volume;
	UINT8	rhythmvol;
	UINT8	rhythmcap;
	CHATTR	chattr[16];
	CPort*	port;

	UINT8 GetVolExp(UINT8 ch);
	virtual void UpdateVolExp(UINT8 ch) = 0;
	virtual void UpdateFreq(UINT8 ch) = 0;
	virtual void UpdateVoice(UINT8 ch) = 0;
	virtual void UpdatePanpot(UINT8 ch) = 0;
	virtual void UpdateRhythmVol() {};
	virtual FNUM GetFnumber(UINT8 note) = 0;
	virtual FNUM CalcFnumber(UINT8 note, SINT16 tune, SINT16 bend, UINT8 range) = 0;
public:
	CFMChip(CPort* pt=0);
	~CFMChip();

	// Device status
	virtual void SetDevice(UINT8 devid);
	virtual UINT8 GetDevice() { return device; };
	virtual void EnableCh(UINT8 ch, UINT8 ena);
	virtual UINT8 AllocCh(FMVOICE* voice = 0);
	virtual void ReleaseCh(UINT8 ch);
	virtual UINT8 GetChs();
	virtual UINT8 GetAvailable();
	virtual UINT8 GetRhythmCaps() { return rhythmcap; }
	const CPort* GetDevPort() { return port; };
	UINT8 IsEnable(UINT8 ch);

	// Physical accesses
	void SetReg(UINT16 reg, UINT8 data);
	UINT8 GetReg(UINT16 reg, UINT8 v);

	// Note control interfaces (polymorph)
	virtual void NoteOn(UINT8 ch, UINT8 vel=127) = 0;
	virtual void NoteOff(UINT8 ch) = 0;
	virtual void RhythmOn(UINT8 num, UINT8 vel) {};

	// Ch Property settings
	virtual void SetNote(UINT8 ch, UINT8 note, int update=1);
	virtual void SetPitchBend(UINT8 ch, UINT8 range, UINT16 bend, int update=1);
	virtual void SetTuning(UINT8 ch, UINT16 tune, int update=1);
	virtual void SetVoice(UINT8 ch, FMVOICE* voice, int update=1);
	virtual void SetVolume(UINT8 ch, UINT8 vol, int update=1);
	virtual void SetVelocity(UINT8 ch, UINT8 vel, int update=1);
	virtual void SetExpress(UINT8 ch, UINT8 exp, int update=1);
	virtual void SetPanpot(UINT8 ch, UINT8 pan, int update=1);
	virtual void SetMasterVolume(UINT8 vol);
	virtual void SetRhythmVolume(UINT8 vol);

	//Callback
	virtual void PollingCallBack() {};
	virtual void TimerCallBack() {};
};

class CDualChips : public CFMChip {
protected:
	int numchips;
	CFMChip* chips[2];
	struct DEVCHRES {
		int dev;
		int ch;
	};
	DEVCHRES chres[16];
public:
	CDualChips();
	CDualChips(CFMChip* chip1, CFMChip* chips);
	virtual void AddDevice(CFMChip* dev);
};

class CSpanChip : public CDualChips {
protected:
	virtual FNUM GetFnumber(UINT8 note);
	virtual FNUM CalcFnumber(UINT8 note, SINT16 tune, SINT16 bend, UINT8 range);

	virtual void UpdateVolExp(UINT8 ch);
	virtual void UpdateVoice(UINT8 ch);
	virtual void UpdateFreq(UINT8 ch);
	virtual void UpdatePanpot(UINT8 ch);
	static UINT8 carmsk[];
public:
	CSpanChip();
	virtual void SetNote(UINT8 ch, UINT8 note, int update=1);
	virtual void SetPanpot(UINT8 ch, UINT8 pan, int update=1);
	virtual void SetTuning(UINT8 ch, UINT16 tune, int update=1);
	virtual void SetVolume(UINT8 ch, UINT8 vol, int update=1);
	virtual void SetVelocity(UINT8 ch, UINT8 vel, int update=1);
	virtual void SetExpress(UINT8 ch, UINT8 exp, int update=1);
	virtual void SetVoice(UINT8 ch, FMVOICE* voice, int update=1);
	virtual void NoteOn(UINT8 ch, UINT8 vel);
	virtual void NoteOff(UINT8 ch);
};

class CSplitPan : public CDualChips {
};

class CLinearPan : public CDualChips {
};

class CUnison : public CDualChips {
};

class COPL : public CFMChip {
	friend class COPL3;
protected:
	virtual FNUM GetFnumber(UINT8 note);
	virtual FNUM CalcFnumber(UINT8 note, SINT16 tune, SINT16 bend, UINT8 range);

	virtual void UpdateVolExp(UINT8 ch);
	virtual void UpdateVoice(UINT8 ch);
	virtual void UpdateFreq(UINT8 ch);
	virtual void UpdatePanpot(UINT8 ch);

	static UINT16 FnumL[];
	static UINT16 FnumM[];
	static UINT16 FnumH[];
	static UINT8 map[];
public:
	COPL(CPort* pt);
	virtual void NoteOn(UINT8 ch, UINT8 vel=255);
	virtual void NoteOff(UINT8 ch);
};

class COPN : public CFMChip {
protected:
	virtual FNUM GetFnumber(UINT8 note);
	virtual FNUM CalcFnumber(UINT8 note, SINT16 tune, SINT16 bend, UINT8 range);

	virtual void UpdateVolExp(UINT8 ch);
	virtual void UpdateVoice(UINT8 ch);
	virtual void UpdateFreq(UINT8 ch);
	virtual void UpdatePanpot(UINT8 ch);

	static UINT16 FnumL[];
	static UINT16 FnumM[];
	static UINT16 FnumH[];
	static UINT8 map[];
	static UINT8 carmsk[];
public:
	COPN(CPort* pt);
	virtual void NoteOn(UINT8 ch, UINT8 vel);
	virtual void NoteOff(UINT8 ch);
};

class COPL3 : public CFMChip {
protected:
	COPL* opl[2];
	virtual FNUM GetFnumber(UINT8 note);
	virtual FNUM CalcFnumber(UINT8 note, SINT16 tune, SINT16 bend, UINT8 range);

	virtual void UpdateVolExp(UINT8 ch);
	virtual void UpdateVoice(UINT8 ch);
	virtual void UpdateFreq(UINT8 ch);
	virtual void UpdatePanpot(UINT8 ch);
	static UINT8 carmsk[];
	static UINT8 opmap[];
public:
	COPL3(CDblPort* pt);
	virtual void SetNote(UINT8 ch, UINT8 note, int update=1);
	virtual void SetPanpot(UINT8 ch, UINT8 pan, int update=1);
	virtual void SetTuning(UINT8 ch, UINT16 tune, int update=1);
	virtual void SetVolume(UINT8 ch, UINT8 vol, int update=1);
	virtual void SetVelocity(UINT8 ch, UINT8 vel, int update=1);
	virtual void SetExpress(UINT8 ch, UINT8 exp, int update=1);
	virtual void SetVoice(UINT8 ch, FMVOICE* voice, int update=1);
	virtual void NoteOn(UINT8 ch, UINT8 vel);
	virtual void NoteOff(UINT8 ch);
};

class COPL3_2 : public CSpanChip {
public:
	COPL3_2(CDblPort* pt);
};

class COPN2 : public CSpanChip {
protected:
	virtual void UpdateVoice(UINT8 ch);
public:
	COPN2(CDblPort* pt);
	virtual void NoteOn(UINT8 ch, UINT8 vel);
	virtual void NoteOff(UINT8 ch);
};

class COPNA : public COPN2 {
public:
	COPNA(CDblPort* pt);
	virtual void UpdateRhythmVol();
	virtual void RhythmOn(UINT8 num, UINT8 vel);
};

class COPM : public CFMChip {
protected:
	virtual FNUM GetFnumber(UINT8 note);
	virtual FNUM CalcFnumber(UINT8 note, SINT16 tune, SINT16 bend, UINT8 range);

	virtual void UpdateVolExp(UINT8 ch);
	virtual void UpdateVoice(UINT8 ch);
	virtual void UpdateFreq(UINT8 ch);
	virtual void UpdatePanpot(UINT8 ch);

	static UINT8 KeyCode[];
	static UINT8 map[];
	static UINT8 carmsk[];
public:
	COPM(CPort* pt);
	virtual void NoteOn(UINT8 ch, UINT8 vel);
	virtual void NoteOff(UINT8 ch);
};

class COPLL : public CFMChip {
protected:
	virtual FNUM GetFnumber(UINT8 note);
	virtual FNUM CalcFnumber(UINT8 note, SINT16 tune, SINT16 bend, UINT8 range);

	virtual void UpdateVolExp(UINT8 ch);
	virtual void UpdateVoice(UINT8 ch);
	virtual void UpdateFreq(UINT8 ch);
	virtual void UpdatePanpot(UINT8 ch) {};
	virtual void UpdateRhythmVol();

	static UINT16 FnumL[];
	static UINT16 FnumM[];
	static UINT16 FnumH[];
public:
	COPLL(CPort* pt);
	virtual void NoteOn(UINT8 ch, UINT8 vel);
	virtual void NoteOff(UINT8 ch);
	virtual void RhythmOn(UINT8 num, UINT8 vel);
};

#endif
