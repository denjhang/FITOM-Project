#ifndef __SCREEN_H__
#define __SCREEN_H__

#include "FITOM.h"
#include "Console.h"

class IScreen
{
protected:
	CFITOM* Parent;
public:
	IScreen(CFITOM* parent);
	~IScreen(void);
	virtual int Modal(int flag) = 0;
	virtual int Show(int flag) = 0;
	virtual int KeyOn(int ch) = 0;
};

class CScreen : public IScreen
{
public:
	CScreen(CFITOM* parent);
	virtual int Modal(int flag);
};

class CMainScreen : public CScreen
{
protected:
	int currentscreen;
	CScreen* scr[MAX_SCREEN];
	int scrs;
public:
	CMainScreen(CFITOM* parent);
	virtual int Modal(int flag);
	virtual int Show(int flag);
	virtual int KeyOn(int ch);
};

class CMidiMon : public CScreen
{
protected:
	UINT8 curpage;
	UINT8 vcur;
	UINT8 hcur;
public:
	CMidiMon(CFITOM* parent);
	virtual int Show(int flag);
	virtual int KeyOn(int ch);
};

class CDeviceMon : public CScreen
{
protected:
	UINT8 curpage;
	UINT8 vcur;
	UINT8 hcur;
public:
	CDeviceMon(CFITOM* parent);
	virtual int Show(int flag);
	virtual int KeyOn(int ch);
};

class CRegisterMon : public CScreen
{
protected:
	UINT8 curpage;
	UINT8 vcur;
	UINT8 hcur;
public:
	CRegisterMon(CFITOM* parent);
	virtual int Modal(int flag);
	virtual int Show(int flag);
	virtual int KeyOn(int ch);
};

class CVoiceEdit : public CScreen
{
private:
	struct EDITITEM {
		UINT8 size;	// location size
		UINT8 addr;	// data address
		UINT8 mask;
		UINT8 shift;
		UINT8 floor;
		UINT8 seal;
		const char* label;
	};
	struct LABELITEM {
		UINT8 x;
		UINT8 y;
		char* label;
		CConsole::CONSATTR attr;
	};
	enum CURFUNC {
		FUNC_NONE,
		FUNC_MIDI, FUNC_CH, FUNC_DEV,
		FUNC_BANK, FUNC_PROG,
		FUNC_PORT, FUNC_PORTTIME,
		FUNC_EXPR, FUNC_VOL,
		FUNC_MODU, FUNC_MODURATE,
		FUNC_FOOT, FUNC_FOOTRATE,
		FUNC_SUSTAIN, FUNC_LEGATO,
		FUNC_FDAMP, FUNC_SOSTE,
		FUNC_MONO, FUNC_POLY,
		FUNC_BEND, FUNC_BENDRANGE,
		FUNC_EDITPAGE, FUNC_VOICE,
	};
	struct CURLOC {
		UINT8 x;
		UINT8 y;
		UINT8 size;
		UINT8 param;
		CURFUNC func;
		UINT8 left;
		UINT8 right;
		UINT8 up;
		UINT8 down;
	};
protected:
	static const EDITITEM items[];
	static const LABELITEM labels[];
	static const CURLOC locate[];
	static const int editpages[4][36];
	static const char* pagename[4];
	UINT8 port;
	UINT8 mch;
	UINT8 voice[128];
	UINT8 params[36];
	UINT8 curpage;
	int cursor;
	void DispValue(const CURLOC& loc, int cur);
	void ModifyValue(const CURLOC& loc, int inc);
	void ReadVoice();
	void WriteVoice();
	void SetEditPage(int page);
public:
	CVoiceEdit(CFITOM* parent);
	virtual int Show(int flag);
	virtual int KeyOn(int ch);
};

class CNullScreen : public CScreen
{
public:
	CNullScreen(CFITOM* parent) : CScreen(parent) {};
	virtual int Show(int flag) { return 0; };
	virtual int KeyOn(int ch) { return -1; };
};

#endif
