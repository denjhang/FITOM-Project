#ifndef __OPK_H__
#define __OPK_H__

#include "SoundDev.h"

class COPK : public CSoundDevice {
protected:
	virtual void UpdateVolExp(UINT8 ch) {};
	virtual void UpdateVoice(UINT8 ch) {};
	virtual void UpdateFreq(UINT8 ch, const FNUM* fnum) {};
	virtual void UpdatePanpot(UINT8 ch) {};
	virtual void UpdateSustain(UINT8 ch) {};
	virtual void UpdateTL(UINT8 ch, UINT8 op, UINT8 lev) {};
	virtual void UpdateKey(UINT8 ch, UINT8 keyon) {};
	UINT8 RhythmOnMap;
	UINT8 RhythmOffMap;
	static UINT8 RhythmRomAddr[];
	static UINT8 RhythmVolReg[];
	static UINT8 RhythmMapCh[];
	UINT8 RhythmStat[4];
	UINT8 AllocRhythmCh(UINT8 num);
public:
	COPK(CPort* pt, UINT8 mode=0, UINT8 fsamp=0);
	virtual void RhythmOn(UINT8 num, UINT8 vel, SINT8 pan, FMVOICE* rv, FNUM* fnum);
	virtual void RhythmOff(UINT8 num);
	virtual void TimerCallBack(UINT32 tick);
};

#endif //__OPK_H__