#include "stdafx.h"
#include "Port.h"
#include "FMChip.h"

FNUM NullNote = {0, 0};

CFMChip::CHATTR::CHATTR()
{
	status = CHATTR::EMPTY;
	express = 127;
	volume = 100;
	velocity=127;
	panpot = 0;
	lastvel = 0;
	lastnote = 255;
	lastfnum = NullNote;
	range = 2;
	bend = 0;
	pitch = 0;
}

CFMChip::CFMChip(CPort* pt) : port(pt)
{
	chs = 0;
	device = 0;
	volume = 100;
	rhythmvol = 100;
	rhythmcap = 0;
}

CFMChip::~CFMChip()
{
	if (chs)
	{
	//	delete[] chattr;
	}
}

void CFMChip::SetDevice(UINT8 devid)
{
	device = devid;
}

void CFMChip::SetReg(UINT16 reg, UINT8 data)
{
	port->write(reg, data);
}

UINT8 CFMChip::GetReg(UINT16 reg, UINT8 v)
{
	UINT8 ret = 0;
	ret = port->read(reg, (int)v);
	return ret;
}

UINT8 CFMChip::IsEnable(UINT8 ch)
{
	if (ch < chs) {
		return (chattr[ch].status != CHATTR::DISABLED);
	}
	return 0;
}

void CFMChip::SetVoice(UINT8 ch, FMVOICE* voice, int update)
{
	if (ch < chs && chattr[ch].status != CHATTR::DISABLED)
	{
		if (chattr[ch].voice.ID != voice->ID) {
			chattr[ch].voice = *voice;
			if (update) {
				UpdateVoice(ch);
			}
		}
	}
}

void CFMChip::SetVolume(UINT8 ch, UINT8 vol, int update)
{
	if (ch < chs && chattr[ch].status != CHATTR::DISABLED)
	{
		if (chattr[ch].volume != vol) {
			chattr[ch].volume = vol;
			if (update) {
				UpdateVolExp(ch);
			}
		}
	}
}

void CFMChip::SetExpress(UINT8 ch, UINT8 exp, int update)
{
	if (ch < chs && chattr[ch].status != CHATTR::DISABLED)
	{
		if (chattr[ch].express != exp) {
			chattr[ch].express = exp;
			if (update) {
				UpdateVolExp(ch);
			}
		}
	}
}

void CFMChip::SetPanpot(UINT8 ch, UINT8 pan, int update)
{ 
	if (ch < chs && chattr[ch].status != CHATTR::DISABLED)
	{
		SINT8 panpot = pan - 64;
		if (chattr[ch].panpot != panpot) {
			chattr[ch].panpot = panpot;
			if (update) {
				UpdatePanpot(ch);
			}
		}
	}
}

UINT8 CFMChip::GetVolExp(UINT8 ch)
{
	UINT32 tmp;
	tmp = chattr[ch].volume;
	tmp = (tmp * chattr[ch].express + tmp + chattr[ch].express) >> 7;
	tmp = (tmp * volume + tmp + volume) >>7;
	tmp = (tmp * chattr[ch].lastvel + tmp + chattr[ch].lastvel) >> 7;
	return (UINT8)tmp;
}

void CFMChip::SetMasterVolume(UINT8 vol)
{
	if (volume != vol) {
		volume = vol;
		for (int i=0; i<chs; i++)
		{
			if (chattr[i].status != CHATTR::DISABLED) {
				UpdateVolExp((UINT8)i);
			}
		}
	}
}

void CFMChip::SetPitchBend(UINT8 ch, UINT8 range, UINT16 bend, int update)
{
	if (ch < chs && chattr[ch].status != CHATTR::DISABLED) {
		SINT16 pbend = bend - 8192;
		if (chattr[ch].range != range && chattr[ch].bend != pbend) {
			chattr[ch].range = range;
			chattr[ch].bend = pbend;
			if (update) {
				UpdateFreq(ch);
			}
		}
	}
}

void CFMChip::SetTuning(UINT8 ch, UINT16 tune, int update)
{
	if (ch < chs && chattr[ch].status != CHATTR::DISABLED) {
		SINT16 pitch = tune - 8192;
		if (chattr[ch].pitch != pitch) {
			chattr[ch].pitch = pitch;
			if (update) {
				UpdateFreq(ch);
			}
		}
	}
}

UINT8 CFMChip::AllocCh(FMVOICE* voice)
{
	UINT8 ret = 0xff;
	if (voice) {
		for (int i=0; i<chs; i++) {
			if (chattr[i].status == CHATTR::EMPTY && chattr[i].voice.ID == voice->ID) {
				ret = i;
				break;
			}
		}
	}
	if (!voice || ret == 0xff) {
		for (int i=0; i<chs; i++) {
			if (chattr[i].status == CHATTR::EMPTY) {
				ret = i;
				SetVoice(i, voice);
				break;
			}
		}
	}
	return (ret);
}

void CFMChip::ReleaseCh(UINT8 ch)
{
	if (ch < chs)
	{
		chattr[ch].status = CHATTR::EMPTY;
	}
}

void CFMChip::EnableCh(UINT8 ch, UINT8 ena)
{
	if (ch < chs)
	{
		chattr[ch].status = (ena==0) ? CHATTR::DISABLED : CHATTR::EMPTY;
	}
}

void CFMChip::SetVelocity(UINT8 ch, UINT8 vel, int update)
{
	if (ch < chs && chattr[ch].status != CHATTR::DISABLED && vel < 128) {
		chattr[ch].velocity = vel;
		if (update) {
			UpdateVolExp(ch);
		}
	}
}

UINT8 CFMChip::GetChs()
{
	return chs;
}

void CFMChip::SetNote(UINT8 ch, UINT8 note, int update)
{
	if (ch < chs && chattr[ch].status != CHATTR::DISABLED) {
		FNUM fnum = CalcFnumber(note, chattr[ch].pitch, chattr[ch].bend, chattr[ch].range);
		chattr[ch].lastnote = note;
		chattr[ch].lastfnum = fnum;
		if (update) {
			UpdateFreq(ch);
		}
	}
}

void CFMChip::SetRhythmVolume(UINT8 vol)
{
	rhythmvol = vol & 0x7f;
	UpdateRhythmVol();
}

UINT8 CFMChip::GetAvailable()
{
	UINT8 ret = 0;
	for (int i=0; i<chs; i++) {
		if (chattr[i].status == CHATTR::EMPTY) { ret++; }
	}
	return ret;
}

/*----------------*/

CDualChips::CDualChips() : CFMChip(0), numchips(0)
{
	int i;
	for(i=0; i<2; i++) {
		chips[i] = 0;
	}
	for(i=0; i<16; i++) {
		chres[i].dev = -1;
		chres[i].ch = -1;
	}
}

CDualChips::CDualChips(CFMChip* chip1, CFMChip* chip2) : CFMChip(0), numchips(0)
{
	AddDevice(chip1);
	AddDevice(chip2);
}

void CDualChips::AddDevice(CFMChip* dev)
{
	if (dev && numchips < 2) {
		chips[numchips] = dev;
		int newchs = dev->GetChs();
		for (int i=0; i<newchs; i++) {
			if (dev->IsEnable(i)) {
				chres[chs].dev = numchips;
				chres[chs].ch = i;
				chs++;
			}
		}
		numchips++;
	}
}

CSpanChip::CSpanChip() : CDualChips()
{
}

void CSpanChip::SetVoice(UINT8 ch, FMVOICE* voice, int update)
{
	if (ch < chs && chattr[ch].status != CHATTR::DISABLED) {
		if (chattr[ch].voice.ID != voice->ID) {
			chattr[ch].voice = *voice;
			chips[chres[ch].dev]->SetVoice(chres[ch].ch, voice, 0);
			if (update) {
				UpdateVoice(ch);
			}
		}
	}
}

void CSpanChip::UpdateVoice(UINT8 ch)
{
	chips[chres[ch].dev]->UpdateVoice(chres[ch].ch);
}

void CSpanChip::UpdateVolExp(UINT8 ch)
{
	chips[chres[ch].dev]->UpdateVolExp(chres[ch].ch);
}

void CSpanChip::UpdatePanpot(UINT8 ch)
{
	chips[chres[ch].dev]->UpdatePanpot(chres[ch].ch);
}

void CSpanChip::SetNote(UINT8 ch, UINT8 note, int update)
{
	CFMChip::SetNote(ch, note);
	chips[chres[ch].dev]->SetNote(chres[ch].ch, note, update);
}

void CSpanChip::SetPanpot(UINT8 ch, UINT8 pan, int update)
{
	CFMChip::SetPanpot(ch, pan, 0);
	chips[chres[ch].dev]->SetPanpot(chres[ch].ch, pan, update);
}

void CSpanChip::SetTuning(UINT8 ch, UINT16 tune, int update)
{
	CFMChip::SetTuning(ch, tune, 0);
	chips[chres[ch].dev]->SetTuning(chres[ch].ch, tune, update);
}

void CSpanChip::SetVolume(UINT8 ch, UINT8 vol, int update)
{
	CFMChip::SetVolume(ch, vol, 0);
	chips[chres[ch].dev]->SetVolume(chres[ch].ch, vol, update);
}

void CSpanChip::SetVelocity(UINT8 ch, UINT8 vel, int update)
{
	CFMChip::SetVelocity(ch, vel, 0);
	chips[chres[ch].dev]->SetVelocity(chres[ch].ch, vel, update);
}

void CSpanChip::SetExpress(UINT8 ch, UINT8 exp, int update)
{
	CFMChip::SetExpress(ch, exp, 0);
	chips[chres[ch].dev]->SetExpress(chres[ch].ch, exp, update);
}

FNUM CSpanChip::GetFnumber(UINT8 note)
{
	return chips[0]->GetFnumber(note);
}

FNUM CSpanChip::CalcFnumber(UINT8 note, SINT16 tune, SINT16 bend, UINT8 range)
{
	return chips[0]->CalcFnumber(note, tune, bend, range);
}

void CSpanChip::UpdateFreq(UINT8 ch)
{
	chips[chres[ch].dev]->UpdateFreq(chres[ch].ch);
}

void CSpanChip::NoteOn(UINT8 ch, UINT8 vel)
{
	if (ch < chs && chattr[ch].status != CHATTR::DISABLED) {
		chips[chres[ch].dev]->NoteOn(chres[ch].ch, vel);
		chattr[ch].status = CHATTR::ASSIGNED;
	}
}

void CSpanChip::NoteOff(UINT8 ch)
{
	if (ch < chs && chattr[ch].status != CHATTR::DISABLED) {
		chips[chres[ch].dev]->NoteOff(chres[ch].ch);
		chattr[ch].status = CHATTR::EMPTY;
	}
}
