#ifndef __XMEMFILE_H__
#define __XMEMFILE_H__

#ifdef _DOS
class XMSInit {
public:
	XMSInit();
	~XMSInit();
};

extern "C" {
#include "XMS.H"
};

#endif

class CXmemFile
{
protected:
#ifdef _DOS
	SMEM xmem;
#endif
#ifdef _WIN32
	HANDLE xmem;
#endif
	UINT32 actsize;
	SINT32 pos;
public:
	CXmemFile();
	CXmemFile(UINT32 size);
	int Alloc(UINT32 size);
	int Read(void* dst, UINT32 size);
	int Write(void* src, UINT32 size);
	int Seek(SINT32 offset, int origin);
	UINT32 GetSize();
	int Free();
	~CXmemFile(void);
};

#endif
