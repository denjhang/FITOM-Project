#include "STDAFX.H"
#include "FITOM.h"
#include "OPK.h"

UINT8 COPK::RhythmRomAddr[] = { 0x11, 0x25, 0x34, 0x53, 0x81, 0xc2, };	// sd, c-hh, o-hh, rc, bd, tom
UINT8 COPK::RhythmVolReg[] = { 0x2a, 0x2b, 0x2e, 0x2f, };
UINT8 COPK::RhythmMapCh[] = { 0, 1, 1, 2, 3, -1, };

COPK::COPK(CPort* pt, UINT8 mode, UINT8 fsamp) : CSoundDevice(DEVICE_OPK, 0, fsamp, pt)
{
	SetReg(0x01, 0xff, 1);
	rhythmcap = 12;
}

void COPK::RhythmOn(UINT8 num, UINT8 vel, SINT8 pan, FMVOICE* rv, FNUM* fnum)
{
	//SetReg(0xbd, 0x20);
	if (num < rhythmcap) {
		UINT8 evol = CalcEffectiveLevel(vel, 127-rhythmvol) >> 1;
		UINT8 addr = RhythmRomAddr[(num > 6) ? (num-6) : num];

		SetReg(addr, evol, 1);
		//SetReg(0xbd, GetReg(0xbd, 0) & ~(1 << num));
		//SetReg(0xbd, (1 << num) | (GetReg(0xbd, 0) & 0xc0) | 0x20);
		RhythmOnMap |= (1 << num);
	}
}

void COPK::RhythmOff(UINT8 num)
{
	if (num < rhythmcap) {
		RhythmOffMap |= (1 << num);
	}
}

void COPK::TimerCallBack(UINT32 tick)
{
}