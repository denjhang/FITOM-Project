#include "stdafx.h"
#include "FITOM.h"
#include "OPN.h"
#include "OPM.h"
#include "OPL.h"
#include "OPLL.h"
#include "SSG.h"
#include "MultiDev.h"
#include "MIDIDEV.h"
#include "MIDI.h"
#include "XmemFile.h"

CSoundDevice* CFITOM::AddDevice(CSoundDevice* pdev)
{
	char tmp1[80], tmp2[80], tmp3[80], tmp4[80];
	if (devs >= MAX_DEVS || !pdev) return 0;
	pdev->GetDescriptor(tmp1);
	if (pdev->GetDevPort()) {
		pdev->GetDevPort()->GetDesc(tmp2);
	}
	for (int i=0; i<devs; i++) {
		if (pdev->GetDevice() == fmdev[i]->GetDevice()) {
			fmdev[i]->GetDescriptor(tmp3);
			CPort* pt = fmdev[i]->GetDevPort();
			if (pt) {
				pt->GetDesc(tmp4);
				printf("Dev.%i: %s+%s (spanned) port=%s%s\n", i, tmp1, tmp3, tmp2, tmp4);
				CSpanDevice* pspan = new CSpanDevice(pdev, fmdev[i], 0, 0);
				fmdev[i] = pspan;
			} else { //already spanned
				((CSpanDevice*)fmdev[i])->AddDevice(pdev);
			}
			return fmdev[i];
		}
	}
	printf("Dev.%i: %s port=%s\n", devs, tmp1, tmp2);
	fmdev[devs++] = pdev;
	return pdev;
}

int CFITOM::AddDevice(CMidiIn* pmpu)
{
	int ret = -1;
	if (mpus < MAX_MPUS && pmpu) {
		ret = mpus++;
		mpu[ret] = pmpu;
		midi[ret] = new CMidiInst(pmpu, this);
	}
	return ret;
}

int CFITOM::AddDevice(CMidiOut* pmpu)
{
	int ret = -1;
	if (ompus < MAX_MPUS && pmpu) {
		ret = ompus++;
		ompu[ret] = pmpu;
	}
	return ret;
}

int CFITOM::CreateSingleDevice(int devtype, char* param)
{
	int res = 0;
	CPort* pt = 0;
	int md, fs;
	char portparams[80];
	sscanf(param, "%i : %i, %s", &md, &fs, portparams);
	switch (devtype) {
	case DEVICE_OPN:
		if ((pt=CreatePort(1, (char*)portparams))) {
			if (!(md & 1)) {
				AddDevice(new COPN(pt, UINT8(fs)));
			}
			if (!(md & 2)) {
				AddDevice(new CSSG(pt, UINT8(fs)));
			}
		}
		break;
	case DEVICE_OPNC:
		if ((pt=CreatePort(1, (char*)portparams))) {
			if (!(md & 1)) {
				AddDevice(new COPNC(pt, UINT8(fs)));
			}
			if (!(md & 2)) {
				AddDevice(new CSSG(pt, UINT8(fs)));
			}
		}
		break;
	case DEVICE_OPM:
		if ((pt=CreatePort(1, (char*)portparams))) {
			AddDevice(new COPM(pt, UINT8(fs)));
		}
		break;
	case DEVICE_OPP:
		if ((pt=CreatePort(1, (char*)portparams))) {
			AddDevice(new COPP(pt, UINT8(fs)));
		}
		break;
	case DEVICE_OPN2:
		if ((pt=CreatePort(2, (char*)portparams))) {
			AddDevice(new COPN2((CDblPort*)pt, UINT8(fs)));
		}
		break;
	case DEVICE_OPN2C:
		if ((pt=CreatePort(2, (char*)portparams))) {
			AddDevice(new COPN2C((CDblPort*)pt, UINT8(fs)));
		}
		break;
	case DEVICE_OPN2L:
		if ((pt=CreatePort(2, (char*)portparams))) {
			AddDevice(new COPN2L((CDblPort*)pt, UINT8(fs)));
		}
		break;
	case DEVICE_OPNB:
		if ((pt=CreatePort(2, (char*)portparams))) {
			AddDevice(new COPNB((CDblPort*)pt, UINT8(fs)));
		}
		break;
	case DEVICE_F286:
		if ((pt=CreatePort(2, (char*)portparams))) {
			AddDevice(new CF286((CDblPort*)pt, UINT8(fs)));
		}
		break;
	case DEVICE_2610B:
		if ((pt=CreatePort(2, (char*)portparams))) {
			AddDevice(new C2610B((CDblPort*)pt, UINT8(fs)));
		}
		break;
	case DEVICE_OPNA:
		if ((pt=CreatePort(2, (char*)portparams))) {
			if (!(md & 1)) {
				AddDevice(new COPNA((CDblPort*)pt, UINT8(fs)));
			}
			if (!(md & 2)) {
				AddDevice(new CSSG(((CDblPort*)pt)->GetSubPort(0), UINT8(fs)));
			}
			if (!(md & 4)) {
				//AddDevice(new CAdPcm2608(((CDblPort*)pt)->GetSubPort(1), UINT8(fs)));
			}
		}
		break;
	case DEVICE_OPN3L:
		if ((pt=CreatePort(2, (char*)portparams))) {
			if (!(md & 1)) {
				AddDevice(new COPN3L((CDblPort*)pt, UINT8(fs)));
			}
			if (!(md & 2)) {
				AddDevice(new CSSG(((CDblPort*)pt)->GetSubPort(0), UINT8(fs)));
			}
		}
		break;
	case DEVICE_OPL3:
		if ((pt=CreatePort(2, (char*)portparams))) {
			switch (md) {
			case 0:	// 6op4 + 6op2
				AddDevice(new COPL3((CDblPort*)pt, UINT8(fs)));
				AddDevice(new COPL3_2((CDblPort*)pt, UINT8(fs)));
				break;
			case 1:	// 6op4 + 3op2 + 5rhy
				AddDevice(new COPL3((CDblPort*)pt, UINT8(fs)));
				AddDevice(new COPL2(((CDblPort*)pt)->GetSubPort(0), 3, UINT8(fs)));
				AddDevice(new COPL2(((CDblPort*)pt)->GetSubPort(1), 2, UINT8(fs)));
				break;
			case 2:	// 6op4 + 4op2 + 4rhy
				AddDevice(new COPL3((CDblPort*)pt, UINT8(fs)));
				AddDevice(new COPL2(((CDblPort*)pt)->GetSubPort(0), 4, UINT8(fs)));
				AddDevice(new COPL2(((CDblPort*)pt)->GetSubPort(1), 2, UINT8(fs)));
				break;
			case 3:	// 18op2
				AddDevice(new COPL2(((CDblPort*)pt)->GetSubPort(0), 0, UINT8(fs)));
				AddDevice(new COPL2(((CDblPort*)pt)->GetSubPort(1), 0, UINT8(fs)));
				break;
			case 4:	// 15op2 + 5rhy
				AddDevice(new COPL2(((CDblPort*)pt)->GetSubPort(0), 3, UINT8(fs)));
				AddDevice(new COPL2(((CDblPort*)pt)->GetSubPort(1), 0, UINT8(fs)));
				break;
			case 5:	//16op2 + 4rhy
				AddDevice(new COPL2(((CDblPort*)pt)->GetSubPort(0), 4, UINT8(fs)));
				AddDevice(new COPL2(((CDblPort*)pt)->GetSubPort(1), 0, UINT8(fs)));
				break;

			}
		}
		break;
	case DEVICE_OPL:
		if ((pt=CreatePort(1, (char*)portparams))) {
			AddDevice(new COPL(pt, UINT8(md), UINT8(fs)));
		}
		break;
	case DEVICE_Y8950:
		if ((pt=CreatePort(1, (char*)portparams))) {
			AddDevice(new C3801(pt, UINT8(md), UINT8(fs)));
		}
		break;
	case DEVICE_OPL2:
		if ((pt=CreatePort(1, (char*)portparams))) {
			AddDevice(new COPL2(pt, UINT8(md), UINT8(fs)));
		}
		break;
	case DEVICE_OPLL:
		if ((pt=CreatePort(1, (char*)portparams))) {
			AddDevice(new COPLL(pt, UINT8(md), UINT8(fs)));
		}
		break;
	case DEVICE_2420:
		if ((pt=CreatePort(1, (char*)portparams))) {
			AddDevice(new C2420(pt, UINT8(md), UINT8(fs)));
		}
		break;
	case DEVICE_OPLLP:
		if ((pt=CreatePort(1, (char*)portparams))) {
			AddDevice(new COPLLP(pt, UINT8(md), UINT8(fs)));
		}
		break;
	default:
		delete pt;
	}
	return res;
}

int CFITOM::CreateDualDevice(int devtype, char* param)
{
	int res = 0;
	CPort* pt1 = 0;
	CPort* pt2 = 0;
	CSoundDevice* dev1 = 0;
	CSoundDevice* dev2 = 0;
	int md, fs;
	char portpara1[80];
	char portpara2[80];
	sscanf(param, "%i : %i, %[^,],%s", &md, &fs, portpara1, portpara2);
	pt1 = CreatePort(1, portpara1);
	pt2 = CreatePort(1, portpara2);
	while (pt1&&pt2) {
		switch (devtype) {
		case DEVICE_OPN:
			if (!(md & 1)) {
				dev1 = new COPN(pt1, UINT8(fs));
				dev2 = new COPN(pt2, UINT8(fs));
			}
			if (!(md & 2)) {
				devtype = DEVICE_SSG;
			} else {
				pt1 = pt2 = 0;
			}
			break;
		case DEVICE_OPNC:
			if (!(md & 1)) {
				dev1 = new COPNC(pt1, UINT8(fs));
				dev2 = new COPNC(pt2, UINT8(fs));
			}
			if (!(md & 2)) {
				devtype = DEVICE_SSG;
			} else {
				pt1 = pt2 = 0;
			}
			break;
		case DEVICE_OPL:
			dev1 = new COPL(pt1, UINT8(md), UINT8(fs));
			dev2 = new COPL(pt2, UINT8(md), UINT8(fs));
			pt1 = pt2 = 0;
			break;
		case DEVICE_Y8950:
			dev1 = new C3801(pt1, UINT8(md), UINT8(fs));
			dev2 = new C3801(pt2, UINT8(md), UINT8(fs));
			pt1 = pt2 = 0;
			break;
		case DEVICE_OPL2:
			dev1 = new COPL2(pt1, UINT8(md), UINT8(fs));
			dev2 = new COPL2(pt2, UINT8(md), UINT8(fs));
			pt1 = pt2 = 0;
			break;
		case DEVICE_OPLL:
			dev1 = new COPLL(pt1, UINT8(md), UINT8(fs));
			dev2 = new COPLL(pt2, UINT8(md), UINT8(fs));
			pt1 = pt2 = 0;
			break;
		case DEVICE_2420:
			dev1 = new C2420(pt1, UINT8(md), UINT8(fs));
			dev2 = new C2420(pt2, UINT8(md), UINT8(fs));
			pt1 = pt2 = 0;
			break;
		case DEVICE_OPLLP:
			dev1 = new COPLLP(pt1, UINT8(md), UINT8(fs));
			dev2 = new COPLLP(pt2, UINT8(md), UINT8(fs));
			pt1 = pt2 = 0;
			break;
		case DEVICE_SSG:
			dev1 = new CSSG(pt1, UINT8(fs));
			dev2 = new CSSG(pt2, UINT8(fs));
			pt1 = pt2 = 0;
			break;
		}
		if (dev1 && dev2) {
			AddDevice(new CSplitPan(dev1, dev2, UINT8(fs)));
		}
	}
	return res;
}

int CFITOM::LoadDeviceConfig(FILE* fp)
{
	char tmp[80];
	while(fgets(tmp, 80, fp) != NULL) {
		char devtyp[16];
		char params[80];
		//sscanf(tmp, "%[^:]: %i, %i, %s", devtyp, &md, &fs, params);

		if (strncmp("DUAL_", devtyp, 5) == 0) {
			sscanf(&tmp[5], "%[^:]: %s", devtyp, params);
		} else {
			sscanf(tmp, "%[^:]: %s", devtyp, params);
			int devnum = GetDeviceIDFromName((char*)devtyp);
			CreateSingleDevice(devnum, params);
		}
	}
	if (!devs) { return -2; }
	return 0;
}

CHostIF* CFITOM::GetIOIF(CHostIF::IOIF_TYPE type, UINT32 id)
{
	for (int i=0; i<ioifs; i++) {
		if (pioif[i]->GetIFType() == type && pioif[i]->GetIFID() == id) {
			return pioif[i];
		}
	}
	return 0;
}

int CFITOM::LoadMapConfig(FILE* fp)
{
	int ret = 0;
	char tmp[80];
	int inst, ch, timbres;
	char dev[10];
	inst = -1;
	if (mpus) {
		while(fgets(tmp, 80, fp) != NULL) {
			sscanf(tmp, "%i : %[^,\n] , %i", &ch, dev, &timbres);
			ch--;
			inst = ch >> 4;
			ch = ch & 0xf;
			if (inst < mpus) {
				if (strcmp(dev, "RHYTHM")==0) {
					midi[inst]->AssignRhythm(ch);
				} else {
					CSoundDevice* chip = GetInstDeviceFromID(GetDeviceIDFromName(dev));
					if (chip != NULL && timbres <= chip->GetChs()) {
						midi[inst]->Assign(ch, chip, timbres);
						printf("port%i: ch.%i: %s(%i)\n", inst, ch, dev, timbres);
					}
				}
			}
		}
	}
	return ret;
}

int CFITOM::LoadVoiceConfig(FILE* fp)
{
	int ret = 0;
	char tmp[80];
	char filename[80];
	char devname[80];
	int bank;
	while(fgets(tmp, 80, fp) != NULL) {
		sscanf(tmp, " %[^:] : %i : %[^:\n]", devname, &bank, filename);
		UINT8 vtype = GetVoiceType(GetDeviceIDFromName(devname));
		switch (vtype) {
		case VOICE_TYPE_OPN:
		case VOICE_TYPE_OPNA:
			if (bank < MAX_BANK) {
				printf("Loading OPN/OPN2/OPNA voice bank \"%s\"\n", filename);
				LoadVoice(bank, opnabank, filename);
			}
			break;
		case VOICE_TYPE_OPM:
			if (bank < MAX_BANK) {
				printf("Loading OPM voice bank \"%s\"\n", filename);
				LoadVoice(bank, opmbank, filename);
			}
			break;
		case VOICE_TYPE_OPL3:
			if (bank < MAX_BANK) {
				printf("Loading OPL3(4op) voice bank \"%s\"\n", filename);
				LoadVoice(bank, opl3bank, filename);
			}
			break;
		case VOICE_TYPE_OPL2:
			if (bank < MAX_BANK) {
				printf("Loading OPL/OPL2 voice bank \"%s\"\n", filename);
				LoadVoice(bank, opl2bank, filename);
			}
			break;
		case VOICE_TYPE_OPLL:
			if (bank < MAX_BANK) {
				printf("Loading OPLL voice bank \"%s\"\n", filename);
				LoadVoice(bank, opllbank, filename);
			}
			break;
		case VOICE_TYPE_SSG:
			if (bank == 0) {
				printf("Loading PSG voice bank \"%s\"\n", filename);
				LoadVoice(bank, psgbank, filename);
			}
			break;
		default:
			if ((strcmp("SSGDRUM:", devname) == 0 ||
				strcmp("PSGDRUM", devname) == 0)) {
			}
			if (strcmp("RHYTHM", devname) == 0) {
				printf("Loading Rhythm bank \"%s\"\n", filename);
				LoadDrumMap(bank, filename);
			}
			break;
		}
	}
	return ret;
}

int CFITOM::LoadVoice(int bank, CXmemFile* voice, char* filename)
{
	int ret = 0;
	FILE* fp = NULL;
	FMVOICE buf;
	if ((fp=fopen(filename, "rb"))) {
		for (int i=0; i<128; i++) {
			voice->Seek(sizeof(FMVOICE)*(bank*128L+i), 0);
			if (fread((void*)&buf, sizeof(FMVOICE), 1, fp)) {
				buf.ID = (buf.ID & 0xffff0000) | (bank << 8) | i;
				voice->Write((void*)&buf, (UINT32)sizeof(FMVOICE));
			}
		}
		fclose(fp);
	} else {
		printf("Error loading \"%s\"\n", filename);
		ret = -1;
	}
	return ret;
}

int CFITOM::SaveVoice(int bank, CXmemFile* voice, char* filename)
{
	int ret = 0;
	FILE* fp = NULL;
	FMVOICE* buf = new FMVOICE[128];
	if ((fp=fopen(filename, "wb"))) {
		for (int i=0; i<128; i++) {
			voice->Seek(sizeof(FMVOICE)*(bank*128L+i), 0);
			voice->Read((void*)&buf[i], (UINT32)sizeof(FMVOICE));
		}
		fwrite((void*)buf, sizeof(FMVOICE), 128, fp);
		fclose(fp);
	} else {
		printf("Error saving \"%s\"\n", filename);
		ret = -1;
	}
	delete[] buf;
	return ret;
}

int CFITOM::InitVoice(int type, int banks, CXmemFile* voice)
{
	int ret = 0;
	FMVOICE buf;
	memset((void*)&buf, 0, sizeof(FMVOICE));
	for (int j=0; j<banks; j++) {
		for (int i=0; i<128; i++) {
			voice->Seek(sizeof(FMVOICE)*(j*128L+i), 0);
			buf.ID = UINT32(0xff000000L) | UINT32(j << 8) | i;
			voice->Write((void*)&buf, (UINT32)sizeof(FMVOICE));
		}
	}
	return ret;
}

int CFITOM::LoadDrumMap(int mapnum, char* filename)
{
	int ret = 0;
	FILE* fp = NULL;
	char tmp[80];
	if ((fp=fopen(filename, "rb"))) {
		while(fgets(tmp, 80, fp) != NULL) {
			int note;
			int pan;
			int gate;
			int bank;
			int prog;
			char devname[80];
			char notename[80];
			char strnote[8];
			DRUMMAP tmpdrum;
			sscanf(tmp, " %i , %[^,], %[^,], %i, %i, %[^,] , %i , %i ", &note, notename, devname, &bank, &prog, strnote, &pan, &gate);
			if (note >= 0 && note < 128) {
				if (strnote[0] == '#') {
					sscanf(&strnote[1], "%i:%x", &tmpdrum.num, &tmpdrum.fnum);
					tmpdrum.num |= 0x80;
				} else {
					sscanf(strnote, "%i", &tmpdrum.num);
					tmpdrum.fnum = 0;
				}
				tmpdrum.devID = GetDeviceIDFromName(devname);
				tmpdrum.device = GetInstDeviceFromID(tmpdrum.devID);
				tmpdrum.bank = UINT8(bank);
				tmpdrum.prog = UINT8(prog);
				tmpdrum.pan = SINT8(pan);
				tmpdrum.gate = UINT16(gate);
				drummap->Seek((mapnum * 128L + note) * sizeof(DRUMMAP), 0);
				drummap->Write(&tmpdrum, sizeof(DRUMMAP));
			}
		}
		fclose(fp);
	} else {
		printf("Error loading \"%s\"\n", filename);
		ret = -1;
	}
	return ret;
}

int CFITOM::LoadConfig()
{
	int ret = 0;
#ifdef _WIN32

#endif //_WIN32
	FILE* cfg = NULL;
	if ((cfg = fopen("IO.CFG", "rt"))) {
		printf("Loading I/O settings...\n");
		ret = LoadIOIF(cfg);
		fclose(cfg);
	}
	if ((cfg=fopen("DEVICE.CFG", "rt"))) {
		printf("Loading device settings...\n");
		ret = LoadDeviceConfig(cfg);
		fclose(cfg);
	}
	if ((cfg=fopen("MIDIIF.CFG", "rt"))) {
		printf("Loading device settings...\n");
		ret = LoadMidiConfig(cfg);
		fclose(cfg);
	}
	if ((cfg=fopen("MIDIMAP.CFG", "rt"))) {
		printf("Loading MIDI channel map settings...\n");
		ret = LoadMapConfig(cfg);
		fclose(cfg);
	}
	if ((cfg=fopen("VOICEMAP.CFG", "rt"))) {
		printf("Loading preset voice settings...\n");
		ret = LoadVoiceConfig(cfg);
		fclose(cfg);
	}

	return ret;
}
