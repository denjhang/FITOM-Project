/*---------------------------------------------------------------------------*/
/*																			 */
/*	 XMS (FGALEL MES2 Sample)												 */
/*	   by Sey_ju_row (QGA02240@niftyserve.or.jp)							 */
/*																			 */
/*---------------------------------------------------------------------------*/
#include <stdio.h>
#include <dos.h>
#include "XMS.H"

static void ( far *XMScall )( void );

union	REGS	regs;	/* INT�p�o�b�t�@ */
struct SREGS	sregs;	/* INT�p�o�b�t�@ */

void ( far *GetXMSentry( void ))( void )
{
	regs.x.ax = 0x4300;
	int86( 0x2f, &regs, &regs );		/* �ݽİ٥���� */
	if ( regs.h.al != 0x80 )
		return( XMScall = NULL );
	regs.x.ax = 0x4310; 				/* XMS ���ب����ڽ�̎擾 */
	int86x( 0x2f, &regs, &regs, &sregs );
	return( XMScall = ( void (far *)( void ))MK_FP( sregs.es, regs.x.bx ));
}

int XMSalloc( ulong size, SMEM *pmem )
{
	uint KBsize;
	uint res;
	uint handle;

	KBsize = (size >> 10) + ((size&1023) ? 1 : 0);
	_asm	push dx
	_asm	mov dx, word ptr ss:[KBsize]
	_asm	mov ah,09h
	_asm	call dword ptr XMScall
	_asm	mov handle, dx
	_asm	mov res, ax
	_asm	pop dx
	pmem->handle = handle;
	pmem->linptr = 0L;
	return res;
}

int XMSfree( uint handle )
{
	uint res;

	regs.x.dx = handle;
	regs.h.ah = 0x0a;			/* XMS ��؉�� */
	_asm	push dx
	_asm	mov dx, handle
	_asm	mov ah,0ah
	_asm	call dword ptr XMScall
	_asm	mov res,ax
	_asm	pop dx
	return res;
}

ulong ExMemMov ( int dir, SMEM *pmem, void *buf, ulong size )
{
	stExMemMov semm;
    uint sseg = FP_SEG(&semm);
    uint soff = FP_OFF(&semm);
    uint res;
	if ( dir == XMSPUT ) {
		semm.MemLength	  = size;
		semm.SourceHandle = 0;
		semm.SourceOffset = ( ulong )buf;
		semm.DestHandle	= ( uint )pmem->handle;
		semm.DestOffset	= pmem->linptr;
	} else if ( dir == XMSGET ) {
		semm.MemLength	  = size;
		semm.SourceHandle = ( uint )pmem->handle;
		semm.SourceOffset = pmem->linptr;
		semm.DestHandle	= 0;
		semm.DestOffset	= ( ulong )buf;
	} else return 0;
	_asm	push si
	_asm	mov ds,sseg
	_asm	mov si,soff
	_asm	mov ah,0bh
	_asm	call dword ptr XMScall
	_asm	mov res,ax
	_asm	pop si
	if ( res == 0 ) return (ulong)( -1L );
	pmem->linptr += size;
	return( size );
}

#if 0
int main (void)
{
	char *buf_s = "test strings";
	char *buf_d = "            ";
	ulong size = 12L;
	SMEM pmem;

	/* �����ޯ̧ �̕������ XMS �o�R���ި��Ȱ��ݥ�ޯ̧ �ɓ]�� (^^; */

	if ( GetXMSentry() != NULL ) {
		if ( XMSalloc( size, &pmem )) {
			ExMemMov ( XMSPUT, &pmem, buf_s, size );
			pmem.linptr = 0L;
			ExMemMov ( XMSGET, &pmem, buf_d, size );
			printf ( "%s\n", buf_d );
			XMSfree( pmem.handle );
		}
	}
	return(0);
}
#endif
