#include "STDAFX.H"
#include "Port.h"
#include "FITOM.h"

int CFITOM::LoadIOIF(FILE* fp)
{
	pioif[0] = new C98IO();
	ioifs = 1;
	return 1;
}

void C98IO::write(UINT16 addr1, UINT16 addr2, UINT16 reg, UINT16 data, UINT16 w1, UINT16 w2)
{
	_outp(addr1, UINT8(reg));
	wait(w1);
	_outp(addr2, UINT8(data));
	wait(w2);
}

void C98IO::write(UINT16 addr, UINT16 data, UINT16 w)
{
	_outp(addr, UINT8(data));
	wait(w);
}

UINT8 C98IO::read(UINT16 addr, UINT16 reg, UINT16 w)
{
	_outp(addr, UINT8(reg));
	wait(w);
	return _inp(addr);
}

UINT8 C98IO::read(UINT16 addr)
{
	return _inp(addr);
}

void C98IO::wait(int w)
{
	for (;w != 0; --w) {
		_outp(0x5f, 0);
	}
}
