// midilist.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <Windows.h>


int _tmain(int argc, _TCHAR* argv[])
{
	MIDIINCAPS mic;
	int dev = -1;
	int numdevs = midiInGetNumDevs();
	printf("%i MIDI IN devices found.\n", numdevs);
	for (int i=0; i<numdevs; i++) {
		if (midiInGetDevCaps(i, &mic, sizeof(mic)) == MMSYSERR_NOERROR) {
			printf("Device%i:%ws\n", i, mic.szPname);
		}
	}

	return 0;
}

